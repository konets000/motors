# Roadmap

RutaMotor 1.1.0 completes the parts of the platform that can be built and verified inside this repository: account security (email confirmation, password reset, session invalidation), a confirmation gate for listings, a shared rate limiter, and browser coverage for the account screens.

The items below are not in this release. Each one depends on something outside the codebase: a partner agreement, a data provider, a legal review, or infrastructure that has not been chosen yet. Writing code for them first would mean building against assumptions that may change, so each entry states what unblocks it and what the engineering plan is.

## Blocked on external decisions

### Mercado Libre and other portals

**Blocked on:** a developer application and partner approval with each portal. Mercado Libre requires OAuth 2.0 and an approved app before a production token can be issued.

**Plan:**
- One provider adapter per portal, with the same shape as `src/integrations/compradeautos.js`: an injected `fetch`, a configuration object, typed results, and a `permanent` flag on errors so the job queue stops retrying what cannot succeed.
- Per-seller OAuth connections. Store refresh tokens sealed with `sealText` (the same mechanism as account email links), never in plain text. Refresh them in a job before expiry.
- Reuse `external_listings` for per-provider status. Publishing uses the existing `external.<provider>.publish` job pattern, which already makes publishing idempotent.
- Test the field mapping against recorded fixtures, and cover token expiry and revocation.

**Done when:** sandbox credentials work end to end, the field mapping has been reviewed with the portal's documentation, and the seller can disconnect the account and remove the stored tokens.

### Vehicle history, liens and fines

**Blocked on:** an authorised data provider, and a legal basis for using registry data. The platform must not show a vehicle as "verified" without a stored provider result.

**Plan:**
- A `vehicle_checks` table: provider, check type, status, `checked_at`, and the raw provider response, with a retention period set by the contract.
- The UI shows exactly what the provider returned and when it was checked. "Not checked" is the default state.
- Each check runs as a job, so provider outages retry without blocking the seller.
- Keep the existing footer disclaimer until the checks are live.

**Done when:** the provider contract and the data-protection review are complete.

### Payments and financing

**Blocked on:** legal and compliance review of consumer and financial rules, and a payment provider contract. Holding funds or offering credit changes the platform's legal position, so no code should be written before that review.

**Design considerations for when it starts:**
- Prefer a hosted checkout so card data never reaches RutaMotor servers, which keeps PCI scope small.
- Webhooks must be idempotent. The existing outbox pattern (write the business change and its job in one transaction) fits here.
- Decide early between direct payment and escrow. The choice determines the state machine for listings and inquiries.

## Ready to build, needs an infrastructure decision

### Photo object storage and malware scanning

**Blocked on:** a choice of object storage provider and a malware scanning service. Nothing in the code depends on the choice yet.

**Plan:**
- `src/media.js` already exposes `save`, `read` and `remove`. Add an S3-compatible driver with SigV4 request signing, written against `fetch` so it stays testable offline. No SDK is needed.
- Keep serving photos through the API for now. Signed URLs would need the bucket origin added to the Content Security Policy's `img-src`, which is a deliberate security change.
- Add a `scan_status` column on `photos` (`pending`, `clean`, `quarantined`) and a `photo.scan` job. Listing pages show only clean photos.
- Keep the existing magic-byte check as the first gate. Scanning comes after it.

**Done when:** a staging bucket and a scanner are chosen, and a quarantined file is never served to another visitor.

### CompraDeAutos live verification

**Blocked on:** the current API documentation and sandbox credentials from CompraDeAutos.cl. The README already marks this integration as unverified against the live API.

**Plan:** check each field and enum mapping against the current documentation, add contract tests against the sandbox, and record the responses as fixtures.

## Operational work

- **Email deliverability.** Publish SPF, DKIM and DMARC for the `MAIL_FROM` domain. Handle bounces and complaints through the provider's webhooks, which is not implemented.
- **Browser tests in CI.** `npm run test:e2e` runs in a few seconds with Chrome. Add a CI job that installs Chrome and `puppeteer-core` and sets `E2E_CHROME_PATH`. It was not added here because CI provisioning is outside this repository.
- **PostgreSQL verification.** The CI PostgreSQL job runs the full integration suite, including the new account and rate-limit tests. Confirm that job passes before deploying 1.1.0 to a shared environment.
