# Architecture

## Layers

1. **HTTP (`src/app.js`, `src/http.js`).** A small router on `node:http`. Each request passes through: security headers, CORS, route matching, rate limit, authentication, CSRF check for cookie writes, role check, JSON body parsing with a size limit, schema validation, the handler, and a single error mapper. Handlers return data; they never write raw responses.
2. **Validation (`src/validation.js`).** Zod schemas for every input. Schemas are strict (unknown fields are rejected), trim text, strip control characters, coerce numbers, and treat empty query strings as absent.
3. **Domain (`src/domain.js`).** Pure rules: listing status transitions, CSV escaping, HTML escaping. Unit tested without any I/O.
4. **Data access (`src/store.js`).** One set of SQL statements for both dialects. Placeholders are `$1…`. Only column names from code are ever interpolated.
5. **Database adapters (`src/db.js`).** `node:sqlite` for SQLite (operations are serialised so an open transaction cannot interleave with other requests) and `pg` for PostgreSQL. Both expose `query`, `execute`, `exec`, `transaction` and the same dialect properties.
6. **Background work (`src/jobs.js`, `src/worker.js`).** Persistent queue, handlers and the worker loop.
7. **Integrations (`src/integrations/`).** Each adapter takes a `fetch` implementation and a configuration object. None of them read the environment directly, which makes them testable offline.

## Data model

Tables: `users`, `listings`, `photos`, `inquiries`, `jobs`, `external_listings`, `audit_events`, `account_tokens`, `rate_limits`, `schema_migrations`.

- Identifiers are UUID text in both dialects. Timestamps are `TIMESTAMPTZ` in PostgreSQL and ISO-8601 text in SQLite.
- Listing status: `active` → `reserved` ⇄ `active`; `active` or `reserved` → `sold` (terminal); `active` or `reserved` → `archived` ⇄ `active`.
- Inquiry status: sellers set any of `new`, `contacted`, `qualified`, `closed` or `spam`. The API does not enforce an order, because sellers track conversations in different ways.
- `external_listings` has a unique `(listing_id, provider)` pair, so a listing is published to each provider at most once at a time.

## Transactional outbox

When a buyer submits an inquiry, the inquiry row and the `lead.created` job are written in one transaction. Likewise a status change and its `webhook.deliver` job. Either both commit or neither does. The worker picks up the job afterwards, so a lead is never stored without its notification being scheduled.

## Job lifecycle

```
queued ──claim──► running ──success──► done
  ▲                  │
  │                  ├──retryable error, attempts < 6──► queued (run_at += backoff)
  │                  ├──permanent error or attempts = 6──► failed ──admin retry──► queued
  └── lock older than 10 min (worker crashed) ◄── running
```

- Claiming increments `attempts` and sets `locked_at`. On PostgreSQL the claim uses `FOR UPDATE SKIP LOCKED`, so several workers never take the same job.
- Backoff: 30 s, 60 s, 120 s, … capped at one hour.
- Errors marked `permanent` (validation, rejected content, missing configuration) fail the job immediately.
- `dedupe_key` makes scheduled work idempotent: monthly reminders and the periodic stale-listing scan cannot create duplicates.

## Idempotency of side effects

Each handler checks an audit record before performing an external action (for example `notify.email` for an inquiry) and writes that record after success. A retry after a later failure therefore does not repeat completed sends. This was the main defect fixed relative to the earlier prototype, where a WhatsApp failure caused a duplicate email on retry.

## Security decisions

- **Passwords:** scrypt (N=16384, r=8, p=1) with a random 16-byte salt. Unknown emails are verified against a dummy hash, so response time does not reveal which accounts exist.
- **Sessions:** HMAC-SHA256 tokens with `exp`, stored in an `HttpOnly`, `SameSite=Lax` cookie (`Secure` in production). Bearer tokens are accepted for API clients and are not subject to the cookie CSRF rule.
- **CSRF:** cookie-authenticated writes are rejected when `Sec-Fetch-Site` is cross-site or when the `Origin` host differs from `Host`. Writes require a JSON content type, which browsers cannot send cross-site without a preflight.
- **Authorisation:** every owner route loads the resource with the caller's id in the same query. Foreign resources return 404, so their existence is not disclosed.
- **Uploads:** size limits are enforced before decoding, the image type is taken from magic bytes, and stored file names are random UUIDs that never come from the client.
- **Output:** user content is inserted as text only. The page sends a strict Content Security Policy with no inline scripts. Photos are served with `nosniff`.
- **Logs:** one JSON object per line. Fields named like credentials are redacted; email addresses are masked.
- **Webhooks:** signed and timestamped. Redirects are refused. Production requires HTTPS.
- **Outbound calls:** `redirect: 'error'` and explicit timeouts on every provider request.
- **Account links:** verification and reset links carry 256-bit random tokens. The database stores only their SHA-256 hash. Links are single-use, valid 72 hours (verification) or 1 hour (reset), and a newer link revokes the older ones. The link travels in the URL fragment, which browsers do not send to the server.
- **Sealed job payloads:** the email job holds its token encrypted with AES-256-GCM. The key is derived from `AUTH_SECRET` with HKDF. A database dump or a worker log cannot reveal a usable link. The token is opened only inside the handler that sends the email, and a link that was used or superseded before sending is never sent.
- **Session version:** session tokens carry the account's `session_version`. A password reset increments it, so every earlier session fails verification on its next request.
- **Enumeration:** the forgot-password response is the same for every address. Server-side timing differs slightly for real accounts because an email is queued. Per-IP and per-address limits keep that difference from being a practical probe.
- **Session revocation:** `POST /api/auth/sessions/revoke-all` increments `session_version`. Logout alone only clears the current browser's cookie.
- **Development secret:** without `AUTH_SECRET`, development processes share one secret in `data/.dev-auth-secret`, so the worker can open links the API sealed. Production refuses to start without `AUTH_SECRET`.

## Operations

- **Request tracing:** every response carries `X-Request-Id`. A client-supplied ID is kept when it is short and made of safe characters. Each request writes one `request.completed` line with method, path (never the query string), status and duration.
- **Migrations:** one transaction, taken under a lock (`pg_advisory_xact_lock` on PostgreSQL, `BEGIN IMMEDIATE` on SQLite). Several API instances can start at once; the rest wait and find nothing left to apply.
- **Retention:** `maintenance.prune` runs once a day. It deletes finished jobs older than 30 days and account links expired for over 7 days. Failed jobs and the audit log are kept.
- **Photo limits** are published by `GET /api/facets`, so the browser and the server read the same values.

## Known gaps

- Registration reveals whether an email is already registered (409). Removing that needs a sign-up flow without automatic sign-in, which is a product decision; the limit on registration attempts is the current mitigation.
- Rate limits are per process unless `RATE_LIMIT_STORE=database`. Photo storage is still local disk.
- The project has no lockfile yet. Run `npm install` once with network access and commit `package-lock.json`, so Docker builds are reproducible.
- Email deliverability (SPF, DKIM, DMARC for the sender domain) is an operator task. Bounce handling is not implemented.
- Browser tests are opt-in (`npm run test:e2e`) and are not yet part of CI.
- Planned work with external dependencies is listed in [ROADMAP.md](ROADMAP.md).
