# RutaMotor API reference

Base path `/api`. Bodies are JSON (`Content-Type: application/json`). Errors have the shape `{ "error": "message" }`; validation errors add `details: [{ path, message }]`.

**Authentication.** Sign in to receive an `HttpOnly` session cookie for the web app, or use the returned `token` as `Authorization: Bearer <token>` for API clients. Cookie-authenticated writes must come from the same origin.

**Tracing.** Every response carries `X-Request-Id`. Send your own (up to 64 letters, digits, `.`, `_` or `-`) to correlate logs across systems. `HEAD` works wherever `GET` does.

**Access levels.** `public` needs no session. `optional` works anonymously and gives owners extra access. `auth` requires a session. `admin` requires the admin role.

## Account

| Method | Path | Access | Description |
|---|---|---|---|
| POST | `/auth/register` | public, rate limited | Create an account and email a confirmation link. Body: `name`, `email`, `password` (10+ chars), optional `phone`, `whatsappOptIn`. |
| POST | `/auth/login` | public, rate limited | Body: `email`, `password`. Returns `user`, `token` and sets the cookie. |
| POST | `/auth/logout` | public | Clears the session cookie in this browser. Other copies of the session stay valid; use `sessions/revoke-all` to end them. |
| POST | `/auth/sessions/revoke-all` | auth | Ends every session of the account, including tokens used by phones and API clients. The password is unchanged. |
| GET | `/auth/me` | auth | Current user, including `emailVerified`. |
| POST | `/auth/verify-email` | public, rate limited | Body: `token` (from the confirmation link). Marks the email confirmed. Links work once. Returns 400 when invalid, used or expired. |
| POST | `/auth/resend-verification` | auth, rate limited | Sends a new confirmation link and revokes the previous one. Returns `alreadyVerified: true` and sends nothing when the email is confirmed. |
| POST | `/auth/forgot-password` | public, rate limited | Body: `email`. Always returns the same `{ ok, message }`. Emails a reset link only when the account exists. |
| POST | `/auth/reset-password` | public, rate limited | Body: `token` (from the reset link), `password` (10+ chars). Sets the new password, ends every existing session, marks the email confirmed, and emails the account holder. Links work once. |

## Catalogue

| Method | Path | Access | Description |
|---|---|---|---|
| GET | `/facets` | public | Currency, the photo `limits` (`maxPhotoBytes`, `maxPhotosPerListing`), distinct makes and regions of active listings, and allowed enum values. |
| GET | `/listings` | public | Search. Query: `q`, `make`, `body`, `fuel`, `transmission`, `region`, `minPrice`, `maxPrice`, `minYear`, `maxYear`, `maxMileage`, `sort` (`newest`, `priceAsc`, `priceDesc`, `yearDesc`, `mileageAsc`), `limit` (1–100), `offset`. |
| GET | `/listings/:id` | optional | Active listing with photos. Owners also see their non-active listings. Returns `item`, `photos`, `isOwner`. |
| GET | `/media/:photoId` | public | Photo bytes with the stored content type. Hidden when the listing is archived. |

## Seller

| Method | Path | Access | Description |
|---|---|---|---|
| POST | `/listings` | auth | Publish a listing. Returns 403 for unconfirmed emails when `REQUIRE_VERIFIED_EMAIL=true`. Body fields: `make`, `model`, `trim`, `year`, `price` (CLP), `mileage` (km), `transmission` (`automatic`/`manual`), `fuel` (`petrol`/`diesel`/`hybrid`/`electric`/`lpg`), `body` (`suv`/`sedan`/`hatchback`/`pickup`/`coupe`/`van`), `engineCc`, `region`, `city`, `description`. |
| PATCH | `/listings/:id` | auth, owner | Partial update of the fields above. Sold listings are frozen. |
| PATCH | `/listings/:id/status` | auth, owner | Body: `status` (`active`, `reserved`, `sold`, `archived`). Allowed moves: active→reserved/sold/archived, reserved→active/sold/archived, archived→active. Anything else returns 409. |
| POST | `/listings/:id/renew` | auth, owner | Resets the publish date. Active listings only. |
| GET | `/me/listings` | auth | Your listings with `photoCount` and `inquiryCount`. |
| POST | `/listings/:id/photos` | auth, owner | Body: `filename`, `dataBase64`. JPEG, PNG or WebP up to `MAX_PHOTO_BYTES`; the type is detected from the file contents. |
| DELETE | `/listings/:id/photos/:photoId` | auth, owner | Removes a photo. |
| GET | `/me/inquiries` | auth | Inquiries on your listings. Query: `carId`, `status`, `limit`, `offset`. |
| GET | `/me/inquiries.csv` | auth | The same inquiries as a CSV download. Formula characters are neutralised. |
| PATCH | `/inquiries/:id` | auth, owner | Body: `status` (`new`, `contacted`, `qualified`, `closed`, `spam`). |

## Buyer

| Method | Path | Access | Description |
|---|---|---|---|
| POST | `/listings/:id/inquiries` | public, rate limited | Body: `name`, `email`, optional `phone`, `message` (5–1200 chars), `consent: true`. Returns 201 and schedules the seller notification. |

## Integrations

| Method | Path | Access | Description |
|---|---|---|---|
| POST | `/listings/:id/publish/compradeautos` | auth, owner | Queues publishing to CompraDeAutos.cl. Returns 202. Requires photos, `engineCc`, and an active or reserved listing. |
| GET | `/listings/:id/external` | auth, owner | External publishing status per provider. |
| POST | `/ai/listing-description` | auth, rate limited | Body: `make`, `model`, `year`, `mileage`, `transmission`, `fuel`, `body`, optional `features`, `notes`. Returns `text` and `source` (`ai` or `template`). |
| POST | `/ai/assistant` | public, rate limited | Body: `message` (3–500 chars). Answers from the 20 newest active listings. Returns 503 when AI is not configured. |

## Administration

| Method | Path | Access | Description |
|---|---|---|---|
| GET | `/admin/jobs` | admin | Queue contents. Query: `status`, `limit`. |
| POST | `/admin/jobs/:id/retry` | admin | Requeues a failed job. Other statuses return 409. |
| PATCH | `/admin/listings/:id/status` | admin | Moderation. Body: `status` (`active` or `archived`) and `reason` (3–200 chars). The reason is kept in the audit log. |

## Operations

| Method | Path | Access | Description |
|---|---|---|---|
| GET | `/health` | public | `{ ok, database, dialect, version }`. Returns 503 when the database is unreachable. |

## Webhooks

Each delivery is a `POST` with JSON body `{ "id", "event", "occurredAt", "data" }` and headers `X-RutaMotor-Event`, `X-RutaMotor-Delivery` and `X-RutaMotor-Signature: t=<unix>,v1=<hex>`. The signature is HMAC-SHA256 over `"<t>.<raw body>"` with `WEBHOOK_SECRET`. Reject deliveries whose timestamp is more than five minutes old. Payloads contain identifiers and status only, no buyer personal data.

## Rate limits

| Scope | Limit |
|---|---|
| All API routes, per IP | 300 requests per minute |
| Register and login | 10 per 15 minutes |
| Account links (confirm, forgot, reset) | 10 per 15 minutes per IP. Forgot-password is also capped at 3 per hour per address. Resend confirmation is capped at 3 per hour per account. |
| Inquiries | 10 per minute |
| Photo uploads | 60 per minute |
| AI description | 30 per hour |
| AI assistant | 20 per hour |

Exceeded limits return 429 with `Retry-After`.
