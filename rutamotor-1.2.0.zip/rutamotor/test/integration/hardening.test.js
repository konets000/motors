// Hostile and malformed requests. Each one must get a precise, safe answer, and none may reveal internals.
import test from 'node:test';
import assert from 'node:assert/strict';
import { createHarness } from './harness.js';

const JSON_HEADERS = { 'Content-Type': 'application/json' };

async function raw(h, method, path, { headers = {}, body } = {}) {
  const res = await fetch(h.base + path, { method, headers, body });
  return { status: res.status, headers: res.headers, text: await res.text() };
}

test('bodies: wrong content type, invalid JSON and oversized requests are refused without a stack trace', async (t) => {
  const h = await createHarness();
  t.after(() => h.close());
  const plain = await raw(h, 'POST', '/api/auth/login', { headers: { 'Content-Type': 'text/plain' }, body: '{"email":"a@b.test","password":"x"}' });
  assert.equal(plain.status, 415);
  const broken = await raw(h, 'POST', '/api/auth/login', { headers: JSON_HEADERS, body: '{"email":' });
  assert.equal(broken.status, 400);
  const huge = await raw(h, 'POST', '/api/auth/login', { headers: JSON_HEADERS, body: JSON.stringify({ email: 'a@b.test', password: 'x'.repeat(20_000) }) });
  assert.equal(huge.status, 413);
  for (const response of [plain, broken, huge]) {
    assert.ok(!/at .*\.js:\d+/.test(response.text), 'no stack trace in the response');
  }
});

test('paths: traversal attempts and unknown routes return 404, never file contents', async (t) => {
  const h = await createHarness();
  t.after(() => h.close());
  for (const path of ['/assets/%2e%2e/%2e%2e/package.json', '/assets/..%2f..%2fpackage.json', '/media/..%2F..%2Fetc', '/api/nope']) {
    const response = await raw(h, 'GET', path);
    assert.equal(response.status, 404, `${path} is not found`);
    assert.ok(!response.text.includes('"name": "rutamotor"') && !response.text.includes('root:'), `${path} leaks nothing`);
  }
  assert.equal((await raw(h, 'GET', '/api/listings/%27%20OR%201%3D1--')).status, 404, 'a malicious id is treated as an unknown listing');
});

test('query strings: unknown sort values and extra fields are rejected; control characters are stripped', async (t) => {
  const h = await createHarness();
  t.after(() => h.close());
  assert.equal((await raw(h, 'GET', '/api/listings?sort=newest;DROP%20TABLE%20users')).status, 422);
  assert.equal((await raw(h, 'GET', '/api/listings?q=%00abc')).status, 200, 'a NUL byte is removed, not passed to SQL');
});

test('mass assignment: unknown fields in a registration body, including __proto__, are rejected', async (t) => {
  const h = await createHarness();
  t.after(() => h.close());
  const res = await raw(h, 'POST', '/api/auth/register', {
    headers: JSON_HEADERS,
    body: '{"__proto__":{"role":"admin"},"role":"admin","name":"x","email":"p@x.test","password":"long-enough-pass"}'
  });
  assert.equal(res.status, 422);
});

test('CORS: an unlisted origin receives no access-control headers', async (t) => {
  const h = await createHarness();
  t.after(() => h.close());
  const res = await raw(h, 'GET', '/api/health', { headers: { Origin: 'https://evil.test' } });
  assert.equal(res.status, 200);
  assert.equal(res.headers.get('access-control-allow-origin'), null);
});

test('methods: wrong methods get 405, and HEAD answers like GET without a body', async (t) => {
  const h = await createHarness();
  t.after(() => h.close());
  assert.equal((await raw(h, 'PUT', '/api/listings')).status, 405);
  const head = await raw(h, 'HEAD', '/api/health');
  assert.equal(head.status, 200, 'load balancers can probe with HEAD');
  assert.equal(head.text, '');
});

test('every response carries the security headers', async (t) => {
  const h = await createHarness();
  t.after(() => h.close());
  for (const path of ['/api/health', '/', '/api/nope']) {
    const res = await raw(h, 'GET', path);
    assert.equal(res.headers.get('x-content-type-options'), 'nosniff', path);
    assert.equal(res.headers.get('x-frame-options'), 'DENY', path);
    assert.match(res.headers.get('content-security-policy') || '', /default-src 'self'/, path);
  }
});
