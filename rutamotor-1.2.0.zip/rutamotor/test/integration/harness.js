// Starts the real HTTP server against a fresh database. Set TEST_DATABASE_URL to run the same suite on PostgreSQL.
import http from 'node:http';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import crypto from 'node:crypto';
import { loadConfig } from '../../src/config.js';
import { createDatabase, migrate } from '../../src/db.js';
import { createServices } from '../../src/services.js';
import { createApp } from '../../src/app.js';
import { createHandlers, drainQueue } from '../../src/jobs.js';
import { createLogger } from '../../src/logger.js';

const DATABASE_URL = process.env.TEST_DATABASE_URL || 'sqlite::memory:';
// On PostgreSQL every harness gets its own schema, so parallel test files never see each other's rows or jobs.
const SCHEMA = process.env.TEST_DATABASE_URL ? `t_${crypto.randomUUID().replace(/-/g, '').slice(0, 16)}` : undefined;
const offlineFetch = async (url) => {
  throw new Error(`Unexpected network call in a test: ${url}`);
};

export const uniqueEmail = (label) => `${label}.${crypto.randomUUID().slice(0, 8)}@example.test`;
export const PNG_1x1 = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=', 'base64');
export const json = (data, status = 200) => new Response(JSON.stringify(data), { status, headers: { 'content-type': 'application/json' } });

export async function createHarness({ env = {}, fetchImpl = offlineFetch, now } = {}) {
  const uploadDir = fs.mkdtempSync(path.join(os.tmpdir(), 'rutamotor-it-'));
  const config = loadConfig({
    NODE_ENV: 'test',
    DATABASE_URL,
    UPLOAD_DIR: uploadDir,
    AUTH_SECRET: 'integration-secret-'.padEnd(40, 'x'),
    ...env
  });
  const logs = [];
  const logger = createLogger({ log: (line) => logs.push(line), error: (line) => logs.push(line) });
  const db = await createDatabase(config.databaseUrl, { schema: SCHEMA });
  await migrate(db);
  const services = createServices(config, { fetchImpl, logger });
  const ctx = { config, db, services, logger, now: now || (() => new Date()) };
  const server = http.createServer(createApp(ctx));
  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
  const base = `http://127.0.0.1:${server.address().port}`;
  const handlers = createHandlers(ctx);

  return {
    ctx, db, config, services, logs, base,
    drain: () => drainQueue({ db, handlers, config, now: ctx.now }),
    request: makeRequest(base),
    async register(label, extra = {}) {
      const email = uniqueEmail(label);
      const res = await makeRequest(base)('POST', '/api/auth/register', { body: { name: `${label} user`, email, password: 'correct-horse-1', ...extra } });
      if (res.status !== 201) throw new Error(`register failed: ${res.status} ${res.text}`);
      const cookie = res.headers.get('set-cookie').split(';')[0];
      return { id: res.json.user.id, email, token: res.json.token, cookie, auth: { Authorization: `Bearer ${res.json.token}` }, user: res.json.user };
    },
    async createListing(seller, overrides = {}) {
      const token = `Model${crypto.randomUUID().slice(0, 8)}`;
      const body = {
        make: 'Toyota', model: token, trim: 'XLI', year: 2021, price: 12500000, mileage: 45000,
        transmission: 'automatic', fuel: 'petrol', body: 'sedan', engineCc: 1800,
        region: 'Metropolitan Region', city: 'Ñuñoa', description: 'Well kept, single owner, service records.',
        ...overrides
      };
      const res = await makeRequest(base)('POST', '/api/listings', { body, headers: seller.auth });
      if (res.status !== 201) throw new Error(`create failed: ${res.status} ${res.text}`);
      return { id: res.json.item.id, model: token, item: res.json.item };
    },
    async close() {
      server.closeAllConnections();
      await new Promise((resolve) => server.close(resolve));
      if (SCHEMA) await db.exec(`DROP SCHEMA IF EXISTS ${SCHEMA} CASCADE`);
      await db.close();
      fs.rmSync(uploadDir, { recursive: true, force: true });
    }
  };
}

export function makeRequest(base) {
  return async function request(method, pathname, { body, headers = {}, raw = false } = {}) {
    const init = { method, headers: { ...headers } };
    if (body !== undefined) {
      init.headers['Content-Type'] = 'application/json';
      init.body = JSON.stringify(body);
    }
    const res = await fetch(base + pathname, init);
    if (raw) return res;
    const text = await res.text();
    let parsed = null;
    try {
      parsed = text ? JSON.parse(text) : null;
    } catch {
      parsed = null;
    }
    return { status: res.status, json: parsed, text, headers: res.headers };
  };
}
