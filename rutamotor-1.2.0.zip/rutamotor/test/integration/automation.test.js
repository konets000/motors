import test from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import { createHarness, json } from './harness.js';
import { verifyWebhookSignature } from '../../src/integrations/webhooks.js';
import * as store from '../../src/store.js';
import { enqueue } from '../../src/jobs.js';

const RESEND = { EMAIL_PROVIDER: 'resend', RESEND_API_KEY: 'key', MAIL_FROM: 'RutaMotor <n@example.test>' };

test('a new inquiry emails the seller once, with buyer text escaped', async (t) => {
  const emails = [];
  const fetchImpl = async (url, init) => {
    if (String(url).startsWith('https://api.resend.com')) {
      emails.push(JSON.parse(init.body));
      return json({ id: 'email-1' });
    }
    throw new Error(`unexpected ${url}`);
  };
  const h = await createHarness({ env: RESEND, fetchImpl });
  t.after(() => h.close());
  const seller = await h.register('notified');
  const listing = await h.createListing(seller);
  await h.request('POST', `/api/listings/${listing.id}/inquiries`, {
    body: { name: 'Eve', email: 'eve@example.test', message: '<img src=x onerror=alert(1)> is this available?', consent: true }
  });
  await h.drain();

  // The verification email sent at registration uses the same provider; only lead notifications are checked here.
  const leads = emails.filter((e) => /^New inquiry/.test(e.subject));
  assert.equal(leads.length, 1);
  assert.equal(leads[0].to[0], seller.email);
  assert.match(leads[0].subject, /New inquiry: 2021 Toyota/);
  assert.ok(leads[0].html.includes('&lt;img src=x onerror=alert(1)&gt;'), 'HTML is escaped in the email body');
  assert.ok(!leads[0].html.includes('<img'), 'no raw markup in the email');
});

test('a retried job does not send the same email twice', async (t) => {
  let emailCalls = 0;
  let whatsappCalls = 0;
  const fetchImpl = async (url, init) => {
    const u = String(url);
    if (u.startsWith('https://api.resend.com')) {
      // Only lead notifications are counted; the verification email sent at registration is not.
      if (JSON.parse(init.body).subject.startsWith('New inquiry')) emailCalls += 1;
      return json({ id: 'e' });
    }
    if (u.startsWith('https://graph.facebook.com')) {
      whatsappCalls += 1;
      return whatsappCalls === 1 ? new Response('', { status: 503 }) : json({ messages: [{ id: 'w' }] });
    }
    throw new Error(`unexpected ${u}`);
  };
  let clock = Date.now();
  const h = await createHarness({
    env: { ...RESEND, WHATSAPP_ACCESS_TOKEN: 't', WHATSAPP_PHONE_NUMBER_ID: '123', WHATSAPP_GRAPH_API_VERSION: 'v21.0' },
    fetchImpl,
    now: () => new Date(clock)
  });
  t.after(() => h.close());
  const phone = '+56912345678';
  const seller = await h.register('retry', { phone, whatsappOptIn: true });
  const listing = await h.createListing(seller);
  await h.request('POST', `/api/listings/${listing.id}/inquiries`, { body: { name: 'Ivo', email: 'ivo@example.test', message: 'Hello, still for sale?', consent: true } });

  const first = await h.drain();
  assert.equal(first.find((r) => r.job.type === 'lead.created').ok, false, 'WhatsApp failure fails the job');
  assert.equal(emailCalls, 1);

  clock += 60 * 60 * 1000;
  const second = await h.drain();
  assert.equal(second.find((r) => r.job.type === 'lead.created').ok, true, 'the retry completes');
  assert.equal(emailCalls, 1, 'the email was not sent again');
  assert.equal(whatsappCalls, 2);
});

test('a job that keeps failing is marked failed, and an admin can requeue it', async (t) => {
  const admin = `ops.${crypto.randomUUID().slice(0, 6)}@example.test`;
  const h = await createHarness({ env: { ADMIN_EMAILS: admin, ...RESEND }, fetchImpl: async () => new Response('', { status: 500 }) });
  t.after(() => h.close());
  const seller = await h.register('failing');
  const listing = await h.createListing(seller);
  await h.request('POST', `/api/listings/${listing.id}/inquiries`, { body: { name: 'Bo', email: 'bo@example.test', message: 'Are you there?', consent: true } });

  for (let attempt = 0; attempt < 8; attempt += 1) {
    await h.db.execute("UPDATE jobs SET run_at = $1 WHERE status = 'queued'", [new Date(0).toISOString()]);
    await h.drain();
  }
  const failed = await h.db.query("SELECT id, status, attempts, last_error FROM jobs WHERE type = 'lead.created' AND status = 'failed' ORDER BY updated_at DESC LIMIT 1");
  assert.equal(failed.length, 1, 'the job stopped retrying');
  assert.equal(Number(failed[0].attempts), 6);
  assert.match(failed[0].last_error, /HTTP 500/);

  const adminUser = await h.request('POST', '/api/auth/register', { body: { name: 'Ops', email: admin, password: 'correct-horse-1' } });
  const auth = { Authorization: `Bearer ${adminUser.json.token}` };
  const listed = await h.request('GET', '/api/admin/jobs?status=failed', { headers: auth });
  assert.ok(listed.json.items.some((job) => job.id === failed[0].id));
  const retried = await h.request('POST', `/api/admin/jobs/${failed[0].id}/retry`, { headers: auth });
  assert.equal(retried.status, 200);
  assert.equal((await h.request('POST', `/api/admin/jobs/${failed[0].id}/retry`, { headers: auth })).status, 409, 'only failed jobs can be retried');
});

test('unknown job types fail permanently without retrying', async (t) => {
  const h = await createHarness();
  t.after(() => h.close());
  await enqueue(h.db, 'does.not.exist', {}, { now: new Date() });
  const results = await h.drain();
  const result = results.find((r) => r.job.type === 'does.not.exist');
  assert.equal(result.ok, false);
  assert.equal(result.status, 'failed', 'permanent errors are not retried');
});

test('jobs left running by a crashed worker are recovered after the lock expires', async (t) => {
  const h = await createHarness();
  t.after(() => h.close());
  const seller = await h.register('crashed');
  const listing = await h.createListing(seller);
  const inquiry = await h.request('POST', `/api/listings/${listing.id}/inquiries`, { body: { name: 'Cy', email: 'cy@example.test', message: 'Hi there friend', consent: true } });
  assert.equal(inquiry.status, 201);

  // Simulate a worker that claimed a job and then died: status running, lock taken long ago.
  const stale = new Date(Date.now() - 3 * 60 * 60 * 1000).toISOString();
  await h.db.execute("UPDATE jobs SET status = 'running', locked_at = $1, attempts = 1 WHERE status = 'queued' AND type = 'lead.created'", [stale]);
  const recovered = await h.drain();
  assert.ok(recovered.some((r) => r.job.type === 'lead.created' && r.ok), 'the abandoned job was picked up and completed');
});

test('stale listings get a reminder once per month', async (t) => {
  const emails = [];
  const fetchImpl = async (url, init) => {
    emails.push(JSON.parse(init.body));
    return json({ id: 'r' });
  };
  const h = await createHarness({ env: RESEND, fetchImpl });
  t.after(() => h.close());
  const seller = await h.register('stale');
  const listing = await h.createListing(seller);
  const old = new Date(Date.now() - 120 * 24 * 60 * 60 * 1000).toISOString();
  await h.db.execute('UPDATE listings SET published_at = $1 WHERE id = $2', [old, listing.id]);

  const { createHandlers } = await import('../../src/jobs.js');
  const handlers = createHandlers(h.ctx);
  const found = await handlers['listing.stale_check']({}, { job: { attempts: 1, maxAttempts: 6 } });
  assert.ok(found >= 1);
  await h.drain();
  const mine = emails.filter((e) => e.to[0] === seller.email && /still for sale/.test(e.subject));
  assert.equal(mine.length, 1);
  assert.match(mine[0].subject, /still for sale/);

  await handlers['listing.stale_check']({}, { job: { attempts: 1, maxAttempts: 6 } });
  await h.drain();
  assert.equal(emails.filter((e) => e.to[0] === seller.email && /still for sale/.test(e.subject)).length, 1, 'deduplicated within the month');

  await h.request('POST', `/api/listings/${listing.id}/renew`, { headers: seller.auth });
  const renewed = await h.db.query('SELECT published_at, last_reminded_at FROM listings WHERE id = $1', [listing.id]);
  assert.equal(renewed[0].last_reminded_at, null, 'renewing clears the reminder marker');
});

test('webhooks are delivered with a signature the receiver can verify', async (t) => {
  const deliveries = [];
  const fetchImpl = async (url, init) => {
    if (String(url) === 'https://hooks.example.test/rutamotor') {
      deliveries.push({ headers: init.headers, body: init.body });
      return new Response('', { status: 204 });
    }
    throw new Error(`unexpected ${url}`);
  };
  const h = await createHarness({ env: { WEBHOOK_URL: 'https://hooks.example.test/rutamotor', WEBHOOK_SECRET: 'whsec-test' }, fetchImpl });
  t.after(() => h.close());
  const seller = await h.register('hooks');
  await h.createListing(seller);
  await h.drain();

  const created = deliveries.find((d) => JSON.parse(d.body).event === 'listing.created');
  assert.ok(created, 'listing.created was delivered');
  assert.equal(created.headers['X-RutaMotor-Event'], 'listing.created');
  assert.equal(verifyWebhookSignature('whsec-test', created.headers['X-RutaMotor-Signature'], created.body), true);
  assert.equal(verifyWebhookSignature('wrong', created.headers['X-RutaMotor-Signature'], created.body), false);
  const payload = JSON.parse(created.body);
  assert.equal(payload.data.buyerEmail, undefined, 'payloads carry no buyer personal data');
  assert.equal(payload.data.sellerId, undefined);
});

test('processing the same lead twice notifies the seller only once', async (t) => {
  const emails = [];
  const fetchImpl = async (url, init) => {
    emails.push(JSON.parse(init.body));
    return json({ id: 'e' });
  };
  const h = await createHarness({ env: RESEND, fetchImpl });
  t.after(() => h.close());
  const seller = await h.register('dedupe');
  const listing = await h.createListing(seller);
  const sent = await h.request('POST', `/api/listings/${listing.id}/inquiries`, { body: { name: 'Di', email: 'di@example.test', message: 'Hi there, price?', consent: true } });
  const inquiryId = sent.json.id;

  // Duplicate delivery of the same job (e.g. after a lost acknowledgement).
  await enqueue(h.db, 'lead.created', { inquiryId }, { now: new Date() });
  await h.drain();
  await enqueue(h.db, 'lead.created', { inquiryId }, { now: new Date() });
  await h.drain();

  assert.equal(emails.filter((e) => e.to[0] === seller.email && /^New inquiry/.test(e.subject)).length, 1);
});
