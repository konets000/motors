import test from 'node:test';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import { createHarness, PNG_1x1, json } from './harness.js';

test('seller publishes a car, uploads a photo, and buyers find it', async (t) => {
  const h = await createHarness();
  t.after(() => h.close());
  const seller = await h.register('seller');
  const listing = await h.createListing(seller);

  const photo = await h.request('POST', `/api/listings/${listing.id}/photos`, {
    headers: seller.auth, body: { filename: 'front.png', dataBase64: PNG_1x1.toString('base64') }
  });
  assert.equal(photo.status, 201);
  assert.equal(photo.json.photo.contentType, 'image/png');

  const detail = await h.request('GET', `/api/listings/${listing.id}`);
  assert.equal(detail.status, 200);
  assert.equal(detail.json.photos.length, 1);
  assert.equal(detail.json.isOwner, false);

  const media = await h.request('GET', photo.json.photo.url, { raw: true });
  assert.equal(media.status, 200);
  assert.equal(media.headers.get('content-type'), 'image/png');
  assert.equal(media.headers.get('x-content-type-options'), 'nosniff');
  assert.deepEqual(Buffer.from(await media.arrayBuffer()), PNG_1x1);

  const search = await h.request('GET', `/api/listings?q=${listing.model}&sort=priceAsc`);
  assert.equal(search.status, 200);
  assert.equal(search.json.total, 1);
  assert.equal(search.json.items[0].coverPhotoId, photo.json.photo.id);
});

test('search filters combine and reject bad values', async (t) => {
  const h = await createHarness();
  t.after(() => h.close());
  const seller = await h.register('filters');
  const cheap = await h.createListing(seller, { price: 4000000, transmission: 'manual', fuel: 'diesel', body: 'hatchback' });
  const pricey = await h.createListing(seller, { price: 25000000, body: 'suv' });

  const cheapOnly = await h.request('GET', `/api/listings?maxPrice=5000000&transmission=manual&fuel=diesel`);
  assert.deepEqual(cheapOnly.json.items.map((item) => item.id), [cheap.id]);
  const suvs = await h.request('GET', `/api/listings?body=suv&minPrice=`);
  assert.ok(suvs.json.items.some((item) => item.id === pricey.id));
  assert.equal((await h.request('GET', '/api/listings?body=truck')).status, 422);
  // LIKE wildcards in user input are literal characters, not patterns.
  assert.equal((await h.request('GET', '/api/listings?q=%25%25%25')).json.total, 0);
});

test('buyer inquiries require consent and are validated before anything is saved', async (t) => {
  const h = await createHarness();
  t.after(() => h.close());
  const seller = await h.register('consent');
  const listing = await h.createListing(seller);
  const before = await h.request('GET', '/api/me/inquiries', { headers: seller.auth });

  const refused = await h.request('POST', `/api/listings/${listing.id}/inquiries`, {
    body: { name: 'Luis', email: 'luis@example.test', message: 'Is it available?', consent: false }
  });
  assert.equal(refused.status, 422);
  assert.match(JSON.stringify(refused.json.details), /Consent is required/);

  const after = await h.request('GET', '/api/me/inquiries', { headers: seller.auth });
  assert.equal(after.json.total, before.json.total, 'nothing was saved');
});

test('inquiries reach the seller and the CSV export neutralises formulas', async (t) => {
  const h = await createHarness();
  t.after(() => h.close());
  const seller = await h.register('csv');
  const listing = await h.createListing(seller);
  const sent = await h.request('POST', `/api/listings/${listing.id}/inquiries`, {
    body: { name: '=cmd|"/c calc"!A1', email: 'buyer@example.test', phone: '+56 9 1234 5678', message: 'Hello, is this still available?', consent: true }
  });
  assert.equal(sent.status, 201);

  const mine = await h.request('GET', '/api/me/inquiries', { headers: seller.auth });
  assert.equal(mine.json.total >= 1, true);
  const csv = await h.request('GET', '/api/me/inquiries.csv', { headers: seller.auth, raw: true });
  assert.equal(csv.status, 200);
  assert.match(csv.headers.get('content-disposition'), /attachment/);
  const text = await csv.text();
  assert.ok(text.includes("'=cmd|"), 'formula is prefixed');
  assert.ok(text.includes("'+56 9 1234 5678"), 'phone is neutralised');
  assert.ok(text.includes('"Hello, is this still available?"'), 'comma is quoted');
});

test('sellers cannot touch other sellers\' listings or inquiries', async (t) => {
  const h = await createHarness();
  t.after(() => h.close());
  const owner = await h.register('owner');
  const intruder = await h.register('intruder');
  const listing = await h.createListing(owner);
  await h.request('POST', `/api/listings/${listing.id}/inquiries`, { body: { name: 'B', email: 'b@example.test', message: 'Hello there', consent: true } });
  const inquiries = await h.request('GET', '/api/me/inquiries', { headers: owner.auth });
  const inquiryId = inquiries.json.items[0].id;

  assert.equal((await h.request('PATCH', `/api/listings/${listing.id}`, { headers: intruder.auth, body: { price: 1000000 } })).status, 404);
  assert.equal((await h.request('PATCH', `/api/listings/${listing.id}/status`, { headers: intruder.auth, body: { status: 'sold' } })).status, 404);
  assert.equal((await h.request('POST', `/api/listings/${listing.id}/renew`, { headers: intruder.auth })).status, 404);
  assert.equal((await h.request('PATCH', `/api/inquiries/${inquiryId}`, { headers: intruder.auth, body: { status: 'closed' } })).status, 404);
  assert.equal((await h.request('GET', `/api/me/inquiries`, { headers: intruder.auth })).json.total, 0);
  assert.equal((await h.request('GET', `/api/listings/${listing.id}/external`, { headers: intruder.auth })).status, 404);
});

test('listing status follows the state machine', async (t) => {
  const h = await createHarness();
  t.after(() => h.close());
  const seller = await h.register('states');
  const listing = await h.createListing(seller);
  const change = (status) => h.request('PATCH', `/api/listings/${listing.id}/status`, { headers: seller.auth, body: { status } });

  assert.equal((await change('reserved')).json.changed, true);
  assert.equal((await change('reserved')).json.changed, false, 'no-op');
  assert.equal((await change('sold')).status, 200);
  const blocked = await change('active');
  assert.equal(blocked.status, 409);
  assert.match(blocked.json.error, /sold listing cannot change to active/);
  assert.equal((await h.request('PATCH', `/api/listings/${listing.id}`, { headers: seller.auth, body: { price: 9000000 } })).status, 409, 'sold cars are frozen');
  assert.equal((await h.request('GET', `/api/listings/${listing.id}`)).status, 404, 'buyers no longer see sold cars');
  const ownerView = await h.request('GET', `/api/listings/${listing.id}`, { headers: seller.auth });
  assert.equal(ownerView.json.item.status, 'sold');
});

test('sold and archived listings are hidden from buyers', async (t) => {
  const h = await createHarness();
  t.after(() => h.close());
  const seller = await h.register('hidden');
  const listing = await h.createListing(seller);
  await h.request('PATCH', `/api/listings/${listing.id}/status`, { headers: seller.auth, body: { status: 'archived' } });
  assert.equal((await h.request('GET', `/api/listings/${listing.id}`)).status, 404);
  const owner = await h.request('GET', `/api/listings/${listing.id}`, { headers: seller.auth });
  assert.equal(owner.status, 200, 'the owner can still see it');
  assert.equal(owner.json.isOwner, true);
});

test('bad identifiers return 404 instead of crashing', async (t) => {
  const h = await createHarness();
  t.after(() => h.close());
  const seller = await h.register('ids');
  assert.equal((await h.request('GET', '/api/listings/not-a-uuid')).status, 404);
  assert.equal((await h.request('PATCH', '/api/listings/not-a-uuid', { headers: seller.auth, body: { price: 200000 } })).status, 404);
  assert.equal((await h.request('POST', '/api/listings/nope/inquiries', { body: { name: 'a', email: 'a@example.test', message: 'hello there', consent: true } })).status, 404);
  assert.equal((await h.request('GET', '/media/nope')).status, 404);
});

test('authentication: duplicate accounts, wrong passwords, expired or invalid sessions', async (t) => {
  const h = await createHarness();
  t.after(() => h.close());
  const user = await h.register('auth');
  assert.equal((await h.request('POST', '/api/auth/register', { body: { name: 'Again', email: user.email, password: 'another-long-1' } })).status, 409);
  assert.equal((await h.request('POST', '/api/auth/login', { body: { email: user.email, password: 'wrong-password-x' } })).status, 401);
  assert.equal((await h.request('POST', '/api/auth/login', { body: { email: 'nobody@example.test', password: 'wrong-password-x' } })).status, 401);
  const login = await h.request('POST', '/api/auth/login', { body: { email: user.email, password: 'correct-horse-1' } });
  assert.equal(login.status, 200);
  assert.match(login.headers.get('set-cookie'), /HttpOnly/);
  assert.match(login.headers.get('set-cookie'), /SameSite=Lax/);
  assert.equal((await h.request('GET', '/api/auth/me', { headers: { Cookie: user.cookie } })).json.user.email, user.email);
  assert.equal((await h.request('GET', '/api/auth/me', { headers: { Authorization: 'Bearer forged.token.value' } })).status, 401);
  assert.equal((await h.request('GET', '/api/auth/me')).status, 401);
});

test('cookie sessions cannot be used for cross-site writes', async (t) => {
  const h = await createHarness();
  t.after(() => h.close());
  const seller = await h.register('csrf');
  const listing = await h.createListing(seller);
  const attack = await h.request('PATCH', `/api/listings/${listing.id}/status`, {
    headers: { Cookie: seller.cookie, Origin: 'https://evil.example.test', 'Sec-Fetch-Site': 'cross-site' },
    body: { status: 'sold' }
  });
  assert.equal(attack.status, 403);
  const bearer = await h.request('PATCH', `/api/listings/${listing.id}/status`, { headers: { ...seller.auth, Origin: 'https://evil.example.test' }, body: { status: 'reserved' } });
  assert.equal(bearer.status, 200, 'bearer tokens are not subject to the cookie check');
  const sameOrigin = await h.request('PATCH', `/api/listings/${listing.id}/status`, {
    headers: { Cookie: seller.cookie, Origin: h.base, 'Sec-Fetch-Site': 'same-origin' },
    body: { status: 'active' }
  });
  assert.equal(sameOrigin.status, 200);
});

test('security headers and static files are served safely', async (t) => {
  const h = await createHarness();
  t.after(() => h.close());
  const page = await h.request('GET', '/', { raw: true });
  assert.equal(page.status, 200);
  assert.match(page.headers.get('content-security-policy'), /script-src 'self'/);
  assert.equal(page.headers.get('x-frame-options'), 'DENY');
  assert.equal(page.headers.get('x-content-type-options'), 'nosniff');
  assert.equal((await h.request('GET', '/assets/app.js', { raw: true })).status, 200);
  assert.equal((await h.request('GET', '/package.json', { raw: true })).status, 404, 'project files are not exposed');
  assert.equal((await h.request('GET', '/assets/../package.json', { raw: true })).status, 404);
  assert.equal((await h.request('GET', '/src/app.js', { raw: true })).status, 404);
  assert.equal((await h.request('GET', '/#/listings/anything', { raw: true })).status, 200, 'hash routes load the shell');
});

test('admin: only administrators reach admin routes; moderation hides a listing', async (t) => {
  const admin = `admin.${Date.now()}@example.test`;
  const h = await createHarness({ env: { ADMIN_EMAILS: admin } });
  t.after(() => h.close());
  const regular = await h.register('regular');
  const seller = await h.register('moderated');
  const listing = await h.createListing(seller);
  const adminUser = await h.request('POST', '/api/auth/register', { body: { name: 'Admin', email: admin, password: 'correct-horse-1' } });
  assert.equal(adminUser.json.user.role, 'admin');
  const adminAuth = { Authorization: `Bearer ${adminUser.json.token}` };

  assert.equal((await h.request('GET', '/api/admin/jobs', { headers: regular.auth })).status, 403);
  assert.equal((await h.request('GET', '/api/admin/jobs')).status, 401);
  assert.equal((await h.request('GET', '/api/admin/jobs', { headers: adminAuth })).status, 200);

  const moderated = await h.request('PATCH', `/api/admin/listings/${listing.id}/status`, { headers: adminAuth, body: { status: 'archived', reason: 'Duplicate of another listing' } });
  assert.equal(moderated.status, 200);
  assert.equal((await h.request('GET', `/api/listings/${listing.id}`)).status, 404);
  const audit = await h.db.query("SELECT event, metadata FROM audit_events WHERE entity_id = $1 AND event = 'listing.moderated'", [listing.id]);
  assert.equal(audit.length, 1);
  assert.match(audit[0].metadata, /Duplicate of another listing/);
});

test('AI endpoints: assistant needs configuration, descriptions fall back to facts only', async (t) => {
  const h = await createHarness();
  t.after(() => h.close());
  const user = await h.register('ai');
  const assistant = await h.request('POST', '/api/ai/assistant', { body: { message: 'Family SUV under 20 million' } });
  assert.equal(assistant.status, 503);
  const draft = await h.request('POST', '/api/ai/listing-description', {
    headers: user.auth,
    body: { make: 'Kia', model: 'Sportage', year: 2022, mileage: 22000, transmission: 'automatic', fuel: 'hybrid', body: 'suv', features: ['Reversing camera'], notes: '' }
  });
  assert.equal(draft.status, 200);
  assert.equal(draft.json.source, 'template');
  assert.match(draft.json.text, /2022 Kia Sportage with 22,000 km/);
  assert.match(draft.json.text, /Reversing camera/);
  assert.equal((await h.request('POST', '/api/ai/listing-description', { body: {} , headers: {} })).status, 401);
});

test('AI assistant answers from active listings through the configured provider', async (t) => {
  const seen = [];
  const fetchImpl = async (url, init) => {
    seen.push(JSON.parse(init.body));
    return json({ choices: [{ message: { content: 'The Corolla fits your budget.' } }] });
  };
  const h = await createHarness({ env: { AI_BASE_URL: 'https://ai.example.test/v1', AI_API_KEY: 'key', AI_MODEL: 'model' }, fetchImpl });
  t.after(() => h.close());
  const seller = await h.register('assist');
  const listing = await h.createListing(seller);
  const answer = await h.request('POST', '/api/ai/assistant', { body: { message: 'Which car is good for families?' } });
  assert.equal(answer.status, 200);
  assert.equal(answer.json.answer, 'The Corolla fits your budget.');
  const prompt = seen[0].messages[1].content;
  assert.ok(prompt.includes(listing.id), 'the model sees real listing ids');
  assert.ok(prompt.includes('availableListings'));
});

test('external publishing requires configuration, engine size and photos', async (t) => {
  const h = await createHarness({ env: { COMPRADEAUTOS_API_KEY: 'k' } });
  t.after(() => h.close());
  const seller = await h.register('external');
  const noEngine = await h.createListing(seller, { engineCc: null });
  assert.equal((await h.request('POST', `/api/listings/${noEngine.id}/publish/compradeautos`, { headers: seller.auth })).status, 422);
  const noPhoto = await h.createListing(seller);
  assert.equal((await h.request('POST', `/api/listings/${noPhoto.id}/publish/compradeautos`, { headers: seller.auth })).status, 422);
});

test('publishing a listing externally queues a job that records the external id', async (t) => {
  const calls = [];
  const fetchImpl = async (url, init = {}) => {
    const u = String(url);
    calls.push({ u, method: init.method || 'GET', body: init.body });
    if (u.endsWith('/autos/images') && init.method === 'POST') return json({ uploadUrl: 'https://uploads.example.test/o', objectKey: 'k1', method: 'PUT' });
    if (u.startsWith('https://uploads.example.test')) return new Response('', { status: 200 });
    if (u.includes('/autos/images/status')) return json({ status: 'accepted', url: 'https://cdn.example.test/1.png' });
    if (u.endsWith('/autos') && init.method === 'POST') return json({ id: 'ext-777' });
    throw new Error(`unexpected ${u}`);
  };
  const h = await createHarness({ env: { COMPRADEAUTOS_API_KEY: 'k', COMPRADEAUTOS_API_BASE_URL: 'https://api.example.test/v1' }, fetchImpl });
  t.after(() => h.close());
  const seller = await h.register('publisher');
  const listing = await h.createListing(seller);
  await h.request('POST', `/api/listings/${listing.id}/photos`, { headers: seller.auth, body: { filename: 'a.png', dataBase64: PNG_1x1.toString('base64') } });

  const queued = await h.request('POST', `/api/listings/${listing.id}/publish/compradeautos`, { headers: seller.auth });
  assert.equal(queued.status, 202);
  const again = await h.request('POST', `/api/listings/${listing.id}/publish/compradeautos`, { headers: seller.auth });
  assert.equal(again.status, 409, 'a pending publish is not queued twice');

  const results = await h.drain();
  assert.ok(results.some((r) => r.job.type === 'external.compradeautos.publish' && r.ok));
  const external = await h.request('GET', `/api/listings/${listing.id}/external`, { headers: seller.auth });
  assert.equal(external.json.items[0].status, 'published');
  assert.equal(external.json.items[0].externalId, 'ext-777');
  const posted = JSON.parse(calls.find((c) => c.u.endsWith('/autos') && c.method === 'POST').body);
  assert.equal(posted.cilindrada, 1800);
  assert.equal(posted.mostrar_correo, true);
  assert.equal(posted.mostrar_telefono, false, 'phone is hidden unless the seller opts in');

  assert.equal((await h.request('POST', `/api/listings/${listing.id}/publish/compradeautos`, { headers: seller.auth })).status, 409, 'already published');
});

test('photo uploads enforce type, size and count limits, and deletion is scoped to the listing', async (t) => {
  const h = await createHarness({ env: { MAX_PHOTOS_PER_LISTING: '2', MAX_PHOTO_BYTES: '2048' } });
  t.after(() => h.close());
  const seller = await h.register('photos');
  const listing = await h.createListing(seller);
  const other = await h.createListing(seller);
  const upload = (id, bytes) => h.request('POST', `/api/listings/${id}/photos`, {
    headers: seller.auth, body: { filename: 'p.bin', dataBase64: bytes.toString('base64') }
  });

  const notImage = await upload(listing.id, Buffer.from('<svg xmlns="http://www.w3.org/2000/svg"></svg>'));
  assert.equal(notImage.status, 422);
  assert.match(notImage.json.error, /JPEG, PNG or WebP/);

  const tooBig = await upload(listing.id, Buffer.concat([PNG_1x1, Buffer.alloc(4096)]));
  assert.equal(tooBig.status, 413);

  const first = await upload(listing.id, PNG_1x1);
  const second = await upload(listing.id, PNG_1x1);
  assert.equal(first.status, 201);
  assert.equal(second.status, 201);
  const third = await upload(listing.id, PNG_1x1);
  assert.equal(third.status, 409, 'the per-listing limit is enforced');

  const crossListing = await h.request('DELETE', `/api/listings/${other.id}/photos/${first.json.photo.id}`, { headers: seller.auth });
  assert.equal(crossListing.status, 404, 'a photo cannot be deleted through another listing');
  const removed = await h.request('DELETE', `/api/listings/${listing.id}/photos/${first.json.photo.id}`, { headers: seller.auth });
  assert.equal(removed.status, 200);
  const gone = await h.request('GET', first.json.photo.url, { raw: true });
  assert.equal(gone.status, 404);
});

test('partial listing updates change only the fields sent, and empty updates are refused', async (t) => {
  const h = await createHarness();
  t.after(() => h.close());
  const seller = await h.register('edits');
  const listing = await h.createListing(seller);
  const edited = await h.request('PATCH', `/api/listings/${listing.id}`, { headers: seller.auth, body: { price: 9900000, engineCc: null } });
  assert.equal(edited.status, 200);
  assert.equal(edited.json.item.price, 9900000);
  assert.equal(edited.json.item.engineCc, null);
  assert.equal(edited.json.item.model, listing.model, 'untouched fields keep their values');
  assert.equal((await h.request('PATCH', `/api/listings/${listing.id}`, { headers: seller.auth, body: {} })).status, 422);
  assert.equal((await h.request('PATCH', `/api/listings/${listing.id}`, { headers: seller.auth, body: { status: 'sold' } })).status, 422, 'status is changed only through /status');
});

test('search pages through results without overlap', async (t) => {
  const h = await createHarness();
  t.after(() => h.close());
  const seller = await h.register('paging');
  const tag = `Pager${crypto.randomUUID().slice(0, 6)}`;
  for (let i = 0; i < 3; i += 1) await h.createListing(seller, { make: tag, model: `M${i}`, price: 1000000 + i * 100000 });
  const first = await h.request('GET', `/api/listings?make=${tag}&sort=priceAsc&limit=2&offset=0`);
  const second = await h.request('GET', `/api/listings?make=${tag}&sort=priceAsc&limit=2&offset=2`);
  assert.equal(first.json.total, 3);
  assert.equal(first.json.items.length, 2);
  assert.equal(second.json.items.length, 1);
  const ids = [...first.json.items, ...second.json.items].map((item) => item.id);
  assert.equal(new Set(ids).size, 3, 'no duplicates across pages');
  assert.deepEqual(ids.map((id) => first.json.items.concat(second.json.items).find((item) => item.id === id).price), [1000000, 1100000, 1200000]);
});
