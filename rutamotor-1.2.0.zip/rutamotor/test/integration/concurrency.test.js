// Races that only show up when requests or processes overlap. Each test runs on SQLite and, in CI, on PostgreSQL.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import crypto from 'node:crypto';
import { createHarness, PNG_1x1 } from './harness.js';

import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { fileURLToPath } from 'node:url';
import { createDatabase } from '../../src/db.js';

const execFileAsync = promisify(execFile);

test('simultaneous photo uploads cannot exceed the per-listing limit or share a position', async (t) => {
  const h = await createHarness({ env: { MAX_PHOTOS_PER_LISTING: '10' } });
  t.after(() => h.close());
  const seller = await h.register('photos');
  const listing = await h.createListing(seller);
  const body = { filename: 'front.png', dataBase64: PNG_1x1.toString('base64') };

  const responses = await Promise.all(
    Array.from({ length: 12 }, () => h.request('POST', `/api/listings/${listing.id}/photos`, { body, headers: seller.auth }))
  );

  const created = responses.filter((r) => r.status === 201);
  assert.equal(created.length, 10, 'exactly the allowed number of photos is stored');
  assert.equal(responses.filter((r) => r.status === 409).length, 2, 'the rest are refused, not silently stored');
  const positions = created.map((r) => r.json.photo.position).sort((a, b) => a - b);
  assert.deepEqual(positions, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9], 'every photo has a distinct position');
});

// Two separate processes, as in a real deployment. Two connections in one process cannot wait on each
// other: SQLite's driver is synchronous, so the blocked thread could never release the lock.
test('two processes migrating the same database at once both succeed, and each migration is recorded once', async (t) => {
  const usePostgres = Boolean(process.env.TEST_DATABASE_URL);
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'rutamotor-migrate-'));
  const schema = usePostgres ? `t_mig_${crypto.randomUUID().replace(/-/g, '').slice(0, 12)}` : undefined;
  const url = usePostgres ? process.env.TEST_DATABASE_URL : `sqlite:${path.join(dir, 'race.db')}`;
  const databaseModule = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../../src/db.js');
  const child = `
    const { createDatabase, migrate } = await import(${JSON.stringify(databaseModule)});
    const db = await createDatabase(process.env.DB_URL, { schema: process.env.DB_SCHEMA || undefined });
    try { console.log(JSON.stringify(await migrate(db))); } finally { await db.close(); }
  `;
  const env = { ...process.env, DB_URL: url, DB_SCHEMA: schema || '' };
  const owner = await createDatabase(url, { schema });
  t.after(async () => {
    await owner.close();
    if (schema) await owner.exec(`DROP SCHEMA IF EXISTS ${schema} CASCADE`).catch(() => {});
    fs.rmSync(dir, { recursive: true, force: true });
  });

  const runs = await Promise.allSettled([
    execFileAsync(process.execPath, ['--input-type=module', '-e', child], { env }),
    execFileAsync(process.execPath, ['--input-type=module', '-e', child], { env })
  ]);
  const failures = runs.filter((r) => r.status === 'rejected').map((r) => (r.reason.stderr || r.reason.message).trim());
  assert.deepEqual(failures, [], 'neither process fails');

  const applied = (await owner.query('SELECT version FROM schema_migrations ORDER BY version')).map((row) => row.version);
  assert.deepEqual(applied, [...new Set(applied)], 'no version is recorded twice');
  assert.ok(applied.includes('001_init') && applied.includes('002_account_tokens'), 'all migrations are applied');
});
