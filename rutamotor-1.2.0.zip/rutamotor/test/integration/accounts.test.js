import test from 'node:test';
import assert from 'node:assert/strict';
import { createHarness } from './harness.js';
import { createDatabaseRateLimiter } from '../../src/rate-limit.js';

// Captures account emails sent through the job queue, so tests can read the one-time links.
function captureEmails(h) {
  const sent = [];
  h.services.email.send = async (message) => {
    sent.push(message);
    return { sent: true, reason: 'test' };
  };
  return sent;
}

const tokenFrom = (message) => {
  const match = /#\/(?:verify|reset)\/([A-Za-z0-9_-]{20,})/.exec(message.text);
  assert.ok(match, 'the email contains a one-time link');
  return match[1];
};

const VALID_LISTING = {
  make: 'Toyota', model: 'Corolla', year: 2021, price: 12500000, mileage: 45000,
  transmission: 'automatic', fuel: 'petrol', body: 'sedan',
  region: 'Metropolitan Region', city: 'Ñuñoa', description: 'Well kept, single owner, service records.'
};

test('registration emails a verification link; the raw token never reaches the database', async (t) => {
  const h = await createHarness();
  t.after(() => h.close());
  const sent = captureEmails(h);
  const user = await h.register('verify');
  await h.drain();

  assert.equal(sent.length, 1);
  assert.equal(sent[0].to, user.email);
  assert.match(sent[0].subject, /Confirm your RutaMotor email address/);
  const token = tokenFrom(sent[0]);

  const stored = JSON.stringify(await h.db.query('SELECT payload FROM jobs')) +
    JSON.stringify(await h.db.query('SELECT token_hash FROM account_tokens'));
  assert.ok(!stored.includes(token), 'the raw token is not stored in jobs or account_tokens');

  let me = await h.request('GET', '/api/auth/me', { headers: user.auth });
  assert.equal(me.json.user.emailVerified, false);
  assert.equal(me.json.user.sessionVersion, undefined, 'internal session fields are not exposed');

  const verified = await h.request('POST', '/api/auth/verify-email', { body: { token } });
  assert.equal(verified.status, 200);
  me = await h.request('GET', '/api/auth/me', { headers: user.auth });
  assert.equal(me.json.user.emailVerified, true);

  const again = await h.request('POST', '/api/auth/verify-email', { body: { token } });
  assert.equal(again.status, 400, 'a verification link works once');
});

test('verification links expire after 72 hours', async (t) => {
  let clock = new Date('2026-10-01T12:00:00Z');
  const h = await createHarness({ now: () => clock });
  t.after(() => h.close());
  const sent = captureEmails(h);
  await h.register('expiry');
  await h.drain();
  clock = new Date(clock.getTime() + 73 * 60 * 60 * 1000);
  const res = await h.request('POST', '/api/auth/verify-email', { body: { token: tokenFrom(sent[0]) } });
  assert.equal(res.status, 400);
});

test('requesting a new link revokes the previous one, and superseded links are never sent', async (t) => {
  const h = await createHarness();
  t.after(() => h.close());
  const sent = captureEmails(h);
  const user = await h.register('resend');
  // Both requests are queued before any email goes out.
  const resent = await h.request('POST', '/api/auth/resend-verification', { headers: user.auth });
  assert.equal(resent.status, 200);
  await h.drain();

  assert.equal(sent.length, 1, 'the first link was superseded before it was sent');
  const link = tokenFrom(sent[0]);
  const verified = await h.request('POST', '/api/auth/verify-email', { body: { token: link } });
  assert.equal(verified.status, 200);

  const alreadyVerified = await h.request('POST', '/api/auth/resend-verification', { headers: user.auth });
  assert.deepEqual(alreadyVerified.json, { ok: true, alreadyVerified: true });
  await h.drain();
  assert.equal(sent.length, 1, 'no email for an account that is already verified');
});

test('concurrent clicks on one link: exactly one succeeds', async (t) => {
  const h = await createHarness();
  t.after(() => h.close());
  const sent = captureEmails(h);
  await h.register('race');
  await h.drain();
  const token = tokenFrom(sent[0]);
  const results = await Promise.all([
    h.request('POST', '/api/auth/verify-email', { body: { token } }),
    h.request('POST', '/api/auth/verify-email', { body: { token } })
  ]);
  assert.deepEqual(results.map((r) => r.status).sort(), [200, 400]);
});

test('forgot-password answers the same way for known and unknown emails, and only emails the real account', async (t) => {
  const h = await createHarness();
  t.after(() => h.close());
  const sent = captureEmails(h);
  const user = await h.register('reset');
  await h.drain();
  sent.length = 0;

  const known = await h.request('POST', '/api/auth/forgot-password', { body: { email: user.email } });
  const unknown = await h.request('POST', '/api/auth/forgot-password', { body: { email: 'nobody@example.test' } });
  assert.equal(known.status, 200);
  assert.equal(unknown.status, 200);
  assert.equal(known.text, unknown.text, 'the response does not reveal whether an account exists');

  await h.drain();
  assert.equal(sent.length, 1, 'only the existing account receives a reset email');
  assert.equal(sent[0].to, user.email);
  assert.match(sent[0].subject, /Reset your RutaMotor password/);
  const token = tokenFrom(sent[0]);

  const weak = await h.request('POST', '/api/auth/reset-password', { body: { token, password: 'short' } });
  assert.equal(weak.status, 422);

  const reset = await h.request('POST', '/api/auth/reset-password', { body: { token, password: 'a-brand-new-pass-1' } });
  assert.equal(reset.status, 200);

  assert.equal((await h.request('GET', '/api/auth/me', { headers: user.auth })).status, 401, 'the old session is signed out');
  assert.equal((await h.request('POST', '/api/auth/login', { body: { email: user.email, password: 'correct-horse-1' } })).status, 401);
  const login = await h.request('POST', '/api/auth/login', { body: { email: user.email, password: 'a-brand-new-pass-1' } });
  assert.equal(login.status, 200);
  assert.equal((await h.request('GET', '/api/auth/me', { headers: { Authorization: `Bearer ${login.json.token}` } })).json.user.emailVerified, true,
    'a completed reset proves the inbox, so the email counts as verified');

  assert.equal((await h.request('POST', '/api/auth/reset-password', { body: { token, password: 'another-pass-123' } })).status, 400,
    'a reset link works once');

  await h.drain();
  assert.ok(sent.some((m) => /password was changed/.test(m.subject)), 'the account holder is told about the change');
});

test('reset links from one request are revoked by the next', async (t) => {
  const h = await createHarness();
  t.after(() => h.close());
  const sent = captureEmails(h);
  const user = await h.register('twice');
  await h.drain();
  sent.length = 0;
  await h.request('POST', '/api/auth/forgot-password', { body: { email: user.email } });
  await h.drain();
  const first = tokenFrom(sent[0]);
  await h.request('POST', '/api/auth/forgot-password', { body: { email: user.email } });
  await h.drain();
  const second = tokenFrom(sent[1]);
  assert.equal((await h.request('POST', '/api/auth/reset-password', { body: { token: first, password: 'first-new-pass-1' } })).status, 400);
  assert.equal((await h.request('POST', '/api/auth/reset-password', { body: { token: second, password: 'second-new-pass-1' } })).status, 200);
});

test('invalid or malformed tokens are rejected without revealing why', async (t) => {
  const h = await createHarness();
  t.after(() => h.close());
  const bogus = await h.request('POST', '/api/auth/verify-email', { body: { token: 'a'.repeat(43) } });
  assert.equal(bogus.status, 400);
  assert.equal((await h.request('POST', '/api/auth/verify-email', { body: { token: 'short' } })).status, 422);
  assert.equal((await h.request('POST', '/api/auth/verify-email', { body: { token: 'x'.repeat(43), extra: 1 } })).status, 422);
  assert.equal((await h.request('POST', '/api/auth/reset-password', { body: { token: 'a'.repeat(43), password: 'long-enough-pass' } })).status, 400);
});

test('a verification link cannot be used to reset a password, and vice versa', async (t) => {
  const h = await createHarness();
  t.after(() => h.close());
  const sent = captureEmails(h);
  await h.register('purpose');
  await h.drain();
  const verifyToken = tokenFrom(sent[0]);
  const res = await h.request('POST', '/api/auth/reset-password', { body: { token: verifyToken, password: 'cross-purpose-1' } });
  assert.equal(res.status, 400, 'the token purpose is checked');
});

test('with REQUIRE_VERIFIED_EMAIL, unverified sellers cannot publish until they confirm their email', async (t) => {
  const h = await createHarness({ env: { REQUIRE_VERIFIED_EMAIL: 'true' } });
  t.after(() => h.close());
  const sent = captureEmails(h);
  const seller = await h.register('gate');
  await h.drain();

  const blocked = await h.request('POST', '/api/listings', { body: VALID_LISTING, headers: seller.auth });
  assert.equal(blocked.status, 403);
  assert.match(blocked.json.error, /Verify your email address/);

  await h.request('POST', '/api/auth/verify-email', { body: { token: tokenFrom(sent[0]) } });
  const allowed = await h.request('POST', '/api/listings', { body: VALID_LISTING, headers: seller.auth });
  assert.equal(allowed.status, 201);
});

test('resend-verification is rate limited per account', async (t) => {
  const h = await createHarness();
  t.after(() => h.close());
  const user = await h.register('spam');
  const statuses = [];
  for (let i = 0; i < 4; i += 1) {
    statuses.push((await h.request('POST', '/api/auth/resend-verification', { headers: user.auth })).status);
  }
  assert.deepEqual(statuses, [200, 200, 200, 429]);
});

test('database rate limits are shared by every instance using the same database', async (t) => {
  const h = await createHarness();
  t.after(() => h.close());
  let clock = Date.parse('2026-10-01T12:00:00Z');
  const instanceA = createDatabaseRateLimiter(h.db, { now: () => clock });
  const instanceB = createDatabaseRateLimiter(h.db, { now: () => clock });
  const outcomes = [];
  outcomes.push((await instanceA.hit('shared', 2, 60_000)).allowed);
  outcomes.push((await instanceB.hit('shared', 2, 60_000)).allowed);
  outcomes.push((await instanceA.hit('shared', 2, 60_000)).allowed);
  assert.deepEqual(outcomes, [true, true, false], 'the third hit is blocked across both instances');

  clock += 61_000;
  assert.equal((await instanceB.hit('shared', 2, 60_000)).allowed, true, 'a new window starts after the reset time');
});

test('RATE_LIMIT_STORE=database enforces the same login limit through the API', async (t) => {
  const h = await createHarness({ env: { RATE_LIMIT_STORE: 'database' } });
  t.after(() => h.close());
  const statuses = [];
  for (let i = 0; i < 11; i += 1) {
    statuses.push((await h.request('POST', '/api/auth/login', { body: { email: 'nobody@example.test', password: 'whatever-pass' } })).status);
  }
  assert.equal(statuses.slice(0, 10).every((status) => status === 401), true);
  assert.equal(statuses[10], 429);
});

test('sign out everywhere ends every session of the account, including tokens copied elsewhere', async (t) => {
  const h = await createHarness();
  t.after(() => h.close());
  const user = await h.register('everywhere');
  const laptop = await h.request('POST', '/api/auth/login', { body: { email: user.email, password: 'correct-horse-1' } });
  const phone = await h.request('POST', '/api/auth/login', { body: { email: user.email, password: 'correct-horse-1' } });
  const laptopAuth = { Authorization: `Bearer ${laptop.json.token}` };
  const phoneAuth = { Authorization: `Bearer ${phone.json.token}` };
  assert.equal((await h.request('GET', '/api/auth/me', { headers: phoneAuth })).status, 200);

  const revoked = await h.request('POST', '/api/auth/sessions/revoke-all', { headers: laptopAuth });
  assert.equal(revoked.status, 200);
  assert.match(revoked.headers.get('set-cookie'), /Max-Age=0/, 'this browser is signed out too');

  assert.equal((await h.request('GET', '/api/auth/me', { headers: phoneAuth })).status, 401, 'the phone session is over');
  assert.equal((await h.request('GET', '/api/auth/me', { headers: laptopAuth })).status, 401, 'the laptop session is over');
  assert.equal((await h.request('POST', '/api/auth/sessions/revoke-all')).status, 401, 'signing out everywhere needs a session');

  const fresh = await h.request('POST', '/api/auth/login', { body: { email: user.email, password: 'correct-horse-1' } });
  assert.equal(fresh.status, 200, 'the password still works; only the sessions changed');
});
