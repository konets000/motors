// Operational behaviour: request tracing and data retention.
import test from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import { createHarness } from './harness.js';
import { createHandlers } from '../../src/jobs.js';

const DAY = 86_400_000;

test('every response carries a request ID, and clients can supply their own', async (t) => {
  const h = await createHarness();
  t.after(() => h.close());
  const generated = await fetch(`${h.base}/api/health`);
  assert.match(generated.headers.get('x-request-id'), /^[0-9a-f-]{36}$/);

  const supplied = await fetch(`${h.base}/api/health`, { headers: { 'X-Request-Id': 'lb-7f3a.42' } });
  assert.equal(supplied.headers.get('x-request-id'), 'lb-7f3a.42');

  const unsafe = await fetch(`${h.base}/api/health`, { headers: { 'X-Request-Id': 'bad id/with spaces' } });
  assert.match(unsafe.headers.get('x-request-id'), /^[0-9a-f-]{36}$/, 'unsafe IDs are replaced, not echoed');
});

test('each request writes one completion line with the status, path and duration, and no query string', async (t) => {
  const h = await createHarness();
  t.after(() => h.close());
  await fetch(`${h.base}/api/listings?q=secret-search-term`, { headers: { 'X-Request-Id': 'trace-1' } });
  const lines = h.logs.map((line) => JSON.parse(line)).filter((entry) => entry.event === 'request.completed' && entry.requestId === 'trace-1');
  assert.equal(lines.length, 1);
  assert.equal(lines[0].path, '/api/listings');
  assert.equal(lines[0].status, 200);
  assert.equal(lines[0].method, 'GET');
  assert.equal(typeof lines[0].durationMs, 'number');
  assert.ok(!h.logs.some((line) => line.includes('secret-search-term')), 'search text is not logged');
});

test('retention removes finished jobs and long-expired links, and keeps everything still useful', async (t) => {
  let clock = new Date('2026-10-01T12:00:00Z');
  const h = await createHarness({ now: () => clock });
  t.after(() => h.close());
  const seller = await h.register('retention');
  const now = clock.toISOString();
  const old = new Date(clock.getTime() - 40 * DAY).toISOString();
  const recent = new Date(clock.getTime() - 2 * DAY).toISOString();

  const insertJob = (id, status, updatedAt) => h.db.execute(
    `INSERT INTO jobs (id, type, payload, status, attempts, max_attempts, run_at, created_at, updated_at)
     VALUES ($1, 'noop', '{}', $2, 1, 6, $3, $3, $3)`, [id, status, updatedAt]);
  await insertJob('job-old-done', 'done', old);
  await insertJob('job-recent-done', 'done', recent);
  await insertJob('job-old-failed', 'failed', old);

  const insertToken = (id, expiresAt) => h.db.execute(
    `INSERT INTO account_tokens (id, user_id, purpose, token_hash, expires_at, created_at)
     VALUES ($1, $2, 'verify_email', $3, $4, $5)`, [id, seller.id, crypto.randomUUID(), expiresAt, now]);
  await insertToken('token-long-expired', new Date(clock.getTime() - 10 * DAY).toISOString());
  await insertToken('token-just-expired', new Date(clock.getTime() - 1 * DAY).toISOString());

  const handlers = createHandlers(h.ctx);
  const result = await handlers['maintenance.prune']({}, { job: {} });
  assert.deepEqual(result, { jobs: 1, accountTokens: 1 });

  const jobIds = (await h.db.query('SELECT id FROM jobs ORDER BY id')).map((row) => row.id);
  assert.ok(!jobIds.includes('job-old-done'), 'old finished job removed');
  assert.ok(jobIds.includes('job-recent-done'), 'recent finished job kept');
  assert.ok(jobIds.includes('job-old-failed'), 'failed jobs are kept for administrators');
  const tokenIds = (await h.db.query('SELECT id FROM account_tokens ORDER BY id')).map((row) => row.id);
  assert.ok(!tokenIds.includes('token-long-expired'), 'long-expired link removed');
  assert.ok(tokenIds.includes('token-just-expired'), 'recently expired link kept for a while');
});

test('the browser reads the photo limits the server enforces, so the two cannot drift apart', async (t) => {
  const h = await createHarness({ env: { MAX_PHOTO_BYTES: '1234567', MAX_PHOTOS_PER_LISTING: '4' } });
  t.after(() => h.close());
  const facets = await h.request('GET', '/api/facets');
  assert.deepEqual(facets.json.limits, { maxPhotoBytes: 1234567, maxPhotosPerListing: 4 });
});
