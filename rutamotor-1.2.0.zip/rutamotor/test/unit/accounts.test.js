import test from 'node:test';
import assert from 'node:assert/strict';
import { accountLink, renderAccountEmail, ACCOUNT_TOKEN_TTL_MS } from '../../src/accounts.js';
import { hashToken, newToken, sealText, openText, verifyToken, signToken } from '../../src/security.js';

test('links point the SPA at the right route, with the token in the fragment', () => {
  assert.equal(accountLink('https://rutamotor.example.test', 'verify_email', 'abc'), 'https://rutamotor.example.test/#/verify/abc');
  assert.equal(accountLink('https://rutamotor.example.test', 'reset_password', 'abc'), 'https://rutamotor.example.test/#/reset/abc');
});

test('token lifetimes: 72 hours to verify, one hour to reset', () => {
  assert.equal(ACCOUNT_TOKEN_TTL_MS.verify_email, 72 * 60 * 60 * 1000);
  assert.equal(ACCOUNT_TOKEN_TTL_MS.reset_password, 60 * 60 * 1000);
});

test('account emails escape the recipient name and keep the link as text and href', () => {
  const message = renderAccountEmail('reset_password', { name: '<b>Ana</b>', link: 'https://x.test/#/reset/tok"en' });
  assert.match(message.subject, /Reset your RutaMotor password/);
  assert.ok(message.text.includes('https://x.test/#/reset/tok"en'), 'plain text keeps the link unchanged');
  assert.ok(message.html.includes('Hi &lt;b&gt;Ana&lt;/b&gt;,'), 'greeting is escaped');
  assert.ok(message.html.includes('href="https://x.test/#/reset/tok&quot;en"'), 'quotes in the link are escaped in the href');
  assert.ok(!message.html.includes('<b>'), 'no raw markup in the HTML body');
});

test('the password-change notice has no link', () => {
  const message = renderAccountEmail('password_changed', { name: 'Ana' });
  assert.match(message.subject, /password was changed/);
  assert.ok(!message.text.includes('http'));
  assert.ok(!message.html.includes('<a '));
});

test('unknown account email kinds are rejected', () => {
  assert.throws(() => renderAccountEmail('nope', { name: 'x' }), /Unknown account email/);
});

test('new tokens are long, URL-safe and unique', () => {
  const a = newToken();
  const b = newToken();
  assert.match(a, /^[A-Za-z0-9_-]{43}$/);
  assert.notEqual(a, b);
});

test('hashToken is deterministic and never equals the token', () => {
  const token = newToken();
  assert.equal(hashToken(token), hashToken(token));
  assert.match(hashToken(token), /^[a-f0-9]{64}$/);
  assert.notEqual(hashToken(token), token);
});

test('sealed text opens with the right secret and nothing else', () => {
  const secret = 'x'.repeat(32);
  const sealed = sealText('secret-token-value', secret);
  assert.equal(openText(sealed, secret), 'secret-token-value');
  assert.equal(openText(sealed, 'y'.repeat(32)), null, 'a different secret cannot open it');
  assert.ok(!sealed.includes('secret-token-value'), 'the plaintext is not visible');
  assert.notEqual(sealText('same', secret), sealText('same', secret), 'every seal uses a fresh nonce');
});

test('tampered or malformed sealed text is rejected', () => {
  const secret = 'x'.repeat(32);
  const [iv, tag, data] = sealText('value', secret).split('.');
  const flipped = Buffer.from(data, 'base64url');
  flipped[0] ^= 0x01;
  assert.equal(openText(`${iv}.${tag}.${flipped.toString('base64url')}`, secret), null);
  assert.equal(openText('not-sealed', secret), null);
  assert.equal(openText(undefined, secret), null);
});

test('sessions carry a version; a changed version fails verification', () => {
  const secret = 'x'.repeat(32);
  const token = signToken({ sub: 'u1', role: 'user', v: 0 }, secret, 60, 1000);
  assert.equal(verifyToken(token, secret, 1000).v, 0);
});
