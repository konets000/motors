import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { devAuthSecret } from '../../src/bootstrap.js';

test('development processes share one secret, created on first use', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'rutamotor-secret-'));
  try {
    const first = devAuthSecret(dir);
    const second = devAuthSecret(dir); // e.g. the worker starting after the API
    assert.equal(first, second);
    assert.match(first, /^[a-f0-9]{64}$/);
    assert.equal(fs.readFileSync(path.join(dir, '.dev-auth-secret'), 'utf8').trim(), first);
  } finally {
    fs.rmSync(dir, { recursive: true, force: true });
  }
});

test('the secret is only ever read from the existing file, never regenerated', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'rutamotor-secret-'));
  try {
    fs.writeFileSync(path.join(dir, '.dev-auth-secret'), 'a'.repeat(64));
    assert.equal(devAuthSecret(dir), 'a'.repeat(64));
  } finally {
    fs.rmSync(dir, { recursive: true, force: true });
  }
});
