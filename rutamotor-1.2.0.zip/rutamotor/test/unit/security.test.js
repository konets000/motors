import test from 'node:test';
import assert from 'node:assert/strict';
import { hashPassword, verifyPassword, signToken, verifyToken } from '../../src/security.js';

test('hashes passwords with scrypt and verifies them', async () => {
  const stored = await hashPassword('correct-horse-battery');
  assert.match(stored, /^scrypt\$16384\$8\$1\$/);
  assert.equal(await verifyPassword('correct-horse-battery', stored), true);
  assert.equal(await verifyPassword('wrong-password-here', stored), false);
});

test('uses a fresh salt for every hash', async () => {
  assert.notEqual(await hashPassword('same-password-1'), await hashPassword('same-password-1'));
});

test('rejects malformed stored hashes without throwing', async () => {
  assert.equal(await verifyPassword('anything', ''), false);
  assert.equal(await verifyPassword('anything', 'bcrypt$whatever'), false);
  assert.equal(await verifyPassword('anything', 'scrypt$16384$8$1$'), false);
});

const SECRET = 'a'.repeat(40);

test('verifies a freshly signed token and returns its claims', () => {
  const now = 1_700_000_000;
  const token = signToken({ sub: 'user-1', role: 'user' }, SECRET, 3600, now);
  const claims = verifyToken(token, SECRET, now + 10);
  assert.equal(claims.sub, 'user-1');
  assert.equal(claims.role, 'user');
});

test('rejects tokens that were tampered with, signed with another secret, or expired', () => {
  const now = 1_700_000_000;
  const token = signToken({ sub: 'user-1', role: 'user' }, SECRET, 60, now);
  const [header, payload, signature] = token.split('.');
  const forged = Buffer.from(JSON.stringify({ sub: 'admin', role: 'admin', exp: now + 9999 })).toString('base64url');
  assert.equal(verifyToken(`${header}.${forged}.${signature}`, SECRET, now), null, 'payload tampering');
  assert.equal(verifyToken(token, 'b'.repeat(40), now), null, 'wrong secret');
  assert.equal(verifyToken(token, SECRET, now + 61), null, 'expired');
  assert.equal(verifyToken('not-a-token', SECRET, now), null, 'garbage');
  assert.equal(verifyToken(`${header}.${payload}`, SECRET, now), null, 'missing signature');
});
