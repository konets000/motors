import test from 'node:test';
import assert from 'node:assert/strict';
import { signWebhook, verifyWebhookSignature, createWebhookSender } from '../../src/integrations/webhooks.js';
import { createAiService, templateDescription } from '../../src/integrations/ai.js';
import { createEmailService } from '../../src/integrations/email.js';
import { createWhatsAppService } from '../../src/integrations/whatsapp.js';
import { createCompraDeAutosClient } from '../../src/integrations/compradeautos.js';

const json = (data, status = 200) => new Response(JSON.stringify(data), { status, headers: { 'content-type': 'application/json' } });

test('webhook signatures verify, reject tampering and expire', () => {
  const body = '{"event":"listing.created"}';
  const now = 1_700_000_000;
  const header = `t=${now},v1=${signWebhook('whsec', now, body)}`;
  assert.equal(verifyWebhookSignature('whsec', header, body, { nowSeconds: now + 5 }), true);
  assert.equal(verifyWebhookSignature('whsec', header, `${body} `, { nowSeconds: now + 5 }), false, 'body changed');
  assert.equal(verifyWebhookSignature('other', header, body, { nowSeconds: now + 5 }), false, 'wrong secret');
  assert.equal(verifyWebhookSignature('whsec', header, body, { nowSeconds: now + 3600 }), false, 'stale');
  assert.equal(verifyWebhookSignature('whsec', 'garbage', body, { nowSeconds: now }), false);
});

test('webhook sender posts a signed JSON body and fails on non-2xx responses', async () => {
  const calls = [];
  const fetchImpl = async (url, init) => {
    calls.push({ url, init });
    return new Response('', { status: calls.length === 1 ? 200 : 500 });
  };
  const sender = createWebhookSender({ url: 'https://hooks.example.test/rm', secret: 's3cret', fetchImpl, now: () => 1_700_000_000_000 });
  await sender.deliver({ deliveryId: 'd-1', event: 'listing.created', data: { listingId: 'l-1' } });
  const sent = calls[0];
  assert.equal(sent.init.headers['X-RutaMotor-Event'], 'listing.created');
  assert.equal(sent.init.headers['X-RutaMotor-Delivery'], 'd-1');
  assert.equal(sent.init.redirect, 'error', 'redirects are refused');
  assert.equal(verifyWebhookSignature('s3cret', sent.init.headers['X-RutaMotor-Signature'], sent.init.body, { nowSeconds: 1_700_000_000 }), true);
  await assert.rejects(sender.deliver({ deliveryId: 'd-2', event: 'x', data: {} }), /HTTP 500/);
});

test('AI description falls back to a facts-only template when unconfigured', async () => {
  const ai = createAiService({ baseUrl: '', apiKey: '', model: '' });
  const result = await ai.describeListing({ year: 2021, make: 'Toyota', model: 'Corolla', mileage: 45000, transmission: 'automatic', fuel: 'petrol', features: ['Backup camera'], notes: '' });
  assert.equal(result.source, 'template');
  assert.match(result.text, /^2021 Toyota Corolla with 45,000 km, automatic transmission and a petrol engine\./);
  assert.match(result.text, /Backup camera/);
  assert.equal(templateDescription({ year: 2020, make: 'Kia', model: 'Rio', mileage: 1, transmission: 'manual', fuel: 'diesel', features: [] }).includes('undefined'), false);
});

test('AI description uses the provider and falls back on failure', async () => {
  const facts = { year: 2020, make: 'Kia', model: 'Rio', mileage: 1000, transmission: 'manual', fuel: 'diesel', features: [] };
  const ok = createAiService({ baseUrl: 'https://ai.example.test/v1', apiKey: 'k', model: 'm', fetchImpl: async () => json({ choices: [{ message: { content: '  Clean Rio.  ' } }] }) });
  assert.deepEqual(await ok.describeListing(facts), { text: 'Clean Rio.', source: 'ai' });
  const down = createAiService({ baseUrl: 'https://ai.example.test/v1', apiKey: 'k', model: 'm', fetchImpl: async () => new Response('', { status: 500 }) });
  const fallback = await down.describeListing(facts);
  assert.equal(fallback.source, 'template');
  assert.ok(fallback.fallbackReason);
});

test('AI assistant refuses to answer when unconfigured', async () => {
  const ai = createAiService({ baseUrl: '', apiKey: '', model: '' });
  await assert.rejects(ai.answer('Hi', []), (error) => error.status === 503);
});

test('email: log provider never sends network traffic; resend sends one request', async () => {
  const logged = [];
  const logger = { info: (event, fields) => logged.push({ event, ...fields }) };
  const logEmail = createEmailService({ provider: 'log', logger });
  assert.equal((await logEmail.send({ to: 'maria@example.com', subject: 'Hi' })).sent, true);
  assert.equal(logged[0].to, 'm***@example.com', 'recipient is masked in logs');

  const calls = [];
  const resend = createEmailService({ provider: 'resend', resendApiKey: 'key', from: 'RM <n@example.com>', fetchImpl: async (url, init) => { calls.push({ url, init }); return json({ id: '1' }); } });
  assert.equal((await resend.send({ to: 'a@example.com', subject: 'S', html: '<p>x</p>', text: 'x' })).sent, true);
  assert.equal(calls.length, 1);
  assert.equal(calls[0].url, 'https://api.resend.com/emails');
  const unconfigured = createEmailService({ provider: 'resend', fetchImpl: async () => { throw new Error('must not call'); } });
  assert.equal((await unconfigured.send({ to: 'a@example.com', subject: 'S', text: 'x' })).reason, 'email_not_configured');
});

test('whatsapp is skipped when unconfigured and validates the Graph API version', async () => {
  const off = createWhatsAppService({});
  assert.deepEqual(await off.sendTemplate({ to: '+56 9 1234 5678', template: 't' }), { sent: false, reason: 'whatsapp_not_configured' });
  const bad = createWhatsAppService({ accessToken: 't', phoneNumberId: '1', graphVersion: 'latest', fetchImpl: async () => json({}) });
  await assert.rejects(bad.sendTemplate({ to: '+56912345678', template: 't' }), /must look like v21\.0/);
});

test('CompraDeAutos publish: uploads, waits for validation, and posts the listing', async () => {
  const seen = [];
  let statusChecks = 0;
  const fetchImpl = async (url, init = {}) => {
    const u = String(url);
    seen.push({ method: init.method || 'GET', url: u, body: init.body });
    if (u.endsWith('/autos/images') && init.method === 'POST') return json({ uploadUrl: 'https://uploads.example.test/o/1', objectKey: 'obj-1', method: 'PUT' });
    if (u.startsWith('https://uploads.example.test/')) return new Response('', { status: 200 });
    if (u.includes('/autos/images/status')) {
      statusChecks += 1;
      return statusChecks < 2 ? json({ status: 'processing' }, 202) : json({ status: 'accepted', url: 'https://cdn.example.test/1.jpg' });
    }
    if (u.endsWith('/autos') && init.method === 'POST') return json({ id: 'ext-42', message: 'ok' });
    throw new Error(`unexpected ${u}`);
  };
  const client = createCompraDeAutosClient({ apiKey: 'k', baseUrl: 'https://api.example.test/v1', fetchImpl, pollIntervalMs: 0, sleep: async () => {} });
  const result = await client.publish({
    listing: { make: 'Toyota', model: 'Corolla', year: 2021, price: 12500000, mileage: 45000, fuel: 'hybrid', transmission: 'automatic', region: 'R', city: 'C', engineCc: 1800, description: 'd' },
    photos: [{ fileName: 'a.jpg', mimeType: 'image/jpeg', bytes: Buffer.from([1, 2, 3]), isMain: true }],
    contact: { showEmail: true }
  });
  assert.deepEqual(result, { externalId: 'ext-42', message: 'ok' });
  const payload = JSON.parse(seen.at(-1).body);
  assert.equal(payload.cilindrada, 1800);
  assert.equal(payload.tipo_combustible, 'Híbrido');
  assert.equal(payload.transmision, 'Automática');
  assert.equal(payload.imagen_url[0].is_main, true);
});

test('CompraDeAutos refuses incomplete listings as permanent errors', async () => {
  const client = createCompraDeAutosClient({ apiKey: 'k', baseUrl: 'https://api.example.test/v1', fetchImpl: async () => { throw new Error('must not call'); } });
  const base = { make: 'Toyota', model: 'Corolla', year: 2021, price: 12500000, mileage: 1, fuel: 'petrol', transmission: 'manual', region: 'R', city: 'C', description: 'd' };
  const photos = [{ fileName: 'a.jpg', mimeType: 'image/jpeg', bytes: Buffer.from([1]) }];
  await assert.rejects(client.publish({ listing: { ...base, engineCc: null }, photos, contact: { showEmail: true } }), (e) => e.permanent === true && /cc/.test(e.message));
  await assert.rejects(client.publish({ listing: { ...base, engineCc: 1000 }, photos: [], contact: { showEmail: true } }), (e) => e.permanent === true);
  await assert.rejects(client.publish({ listing: { ...base, engineCc: 1000 }, photos, contact: {} }), (e) => e.permanent === true);
});
