import test from 'node:test';
import assert from 'node:assert/strict';
import { canChangeListingStatus, csvCell, toCsv, escapeHtml, maskEmail, formatMoney, LISTING_TRANSITIONS } from '../../src/domain.js';

test('listing status transitions', () => {
  assert.equal(canChangeListingStatus('active', 'reserved'), true);
  assert.equal(canChangeListingStatus('reserved', 'active'), true);
  assert.equal(canChangeListingStatus('archived', 'active'), true);
  assert.equal(canChangeListingStatus('sold', 'active'), false, 'sold is terminal');
  assert.equal(canChangeListingStatus('archived', 'sold'), false);
  assert.equal(canChangeListingStatus('constructor', 'active'), false, 'no prototype keys');
  assert.equal(canChangeListingStatus('__proto__', 'active'), false);
  assert.ok(Object.isFrozen(LISTING_TRANSITIONS));
});

test('CSV cells follow RFC 4180', () => {
  assert.equal(csvCell('Hello, world'), '"Hello, world"');
  assert.equal(csvCell('He said "yes"'), '"He said ""yes"""');
  assert.equal(csvCell('line one\nline two'), '"line one\nline two"');
  assert.equal(csvCell(null), '');
  assert.equal(csvCell(2021), '2021');
});

test('CSV cells neutralise spreadsheet formulas', () => {
  assert.equal(csvCell('=HYPERLINK("http://x")'), `"'=HYPERLINK(""http://x"")"`);
  assert.equal(csvCell('+1 555 0100'), "'+1 555 0100");
  assert.equal(csvCell('-2+3'), "'-2+3");
  assert.equal(csvCell('@SUM(A1)'), "'@SUM(A1)");
  assert.equal(csvCell('\tcmd'), "'\tcmd");
});

test('toCsv writes a UTF-8 BOM, a header row and CRLF line endings', () => {
  const csv = toCsv([{ key: 'name', label: 'Name' }, { key: 'city', label: 'City' }], [{ name: 'Ñandú', city: 'Ñuñoa' }]);
  assert.equal(csv.charCodeAt(0), 0xfeff);
  assert.equal(csv.slice(1), 'Name,City\r\nÑandú,Ñuñoa\r\n');
});

test('HTML escaping covers the five special characters', () => {
  assert.equal(escapeHtml(`<a href="x">Tom & 'Jerry'</a>`), '&lt;a href=&quot;x&quot;&gt;Tom &amp; &#39;Jerry&#39;&lt;/a&gt;');
  assert.equal(escapeHtml(undefined), '');
});

test('emails are masked for logs', () => {
  assert.equal(maskEmail('maria@example.com'), 'm***@example.com');
  assert.equal(maskEmail('broken'), '***');
});

test('money formatting uses the configured currency without decimals', () => {
  assert.match(formatMoney(12500000, 'CLP'), /12,500,000/);
});
