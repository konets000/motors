import test from 'node:test';
import assert from 'node:assert/strict';
import * as v from '../../src/validation.js';

const car = {
  make: 'Toyota', model: 'Corolla', year: 2021, price: 12500000, mileage: 45000,
  transmission: 'automatic', fuel: 'petrol', body: 'sedan', region: 'Metropolitan Region',
  city: 'Ñuñoa', description: 'Well kept, single owner, service records available.'
};

test('normalises registration email and rejects short passwords', () => {
  const ok = v.registerSchema.parse({ name: ' Ana ', email: ' ANA@Example.com ', password: 'long-enough-1' });
  assert.equal(ok.email, 'ana@example.com');
  assert.equal(ok.name, 'Ana');
  assert.equal(v.registerSchema.safeParse({ name: 'Ana', email: 'ana@example.com', password: 'short' }).success, false);
});

test('strips control characters from free text', () => {
  const parsed = v.listingSchema.parse({ ...car, description: `Clean\u0007 text with a bell and tab\tkept.` });
  assert.equal(parsed.description, 'Clean text with a bell and tab\tkept.');
});

test('accepts a valid listing and applies defaults', () => {
  const parsed = v.listingSchema.parse(car);
  assert.equal(parsed.trim, '');
  assert.equal(parsed.sellerType, 'private');
});

test('rejects out-of-range numbers, unknown enums and unexpected fields', () => {
  assert.equal(v.listingSchema.safeParse({ ...car, year: 1900 }).success, false);
  assert.equal(v.listingSchema.safeParse({ ...car, year: new Date().getFullYear() + 5 }).success, false);
  assert.equal(v.listingSchema.safeParse({ ...car, price: 10 }).success, false);
  assert.equal(v.listingSchema.safeParse({ ...car, fuel: 'Bencina' }).success, false);
  assert.equal(v.listingSchema.safeParse({ ...car, isAdmin: true }).success, false);
});

test('partial updates keep the same validation rules', () => {
  assert.equal(v.listingUpdateSchema.safeParse({ price: 9000000 }).success, true);
  assert.equal(v.listingUpdateSchema.safeParse({ price: 1 }).success, false);
  assert.equal(v.listingUpdateSchema.safeParse({}).success, true);
});

test('search query: empty strings are ignored and numbers are coerced', () => {
  const parsed = v.listingsQuerySchema.parse({ q: '', minPrice: '1000000', maxYear: '', sort: '', limit: '12', offset: '24' });
  assert.equal(parsed.q, undefined, 'empty text is treated as absent');
  assert.equal(parsed.minPrice, 1_000_000);
  assert.equal(parsed.maxYear, undefined);
  assert.equal(parsed.sort, 'newest');
  assert.equal(parsed.limit, 12);
  assert.equal(parsed.offset, 24);
});

test('search query: defaults and bounds', () => {
  const parsed = v.listingsQuerySchema.parse({});
  assert.equal(parsed.limit, 24);
  assert.equal(parsed.offset, 0);
  assert.equal(v.listingsQuerySchema.safeParse({ limit: '500' }).success, false);
  assert.equal(v.listingsQuerySchema.safeParse({ body: 'truck' }).success, false);
});

test('inquiries require explicit consent', () => {
  const base = { name: 'Luis', email: 'luis@example.com', message: 'Still available?' };
  assert.equal(v.inquirySchema.safeParse({ ...base, consent: true }).success, true);
  const denied = v.inquirySchema.safeParse({ ...base, consent: false });
  assert.equal(denied.success, false);
  assert.match(denied.error.issues[0].message, /Consent is required/);
  assert.equal(v.inquirySchema.safeParse(base).success, false);
});

test('UUID validation', () => {
  assert.equal(v.isUuid('3f9c1e2a-7b4d-4e8f-9a1b-2c3d4e5f6a7b'), true);
  assert.equal(v.isUuid('not-a-uuid'), false);
  assert.equal(v.isUuid("1' OR '1'='1"), false);
});

test('status and moderation enums are closed', () => {
  assert.equal(v.statusChangeSchema.safeParse({ status: 'sold' }).success, true);
  assert.equal(v.statusChangeSchema.safeParse({ status: 'deleted' }).success, false);
  assert.equal(v.moderationSchema.safeParse({ status: 'sold', reason: 'bad' }).success, false);
  assert.equal(v.moderationSchema.safeParse({ status: 'archived', reason: 'Duplicate listing' }).success, true);
});

test('engine displacement can be cleared with null but not sent as an empty string', () => {
  assert.equal(v.listingUpdateSchema.parse({ engineCc: null }).engineCc, null);
  assert.equal(v.listingUpdateSchema.parse({ engineCc: '' }).engineCc, undefined);
  assert.equal(v.listingSchema.parse({ ...car, engineCc: null }).engineCc, null);
});
