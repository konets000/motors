import test from 'node:test';
import assert from 'node:assert/strict';
import { createRouter, createRateLimiter, readCookie, clientIp, HttpError } from '../../src/http.js';

test('router extracts named parameters and decodes them safely', () => {
  const router = createRouter();
  router.get('/api/listings/:id/photos/:photoId', () => 'ok');
  const found = router.match('GET', '/api/listings/abc/photos/xyz%20');
  assert.equal(found.route.method, 'GET');
  assert.deepEqual(found.params, { id: 'abc', photoId: 'xyz ' });
  const malformed = router.match('GET', '/api/listings/%E0%A4%A/photos/1');
  assert.equal(malformed.params.id, '%E0%A4%A');
});

test('router escapes literal dots so routes cannot match loosely', () => {
  const router = createRouter();
  router.get('/api/me/inquiries.csv', () => 'csv');
  assert.ok(router.match('GET', '/api/me/inquiries.csv').route);
  assert.equal(router.match('GET', '/api/me/inquiriesXcsv').route, null);
});

test('router reports 405 when the path exists under another method', () => {
  const router = createRouter();
  router.get('/api/listings', () => 'list');
  const found = router.match('DELETE', '/api/listings');
  assert.equal(found.route, null);
  assert.equal(found.pathMatched, true);
});

test('rate limiter allows up to the limit inside the window and then blocks', () => {
  let time = 0;
  const limiter = createRateLimiter({ now: () => time });
  assert.equal(limiter.hit('k', 2, 1000).allowed, true);
  assert.equal(limiter.hit('k', 2, 1000).allowed, true);
  const blocked = limiter.hit('k', 2, 1000);
  assert.equal(blocked.allowed, false);
  assert.ok(blocked.retryAfterSeconds >= 1);
  time = 1001;
  assert.equal(limiter.hit('k', 2, 1000).allowed, true, 'window reset');
});

test('reads a named cookie from a Cookie header', () => {
  assert.equal(readCookie('a=1; rm_session=tok.en.val; b=2', 'rm_session'), 'tok.en.val');
  assert.equal(readCookie('rm_session_other=x', 'rm_session'), null);
  assert.equal(readCookie(undefined, 'rm_session'), null);
});

test('client IP ignores X-Forwarded-For unless a proxy is trusted', () => {
  const req = { headers: { 'x-forwarded-for': '203.0.113.9, 10.0.0.1' }, socket: { remoteAddress: '10.0.0.1' } };
  assert.equal(clientIp(req, false), '10.0.0.1');
  assert.equal(clientIp(req, true), '203.0.113.9');
});

test('HttpError carries status, details and headers', () => {
  const error = new HttpError(429, 'Slow down', { details: [{ path: 'x' }], headers: { 'Retry-After': '5' } });
  assert.equal(error.status, 429);
  assert.equal(error.headers['Retry-After'], '5');
  assert.equal(error.details[0].path, 'x');
});
