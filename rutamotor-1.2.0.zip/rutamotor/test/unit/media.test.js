import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { detectImage, createStorage } from '../../src/media.js';

const PNG_1x1 = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=', 'base64');

test('detects JPEG, PNG and WebP by magic bytes', () => {
  assert.deepEqual(detectImage(Buffer.from([0xff, 0xd8, 0xff, 0xe0, 0, 0])), { contentType: 'image/jpeg', ext: 'jpg' });
  assert.deepEqual(detectImage(PNG_1x1), { contentType: 'image/png', ext: 'png' });
  const webp = Buffer.concat([Buffer.from('RIFF'), Buffer.from([0, 0, 0, 0]), Buffer.from('WEBP'), Buffer.from('VP8 ')]);
  assert.deepEqual(detectImage(webp), { contentType: 'image/webp', ext: 'webp' });
});

test('rejects SVG, HTML and files that only claim to be images', () => {
  assert.equal(detectImage(Buffer.from('<svg xmlns="http://www.w3.org/2000/svg"></svg>')), null);
  assert.equal(detectImage(Buffer.from('<html><script>alert(1)</script>')), null);
  assert.equal(detectImage(Buffer.from([0xff])), null);
});

test('storage saves, reads and removes files using generated keys only', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'rm-media-'));
  try {
    const storage = createStorage(dir);
    const key = await storage.save(PNG_1x1, 'png');
    assert.match(key, /^[0-9a-f-]{36}\.png$/);
    assert.deepEqual(await storage.read(key), PNG_1x1);
    await storage.remove(key);
    await assert.rejects(storage.read(key));
    await assert.rejects(storage.read('../../etc/passwd'), /Invalid storage key/);
    await storage.remove('../../etc/passwd');
  } finally {
    fs.rmSync(dir, { recursive: true, force: true });
  }
});
