import test from 'node:test';
import assert from 'node:assert/strict';
import { loadConfig } from '../../src/config.js';

test('development starts without AUTH_SECRET by generating an ephemeral one', () => {
  const config = loadConfig({});
  assert.equal(config.authSecret.length, 64);
  assert.equal(config.production, false);
});

test('production refuses to start without a strong AUTH_SECRET', () => {
  assert.throws(() => loadConfig({ NODE_ENV: 'production' }), /AUTH_SECRET must be set in production/);
  assert.throws(() => loadConfig({ NODE_ENV: 'production', AUTH_SECRET: 'short' }), /at least 32 characters/);
  assert.equal(loadConfig({ NODE_ENV: 'production', AUTH_SECRET: 'x'.repeat(32), APP_URL: 'https://rutamotor.example.test' }).production, true);
});

test('webhooks must use https in production', () => {
  const base = { NODE_ENV: 'production', AUTH_SECRET: 'x'.repeat(32), APP_URL: 'https://rutamotor.example.test' };
  assert.throws(() => loadConfig({ ...base, WEBHOOK_URL: 'http://hooks.example.test/x' }), /https/);
  assert.equal(loadConfig({ ...base, WEBHOOK_URL: 'https://hooks.example.test/x' }).webhooks.url, 'https://hooks.example.test/x');
});

test('unknown email providers are rejected', () => {
  assert.throws(() => loadConfig({ EMAIL_PROVIDER: 'carrier-pigeon' }), /EMAIL_PROVIDER/);
});

test('parses lists and integers with safe fallbacks', () => {
  const config = loadConfig({ ADMIN_EMAILS: 'Boss@Example.com, , second@example.com', MAX_PHOTO_BYTES: 'not-a-number', CORS_ORIGINS: 'https://a.test,https://b.test' });
  assert.deepEqual(config.adminEmails, ['boss@example.com', 'second@example.com']);
  assert.equal(config.maxPhotoBytes, 5 * 1024 * 1024);
  assert.deepEqual(config.corsOrigins, ['https://a.test', 'https://b.test']);
});

test('production needs an https APP_URL, and development defaults to localhost', () => {
  assert.throws(() => loadConfig({ NODE_ENV: 'production', AUTH_SECRET: 'x'.repeat(32) }), /APP_URL must be set/);
  assert.throws(() => loadConfig({ NODE_ENV: 'production', AUTH_SECRET: 'x'.repeat(32), APP_URL: 'http://rutamotor.example.test' }), /https/);
  assert.equal(loadConfig({ APP_URL: 'https://rutamotor.example.test///' }).appUrl, 'https://rutamotor.example.test');
  assert.equal(loadConfig({}).appUrl, 'http://localhost:3000');
});

test('email verification enforcement is off by default and can be enabled', () => {
  assert.equal(loadConfig({}).requireVerifiedEmail, false);
  assert.equal(loadConfig({ REQUIRE_VERIFIED_EMAIL: 'true' }).requireVerifiedEmail, true);
});

test('the rate limit store must be memory or database', () => {
  assert.equal(loadConfig({}).rateLimitStore, 'memory');
  assert.equal(loadConfig({ RATE_LIMIT_STORE: 'Database' }).rateLimitStore, 'database');
  assert.throws(() => loadConfig({ RATE_LIMIT_STORE: 'redis' }), /RATE_LIMIT_STORE/);
});
