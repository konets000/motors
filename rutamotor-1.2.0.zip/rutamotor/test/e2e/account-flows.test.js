// Browser tests for the account screens. They run the real web app in headless Chrome against an in-process server.
// Opt-in: set E2E_CHROME_PATH to a Chrome or Chromium binary, and install puppeteer-core (npm i -D puppeteer-core).
import test from 'node:test';
import assert from 'node:assert/strict';
import { createHarness } from '../integration/harness.js';

const CHROME = process.env.E2E_CHROME_PATH;
const puppeteer = CHROME ? await import('puppeteer-core').then((m) => m.default).catch(() => null) : null;
const skip = !CHROME
  ? 'set E2E_CHROME_PATH to a Chrome binary to run browser tests'
  : (!puppeteer ? 'install puppeteer-core to run browser tests (npm i -D puppeteer-core)' : false);

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

/** Waits until `predicate` is true in the page, failing with `message` after a timeout. */
async function until(page, predicate, message, timeout = 8000) {
  await page.waitForFunction(predicate, { timeout }).catch(() => {
    throw new Error(message);
  });
}

test('confirm email, reset password, and sign in again, in a real browser', { skip, timeout: 120_000 }, async (t) => {
  const h = await createHarness();
  t.after(() => h.close());
  const sent = [];
  h.services.email.send = async (message) => {
    sent.push(message);
    return { sent: true, reason: 'test' };
  };
  const linkFor = (subject, route) => {
    const mail = sent.filter((m) => subject.test(m.subject)).pop();
    assert.ok(mail, `an email matching ${subject} was sent`);
    const match = new RegExp(`#/${route}/([A-Za-z0-9_-]+)`).exec(mail.text);
    assert.ok(match, 'the email contains the link');
    return match[1];
  };

  const browser = await puppeteer.launch({ executablePath: CHROME, headless: true, args: ['--no-sandbox', '--disable-gpu'] });
  t.after(() => browser.close());
  const errors = [];
  const track = (page) => page.on('pageerror', (error) => errors.push(error.message));
  const email = `browser.${Date.now()}@example.test`;

  // Journey 1: register, see the banner, confirm the email.
  const first = await (await browser.createBrowserContext()).newPage();
  track(first);
  await first.goto(`${h.base}/#/register`, { waitUntil: 'networkidle0' });
  await first.type('input[name=name]', 'Bea Tester');
  await first.type('input[name=email]', email);
  await first.type('input[name=password]', 'correct-horse-1');
  await first.click('button[type=submit]');
  await until(first, () => location.hash === '#/mine', 'registration navigated to My listings');
  await until(first, () => document.querySelector('.alert.info') !== null, 'the confirmation banner is shown');
  await h.drain();
  const verifyToken = linkFor(/Confirm your/, 'verify');

  await first.evaluate((token) => { location.hash = `#/verify/${token}`; }, verifyToken);
  await until(first, () => document.querySelector('#app h1')?.textContent === 'Email confirmed', 'the confirmation page reports success');
  assert.equal(await first.evaluate(() => location.hash), '#/verify', 'the token is removed from the address bar');

  await first.evaluate(() => { location.hash = '#/mine'; });
  await sleep(300);
  assert.equal(await first.$('.alert.info'), null, 'the banner is gone once the email is confirmed');

  await first.evaluate((token) => { location.hash = `#/verify/${token}`; }, verifyToken);
  await until(first, () => document.querySelector('#app h1')?.textContent === 'Link not valid', 'a used link shows an error');

  // Journey 2: forgot password, reset, sign in with the new password (signed out, separate browser context).
  const second = await (await browser.createBrowserContext()).newPage();
  track(second);
  await second.goto(`${h.base}/#/forgot`, { waitUntil: 'networkidle0' });
  await second.type('input[name=email]', email);
  await second.click('button[type=submit]');
  await until(second, () => document.querySelector('.alert.ok') !== null, 'the neutral confirmation is shown');
  await h.drain();
  const resetToken = linkFor(/Reset your/, 'reset');

  await second.evaluate((token) => { location.hash = `#/reset/${token}`; }, resetToken);
  await until(second, () => document.querySelector('input[name=confirm]') !== null, 'the reset form opens');
  assert.equal(await second.evaluate(() => location.hash), '#/reset', 'the reset token is removed from the address bar');

  await second.type('input[name=password]', 'a-new-password-1');
  await second.type('input[name=confirm]', 'different-one-2');
  await second.click('button[type=submit]');
  await until(second, () => /do not match/.test(document.querySelector('.alert.error')?.textContent || ''), 'mismatched passwords are caught in the browser');

  await second.$eval('input[name=confirm]', (el) => { el.value = ''; });
  await second.type('input[name=confirm]', 'a-new-password-1');
  await second.click('button[type=submit]');
  await until(second, () => location.hash === '#/login', 'a successful reset returns to sign-in');

  await second.type('input[name=email]', email);
  await second.type('input[name=password]', 'a-new-password-1');
  await second.click('button[type=submit]');
  await until(second, () => location.hash === '#/mine', 'the new password signs in');

  // Journey 3: the old password is rejected.
  const third = await (await browser.createBrowserContext()).newPage();
  track(third);
  await third.goto(`${h.base}/#/login`, { waitUntil: 'networkidle0' });
  await third.type('input[name=email]', email);
  await third.type('input[name=password]', 'correct-horse-1');
  await third.click('button[type=submit]');
  await until(third, () => /Incorrect email or password/.test(document.querySelector('.alert.error')?.textContent || ''), 'the old password is rejected');

  assert.deepEqual(errors, [], 'no JavaScript errors on any page');
});
