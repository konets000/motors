// Browser test for the marketplace: browse, publish, photo upload, inquiry, compare, seller inbox and admin console.
// Opt-in: set E2E_CHROME_PATH (see account-flows.test.js).
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { createHarness, PNG_1x1 } from '../integration/harness.js';

const CHROME = process.env.E2E_CHROME_PATH;
const puppeteer = CHROME ? await import('puppeteer-core').then((m) => m.default).catch(() => null) : null;
const skip = !CHROME
  ? 'set E2E_CHROME_PATH to a Chrome binary to run browser tests'
  : (!puppeteer ? 'install puppeteer-core to run browser tests (npm i -D puppeteer-core)' : false);

test('a buyer and a seller complete the main marketplace journeys in a real browser', { skip, timeout: 180_000 }, async (t) => {
  const h = await createHarness({ env: { ADMIN_EMAILS: 'ada.admin@example.test' } });
  t.after(() => h.close());
  const photoFile = path.join(os.tmpdir(), `rutamotor-e2e-${process.pid}.png`);
  fs.writeFileSync(photoFile, PNG_1x1);
  t.after(() => fs.rmSync(photoFile, { force: true }));

  const browser = await puppeteer.launch({ executablePath: CHROME, headless: true, args: ['--no-sandbox', '--disable-gpu'] });
  t.after(() => browser.close());
  const errors = [];
  const newPage = async () => {
    const page = await (await browser.createBrowserContext()).newPage();
    page.on('pageerror', (error) => errors.push(error.message));
    return page;
  };

  // Waits for a hash change, or for the page to show some text, instead of reading it at one arbitrary moment.
  const go = async (page, hash) => {
    await page.evaluate((target) => { location.hash = target; }, hash);
  };
  const showsText = (page, needle) => page.waitForFunction(
    (text) => (document.querySelector('#app')?.textContent || '').includes(text), { timeout: 8000 }, needle
  ).then(() => true, () => false);
  const clickButton = (page, label) => page.evaluate((text) => {
    [...document.querySelectorAll('button')].find((b) => b.textContent === text).click();
  }, label);

  // Seller: register, publish a car, upload a photo.
  const seller = await newPage();
  await seller.goto(`${h.base}/#/register`, { waitUntil: 'networkidle0' });
  await seller.type('input[name=name]', 'Sara Seller');
  await seller.type('input[name=email]', `sara.${Date.now()}@example.test`);
  await seller.type('input[name=password]', 'correct-horse-1');
  await seller.click('button[type=submit]');
  await seller.waitForFunction(() => location.hash === '#/mine', { timeout: 8000 });

  await go(seller, '#/sell');
  await seller.waitForSelector('select[name=transmission]');
  const set = (name, value) => seller.$eval(`[name=${name}]`, (el, v) => { el.value = v; }, value);
  await seller.type('input[name=make]', 'Mazda');
  await seller.type('input[name=model]', 'CX-5');
  await seller.type('input[name=trim]', 'Touring');
  await set('year', '2019');
  await set('price', '15000000');
  await set('mileage', '60000');
  await set('transmission', 'automatic');
  await set('fuel', 'petrol');
  await set('body', 'suv');
  await set('engineCc', '2500');
  await seller.type('input[name=region]', 'Metropolitan Region');
  await seller.type('input[name=city]', 'Providencia');
  await seller.type('textarea[name=description]', 'Single owner, full service history, new tyres.');
  await seller.click('form button[type=submit]');
  await seller.waitForFunction(() => /^#\/sell\/[0-9a-f-]{36}$/.test(location.hash), { timeout: 8000 });
  const listingId = (await seller.evaluate(() => location.hash)).split('/').pop();

  await seller.waitForSelector('input[type=file]', { timeout: 8000 });
  const file = await seller.$('input[type=file]');
  await file.uploadFile(photoFile);
  await clickButton(seller, 'Upload photo');
  assert.ok(await seller.waitForFunction(() => /Photo added/.test(document.querySelector('#toasts')?.textContent || ''), { timeout: 8000 }).then(() => true, () => false), 'the photo upload is confirmed');

  // Buyer: browse, search, send an inquiry, compare.
  const buyer = await newPage();
  await buyer.goto(`${h.base}/#/`, { waitUntil: 'networkidle0' });
  assert.ok(await showsText(buyer, 'Mazda CX-5'), 'browse shows the published car');

  await buyer.type('input[name=q]', 'mazda');
  await buyer.keyboard.press('Enter');
  await new Promise((resolve) => setTimeout(resolve, 800));
  assert.ok(await showsText(buyer, 'Mazda CX-5'), 'search finds the car');

  await go(buyer, `#/listings/${listingId}`);
  await buyer.waitForSelector('form input[name=email]', { timeout: 8000 });
  await buyer.type('form input[name=name]', 'Ben Buyer');
  await buyer.type('form input[name=email]', 'ben.buyer@example.test');
  await buyer.click('form input[name=consent]');
  await buyer.click('form button[type=submit]');
  assert.ok(await buyer.waitForFunction(() => /was sent to the seller/.test(document.querySelector('form [role=status]')?.textContent || ''), { timeout: 8000 }).then(() => true, () => false), 'the inquiry is confirmed');

  await go(buyer, '#/');
  const compare = await buyer.waitForSelector('button[data-compare-id]', { timeout: 8000 });
  await compare.click();
  await buyer.waitForFunction(() => document.querySelector('button[data-compare-id]')?.getAttribute('aria-pressed') === 'true', { timeout: 3000 });
  assert.equal(await buyer.$eval('button[data-compare-id]', (b) => b.textContent), 'Remove from compare', 'the button label follows the state');

  // Seller: the inquiry appears in the inbox.
  await go(seller, '#/inquiries');
  assert.ok(await showsText(seller, 'Ben Buyer'), 'the seller inbox lists the inquiry');

  // Administrator: the job console loads.
  const admin = await newPage();
  await admin.goto(`${h.base}/#/register`, { waitUntil: 'networkidle0' });
  await admin.type('input[name=name]', 'Ada Admin');
  await admin.type('input[name=email]', 'ada.admin@example.test');
  await admin.type('input[name=password]', 'correct-horse-1');
  await admin.click('button[type=submit]');
  await admin.waitForFunction(() => location.hash === '#/mine', { timeout: 8000 });
  await go(admin, '#/admin');
  assert.ok(await showsText(admin, 'job'), 'the admin console loads for an administrator');

  assert.deepEqual(errors, [], 'no JavaScript errors on any page');
});
