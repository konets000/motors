// RutaMotor web app: a dependency-free single-page app using hash routing.
// All server data is inserted with textContent or DOM nodes, never as HTML strings.

const LABELS = {
  transmission: { automatic: 'Automatic', manual: 'Manual' },
  fuel: { petrol: 'Petrol', diesel: 'Diesel', hybrid: 'Hybrid', electric: 'Electric', lpg: 'LPG' },
  body: { suv: 'SUV', sedan: 'Sedan', hatchback: 'Hatchback', pickup: 'Pickup', coupe: 'Coupe', van: 'Van' },
  sellerType: { private: 'Private seller', dealer: 'Dealer' },
  status: { active: 'Active', reserved: 'Reserved', sold: 'Sold', archived: 'Archived' },
  inquiry: { new: 'New', contacted: 'Contacted', qualified: 'Qualified', closed: 'Closed', spam: 'Spam' },
  sort: { newest: 'Newest', priceAsc: 'Price: low to high', priceDesc: 'Price: high to low', yearDesc: 'Year: newest first', mileageAsc: 'Mileage: lowest first' }
};
const COMPARE_KEY = 'rutamotor.compare';
const PAGE_SIZE = 24;

const state = {
  user: null,
  facets: { currency: 'CLP', limits: { maxPhotoBytes: 5 * 1024 * 1024, maxPhotosPerListing: 10 }, makes: [], regions: [], bodies: [], fuels: [], transmissions: [], sorts: [] },
  compare: readCompare()
};

// ---------- DOM helpers ----------------------------------------------------------------

function h(tag, props = {}, ...children) {
  const el = document.createElement(tag);
  for (const [key, value] of Object.entries(props || {})) {
    if (value === undefined || value === null || value === false) continue;
    if (key === 'class') el.className = value;
    else if (key === 'text') el.textContent = String(value);
    else if (key === 'value') el.value = String(value);
    else if (key === 'checked') el.checked = Boolean(value);
    else if (key.startsWith('on') && typeof value === 'function') el.addEventListener(key.slice(2), value);
    else el.setAttribute(key, value === true ? '' : String(value));
  }
  for (const child of children.flat()) {
    if (child === undefined || child === null || child === false) continue;
    el.append(child instanceof Node ? child : document.createTextNode(String(child)));
  }
  return el;
}

const $ = (selector) => document.querySelector(selector);
const money = (amount) => new Intl.NumberFormat('en-US', { style: 'currency', currency: state.facets.currency, maximumFractionDigits: 0 }).format(amount);
const km = (value) => `${Number(value).toLocaleString('en-US')} km`;
const dateText = (iso) => (iso ? new Date(iso).toLocaleString('en-US', { dateStyle: 'medium', timeStyle: 'short' }) : '');
const option = (value, label, selected) => h('option', { value, selected: selected ? true : undefined }, label);
const options = (values, labels = {}, selected = '', placeholder = 'Any') => [
  h('option', { value: '' }, placeholder),
  ...values.map((value) => option(value, labels[value] || value, String(value) === String(selected)))
];

function readCompare() {
  try {
    const ids = JSON.parse(localStorage.getItem(COMPARE_KEY) || '[]');
    return Array.isArray(ids) ? ids.filter((id) => typeof id === 'string').slice(0, 3) : [];
  } catch {
    return [];
  }
}
function saveCompare() {
  localStorage.setItem(COMPARE_KEY, JSON.stringify(state.compare));
  renderNav();
}

function toast(message, kind = 'info') {
  const node = h('div', { class: `toast ${kind === 'error' ? 'error' : ''}`, text: message });
  $('#toasts').append(node);
  setTimeout(() => node.remove(), 4500);
}

function alertBox(message, kind = 'error') {
  return h('div', { class: `alert ${kind}`, role: 'alert', text: message });
}

// ---------- API client -----------------------------------------------------------------

async function api(path, { method = 'GET', body } = {}) {
  const init = { method, credentials: 'same-origin', headers: { Accept: 'application/json' } };
  if (body !== undefined) {
    init.headers['Content-Type'] = 'application/json';
    init.body = JSON.stringify(body);
  }
  const response = await fetch(`/api${path}`, init);
  const data = (response.headers.get('content-type') || '').includes('json') ? await response.json() : null;
  if (!response.ok) {
    const error = new Error(data?.error || `Request failed (${response.status}).`);
    error.status = response.status;
    error.details = data?.details || [];
    throw error;
  }
  return data;
}

function errorMessage(error) {
  if (error.details?.length) return error.details.map((detail) => detail.message).join(' ');
  return error.message || 'Something went wrong.';
}

function setView(...nodes) {
  $('#app').replaceChildren(...nodes);
  $('#app').focus({ preventScroll: true });
}

function loading() {
  setView(h('p', { class: 'muted', text: 'Loading…' }));
}

// ---------- Navigation -----------------------------------------------------------------

function renderNav() {
  const current = location.hash || '#/';
  const link = (href, label) => h('a', { href, 'aria-current': current === href ? 'page' : undefined }, label);
  const items = [
    link('#/', 'Browse'),
    link('#/compare', `Compare (${state.compare.length})`)
  ];
  if (state.user) {
    items.push(link('#/sell', 'Sell a car'), link('#/mine', 'My listings'), link('#/inquiries', 'Inquiries'));
    if (state.user.role === 'admin') items.push(link('#/admin', 'Admin'));
    items.push(h('span', { class: 'muted', text: state.user.name }),
      h('button', { class: 'link', type: 'button', onclick: logout, text: 'Sign out' }));
  } else {
    items.push(link('#/login', 'Sign in'), link('#/register', 'Create account'));
  }
  $('#nav').replaceChildren(...items);
}

async function logout() {
  try {
    await api('/auth/logout', { method: 'POST' });
  } catch { /* the session cookie is cleared below regardless */ }
  state.user = null;
  toast('You have signed out.');
  location.hash = '#/';
  render();
}

// ---------- Views ----------------------------------------------------------------------

function placeholder(item) {
  const initials = `${item.make?.[0] || ''}${item.model?.[0] || ''}`.toUpperCase();
  return h('div', { class: 'thumb-placeholder', 'aria-hidden': 'true', text: initials || 'RM' });
}

function listingCard(item) {
  const inCompare = state.compare.includes(item.id);
  const image = item.coverPhotoId
    ? h('img', { src: `/media/${item.coverPhotoId}`, alt: `${item.year} ${item.make} ${item.model}`, loading: 'lazy' })
    : placeholder(item);
  return h('article', { class: 'card' },
    h('a', { href: `#/listings/${item.id}` }, image),
    h('div', { class: 'card-body' },
      h('a', { class: 'card-title', href: `#/listings/${item.id}`, text: `${item.year} ${item.make} ${item.model}` }),
      h('div', { class: 'price', text: money(item.price) }),
      h('div', { class: 'meta', text: `${km(item.mileage)} · ${LABELS.transmission[item.transmission]} · ${LABELS.fuel[item.fuel]}` }),
      h('div', { class: 'meta', text: `${item.city}, ${item.region}` }),
      h('div', { class: 'actions' },
        h('button', { class: 'secondary', type: 'button', 'data-compare-id': item.id, 'aria-pressed': String(inCompare), onclick: () => toggleCompare(item.id), text: inCompare ? 'Remove from compare' : 'Add to compare' })
      )
    )
  );
}

function toggleCompare(id) {
  if (state.compare.includes(id)) {
    state.compare = state.compare.filter((item) => item !== id);
  } else if (state.compare.length >= 3) {
    toast('You can compare up to three cars. Remove one first.', 'error');
    return;
  } else {
    state.compare = [...state.compare, id];
  }
  saveCompare();
  // Update the buttons in place. A full re-render would refetch the list and lose the reader's place.
  syncCompareButtons();
}

function syncCompareButtons() {
  for (const button of document.querySelectorAll('[data-compare-id]')) {
    const selected = state.compare.includes(button.dataset.compareId);
    button.textContent = selected ? 'Remove from compare' : 'Add to compare';
    button.setAttribute('aria-pressed', String(selected));
  }
}

async function browseView() {
  const form = h('form', { class: 'stack', id: 'filters' },
    h('label', {}, 'Search', h('input', { name: 'q', type: 'search', placeholder: 'Make, model or trim', maxlength: 80 })),
    h('label', {}, 'Make', h('select', { name: 'make' }, options(state.facets.makes))),
    h('label', {}, 'Body type', h('select', { name: 'body' }, options(state.facets.bodies, LABELS.body))),
    h('label', {}, 'Fuel', h('select', { name: 'fuel' }, options(state.facets.fuels, LABELS.fuel))),
    h('label', {}, 'Transmission', h('select', { name: 'transmission' }, options(state.facets.transmissions, LABELS.transmission))),
    h('label', {}, 'Region', h('select', { name: 'region' }, options(state.facets.regions))),
    h('div', { class: 'row' },
      h('label', {}, 'Min price', h('input', { name: 'minPrice', type: 'number', min: 0, step: 100000 })),
      h('label', {}, 'Max price', h('input', { name: 'maxPrice', type: 'number', min: 0, step: 100000 }))),
    h('div', { class: 'row' },
      h('label', {}, 'Min year', h('input', { name: 'minYear', type: 'number', min: 1980 })),
      h('label', {}, 'Max year', h('input', { name: 'maxYear', type: 'number', min: 1980 }))),
    h('label', {}, 'Max mileage (km)', h('input', { name: 'maxMileage', type: 'number', min: 0, step: 5000 })),
    h('label', {}, 'Sort by', h('select', { name: 'sort' }, Object.entries(LABELS.sort).map(([v, l]) => option(v, l, v === 'newest')))),
    h('div', { class: 'actions' },
      h('button', { type: 'submit', text: 'Apply filters' }),
      h('button', { class: 'secondary', type: 'button', onclick: () => { form.reset(); offset = 0; search(); }, text: 'Reset' }))
  );
  const results = h('div', { id: 'results' });
  const count = h('p', { class: 'muted', id: 'count' });
  const pager = h('div', { class: 'pager' });
  let offset = 0;
  let total = 0;

  async function search() {
    const params = new URLSearchParams({ limit: PAGE_SIZE, offset });
    for (const [key, value] of new FormData(form)) {
      if (String(value).trim() !== '') params.set(key, String(value).trim());
    }
    results.replaceChildren(h('p', { class: 'muted', text: 'Searching…' }));
    try {
      const data = await api(`/listings?${params}`);
      total = data.total;
      count.textContent = `${total} car${total === 1 ? '' : 's'} found`;
      results.replaceChildren(data.items.length
        ? h('div', { class: 'grid' }, data.items.map(listingCard))
        : h('div', { class: 'panel' }, h('p', { text: 'No cars match these filters yet. Try widening your search.' })));
      pager.replaceChildren(
        h('button', { class: 'secondary', type: 'button', disabled: offset === 0 ? true : undefined, onclick: () => { offset = Math.max(0, offset - PAGE_SIZE); search(); }, text: 'Previous' }),
        h('span', { class: 'muted', text: `${total ? offset + 1 : 0}–${Math.min(offset + PAGE_SIZE, total)} of ${total}` }),
        h('button', { class: 'secondary', type: 'button', disabled: offset + PAGE_SIZE >= total ? true : undefined, onclick: () => { offset += PAGE_SIZE; search(); }, text: 'Next' })
      );
    } catch (error) {
      results.replaceChildren(alertBox(errorMessage(error)));
    }
  }

  form.addEventListener('submit', (event) => {
    event.preventDefault();
    offset = 0;
    search();
  });

  setTimeout(search, 0);
  return h('div', { class: 'layout' },
    h('aside', { class: 'panel' }, h('h2', { style: undefined, text: 'Filters' }), form, assistantPanel()),
    h('section', {}, h('h1', { text: 'Used cars for sale' }), count, results, pager)
  );
}

function assistantPanel() {
  const input = h('textarea', { name: 'message', maxlength: 500, placeholder: 'e.g. A reliable family SUV under 15 million, automatic, low mileage' });
  const answer = h('div', { class: 'assistant-answer hidden', role: 'status' });
  const button = h('button', { type: 'button', text: 'Ask the assistant' });
  button.addEventListener('click', async () => {
    const message = input.value.trim();
    if (message.length < 3) return toast('Please describe what you are looking for.', 'error');
    button.disabled = true;
    answer.classList.remove('hidden');
    answer.textContent = 'Thinking…';
    try {
      const data = await api('/ai/assistant', { method: 'POST', body: { message } });
      answer.textContent = data.answer;
    } catch (error) {
      answer.textContent = errorMessage(error);
    } finally {
      button.disabled = false;
    }
  });
  return h('div', { class: 'stack', style: undefined },
    h('h2', { text: 'Buying assistant' }),
    h('p', { class: 'meta', text: 'Describe what you need. The assistant only recommends cars currently listed on RutaMotor.' }),
    input, button, answer);
}

async function listingDetailView(id) {
  loading();
  const { item, photos, isOwner } = await api(`/listings/${encodeURIComponent(id)}`);
  const images = photos.length ? photos : [];
  const hero = h('img', { class: 'hero-img', src: images[0] ? images[0].url : undefined, alt: `${item.year} ${item.make} ${item.model}` });
  const heroBox = images.length ? hero : placeholder(item);
  const thumbs = images.length > 1 ? h('div', { class: 'gallery-thumbs' }, images.map((photo, index) => {
    const thumb = h('button', { type: 'button', 'aria-pressed': String(index === 0), 'aria-label': `Show photo ${index + 1}` },
      h('img', { src: photo.url, alt: '', loading: 'lazy' }));
    thumb.addEventListener('click', () => {
      hero.src = photo.url;
      for (const other of thumbs.querySelectorAll('button')) other.setAttribute('aria-pressed', String(other === thumb));
    });
    return thumb;
  })) : null;

  const facts = [
    ['Price', money(item.price)], ['Year', item.year], ['Mileage', km(item.mileage)],
    ['Transmission', LABELS.transmission[item.transmission]], ['Fuel', LABELS.fuel[item.fuel]],
    ['Body', LABELS.body[item.body]], ['Engine', item.engineCc ? `${item.engineCc} cc` : 'Not provided'],
    ['Location', `${item.city}, ${item.region}`], ['Seller', `${item.sellerName} (${LABELS.sellerType[item.sellerType]})`],
    ['Listed', dateText(item.publishedAt)]
  ];

  const inquiryForm = inquiryFormFor(item);
  const compareButton = h('button', { class: 'secondary', type: 'button', 'data-compare-id': item.id, 'aria-pressed': String(state.compare.includes(item.id)), text: state.compare.includes(item.id) ? 'Remove from compare' : 'Add to compare' });
  compareButton.addEventListener('click', () => toggleCompare(item.id));
  const ownerActions = isOwner ? h('div', { class: 'actions' },
    h('a', { class: 'button secondary', href: `#/sell/${item.id}`, text: 'Edit listing' }),
    h('a', { class: 'button secondary', href: '#/mine', text: 'Manage my listings' })) : null;

  return h('div', { class: 'layout' },
    h('section', {},
      h('h1', { text: `${item.year} ${item.make} ${item.model}${item.trim ? ` ${item.trim}` : ''}` }),
      h('div', { class: 'actions' }, item.status !== 'active' ? h('span', { class: `badge ${item.status === 'sold' ? 'bad' : 'warn'}`, text: LABELS.status[item.status] }) : null),
      heroBox, thumbs,
      h('h2', { text: 'Description' }),
      ...item.description.split(/\n+/).map((paragraph) => h('p', { text: paragraph })),
      h('h2', { text: 'Details' }),
      h('dl', { class: 'facts' }, facts.flatMap(([label, value]) => [h('dt', { text: label }), h('dd', { text: String(value) })]))
    ),
    h('aside', { class: 'panel stack' },
      h('div', { class: 'price', text: money(item.price) }),
      compareButton,
      ownerActions,
      isOwner ? null : h('h2', { text: 'Contact the seller' }),
      isOwner ? null : inquiryForm
    )
  );
}

function inquiryFormFor(item) {
  const status = h('div', { role: 'status' });
  const form = h('form', { class: 'stack' },
    h('label', {}, 'Your name', h('input', { name: 'name', required: true, maxlength: 80, autocomplete: 'name' })),
    h('label', {}, 'Email', h('input', { name: 'email', type: 'email', required: true, maxlength: 254, autocomplete: 'email' })),
    h('label', {}, 'Phone (optional)', h('input', { name: 'phone', type: 'tel', maxlength: 30, autocomplete: 'tel' })),
    h('label', {}, 'Message', h('textarea', { name: 'message', required: true, minlength: 5, maxlength: 1200, text: `Hi, is the ${item.year} ${item.make} ${item.model} still available?` })),
    h('label', { class: 'check' }, h('input', { name: 'consent', type: 'checkbox', required: true }),
      'I agree that RutaMotor shares my name, email, phone and message with this seller so they can reply.'),
    h('button', { type: 'submit', text: 'Send message' }),
    status
  );
  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    const data = Object.fromEntries(new FormData(form));
    const submit = form.querySelector('button[type="submit"]');
    submit.disabled = true;
    try {
      const body = { name: data.name, email: data.email, phone: data.phone || '', message: data.message, consent: data.consent === 'on' };
      const result = await api(`/listings/${encodeURIComponent(item.id)}/inquiries`, { method: 'POST', body });
      status.replaceChildren(alertBox(result.message, 'ok'));
      form.reset();
    } catch (error) {
      status.replaceChildren(alertBox(errorMessage(error)));
    } finally {
      submit.disabled = false;
    }
  });
  return form;
}

async function compareView() {
  if (!state.compare.length) {
    return h('div', { class: 'panel' }, h('h1', { text: 'Compare' }), h('p', { text: 'Add up to three cars from Browse or a listing page to compare them here.' }));
  }
  loading();
  const items = await Promise.all(state.compare.map((id) => api(`/listings/${encodeURIComponent(id)}`).then((data) => data.item).catch(() => null)));
  const available = items.filter(Boolean);
  const rows = [
    ['Price', (item) => money(item.price)], ['Year', (item) => item.year], ['Mileage', (item) => km(item.mileage)],
    ['Transmission', (item) => LABELS.transmission[item.transmission]], ['Fuel', (item) => LABELS.fuel[item.fuel]],
    ['Body', (item) => LABELS.body[item.body]], ['Engine', (item) => (item.engineCc ? `${item.engineCc} cc` : 'Not provided')],
    ['Location', (item) => `${item.city}, ${item.region}`]
  ];
  return h('section', {},
    h('h1', { text: 'Compare cars' }),
    h('div', { class: 'table-wrap' }, h('table', {},
      h('thead', {}, h('tr', {}, h('th', { text: 'Car' }), available.map((item) => h('th', {}, h('a', { href: `#/listings/${item.id}`, text: `${item.year} ${item.make} ${item.model}` }))))),
      h('tbody', {}, rows.map(([label, getter]) => h('tr', {}, h('th', { text: label }), available.map((item) => h('td', { text: String(getter(item)) })))))
    )),
    available.length < state.compare.length ? alertBox('Some saved cars are no longer available and were skipped.', 'error') : null
  );
}

async function sellView(id) {
  let listing = null;
  let photos = [];
  if (id) {
    loading();
    try {
      const data = await api(`/listings/${encodeURIComponent(id)}`);
      if (!data.isOwner) return h('p', { text: 'You can only edit your own listings.' });
      listing = data.item;
      photos = data.photos;
    } catch (error) {
      return alertBox(errorMessage(error));
    }
  }
  const current = listing || {};
  const year = new Date().getFullYear();
  const status = h('div', { role: 'status' });
  const draftNote = h('p', { class: 'meta' });
  const field = (name, label, attrs = {}, value = current[name]) => h('label', {}, label, h('input', { name, value: value ?? '', ...attrs }));
  const select = (name, label, values, labels, value) => h('label', {}, label, h('select', { name }, options(values, labels, value ?? '', 'Choose…')));

  const form = h('form', { class: 'stack' },
    h('div', { class: 'row' },
      field('make', 'Make', { required: true, maxlength: 50 }, current.make),
      field('model', 'Model', { required: true, maxlength: 70 }, current.model)),
    h('div', { class: 'row' },
      field('trim', 'Trim (optional)', { maxlength: 100 }, current.trim),
      field('year', 'Year', { type: 'number', required: true, min: 1980, max: year + 1 }, current.year ?? year - 3)),
    h('div', { class: 'row' },
      field('price', 'Price', { type: 'number', required: true, min: 100000, step: 1000 }, current.price),
      field('mileage', 'Mileage (km)', { type: 'number', required: true, min: 0, step: 1000 }, current.mileage)),
    h('div', { class: 'row' },
      select('transmission', 'Transmission', ['automatic', 'manual'], LABELS.transmission, current.transmission),
      select('fuel', 'Fuel', ['petrol', 'diesel', 'hybrid', 'electric', 'lpg'], LABELS.fuel, current.fuel)),
    h('div', { class: 'row' },
      select('body', 'Body type', ['suv', 'sedan', 'hatchback', 'pickup', 'coupe', 'van'], LABELS.body, current.body),
      field('engineCc', 'Engine (cc, needed for CompraDeAutos)', { type: 'number', min: 50, max: 10000 }, current.engineCc ?? '')),
    h('div', { class: 'row' },
      field('region', 'Region', { required: true, maxlength: 70 }, current.region),
      field('city', 'City or commune', { required: true, maxlength: 70 }, current.city)),
    h('label', {}, 'Description',
      h('textarea', { name: 'description', required: true, minlength: 10, maxlength: 1200, text: current.description || '' })),
    h('div', { class: 'actions' },
      h('button', { class: 'secondary', type: 'button', id: 'draft', text: 'Draft description with AI' }), draftNote),
    h('div', { class: 'actions' },
      h('button', { type: 'submit', text: listing ? 'Save changes' : 'Publish listing' })),
    status
  );

  form.querySelector('#draft').addEventListener('click', async (event) => {
    const data = Object.fromEntries(new FormData(form));
    if (!data.make || !data.model || !data.year || !data.mileage || !data.transmission || !data.fuel || !data.body) {
      return toast('Fill in make, model, year, mileage, transmission, fuel and body type first.', 'error');
    }
    event.currentTarget.disabled = true;
    try {
      const result = await api('/ai/listing-description', {
        method: 'POST',
        body: { make: data.make, model: data.model, year: Number(data.year), mileage: Number(data.mileage), transmission: data.transmission, fuel: data.fuel, body: data.body, features: [], notes: '' }
      });
      form.elements.description.value = result.text;
      draftNote.textContent = result.source === 'ai' ? 'Draft generated by the AI provider. Review every fact before publishing.' : 'Draft built from your entries only (AI is not configured). Edit it before publishing.';
    } catch (error) {
      toast(errorMessage(error), 'error');
    } finally {
      event.currentTarget.disabled = false;
    }
  });

  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    const data = Object.fromEntries(new FormData(form));
    const body = {
      make: data.make, model: data.model, trim: data.trim || '', year: Number(data.year), price: Number(data.price),
      mileage: Number(data.mileage), transmission: data.transmission, fuel: data.fuel, body: data.body,
      engineCc: data.engineCc ? Number(data.engineCc) : null, region: data.region, city: data.city,
      description: data.description, sellerType: 'private'
    };
    if (listing) delete body.sellerType;
    const submit = form.querySelector('button[type="submit"]');
    submit.disabled = true;
    try {
      const result = listing
        ? await api(`/listings/${encodeURIComponent(listing.id)}`, { method: 'PATCH', body })
        : await api('/listings', { method: 'POST', body });
      toast(listing ? 'Listing saved.' : 'Listing published.');
      if (!listing) {
        location.hash = `#/sell/${result.item.id}`;
      } else {
        status.replaceChildren(alertBox('Saved.', 'ok'));
      }
    } catch (error) {
      status.replaceChildren(alertBox(errorMessage(error)));
    } finally {
      submit.disabled = false;
    }
  });

  const section = h('div', { class: 'layout' }, h('section', { class: 'panel' }, h('h1', { text: listing ? 'Edit listing' : 'Sell a car' }), form));
  if (listing) section.append(photoPanel(listing.id, photos));
  return section;
}

function photoPanel(listingId, initialPhotos) {
  let photos = [...initialPhotos];
  const list = h('div', { class: 'gallery-thumbs' });
  const status = h('div', { role: 'status' });
  const fileInput = h('input', { type: 'file', accept: 'image/jpeg,image/png,image/webp', 'aria-label': 'Choose a photo' });
  const renderList = () => list.replaceChildren(...photos.map((photo) => {
    const remove = h('button', { class: 'danger', type: 'button', 'aria-label': 'Remove photo', text: 'Remove' });
    remove.addEventListener('click', async () => {
      try {
        await api(`/listings/${encodeURIComponent(listingId)}/photos/${encodeURIComponent(photo.id)}`, { method: 'DELETE' });
        photos = photos.filter((other) => other.id !== photo.id);
        renderList();
      } catch (error) {
        status.replaceChildren(alertBox(errorMessage(error)));
      }
    });
    return h('figure', { class: 'stack' }, h('img', { src: photo.url, alt: 'Listing photo', width: 96, height: 72 }), remove);
  }));
  renderList();

  const upload = h('button', { type: 'button', text: 'Upload photo' });
  upload.addEventListener('click', async () => {
    const file = fileInput.files?.[0];
    if (!file) return toast('Choose an image first.', 'error');
    const maxBytes = state.facets.limits.maxPhotoBytes;
    if (file.size > maxBytes) return toast(`Photos must be ${Math.round(maxBytes / 1024 / 1024)} MB or smaller.`, 'error');
    upload.disabled = true;
    try {
      const dataBase64 = await readAsBase64(file);
      const result = await api(`/listings/${encodeURIComponent(listingId)}/photos`, { method: 'POST', body: { filename: file.name, dataBase64 } });
      photos = [...photos, result.photo];
      renderList();
      fileInput.value = '';
      toast('Photo added.');
    } catch (error) {
      status.replaceChildren(alertBox(errorMessage(error)));
    } finally {
      upload.disabled = false;
    }
  });

  return h('aside', { class: 'panel stack' },
    h('h2', { text: 'Photos' }),
    h('p', { class: 'meta', text: `JPEG, PNG or WebP, up to ${Math.round(state.facets.limits.maxPhotoBytes / 1024 / 1024)} MB each. The first photo is the cover.` }),
    list,
    fileInput, upload, status);
}

function readAsBase64(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result).split(',')[1] || '');
    reader.onerror = () => reject(new Error('The file could not be read.'));
    reader.readAsDataURL(file);
  });
}

async function mineView() {
  loading();
  const { items } = await api('/me/listings');
  if (!items.length) {
    return h('div', { class: 'panel' }, h('h1', { text: 'My listings' }), h('p', { text: 'You have not published any cars yet.' }), h('a', { class: 'button', href: '#/sell', text: 'Sell a car' }));
  }
  const statusFor = (item) => {
    const select = h('select', { 'aria-label': `Status for ${item.make} ${item.model}` },
      Object.entries(LABELS.status).map(([value, label]) => option(value, label, value === item.status)));
    select.disabled = item.status === 'sold';
    select.addEventListener('change', async () => {
      try {
        await api(`/listings/${encodeURIComponent(item.id)}/status`, { method: 'PATCH', body: { status: select.value } });
        toast('Status updated.');
        render();
      } catch (error) {
        toast(errorMessage(error), 'error');
        select.value = item.status;
      }
    });
    return select;
  };
  const externalCell = (item) => {
    const cell = h('span', { class: 'meta', text: 'Not published' });
    const button = h('button', { class: 'secondary', type: 'button', text: 'Publish to CompraDeAutos' });
    button.addEventListener('click', async () => {
      button.disabled = true;
      try {
        await api(`/listings/${encodeURIComponent(item.id)}/publish/compradeautos`, { method: 'POST' });
        toast('Queued for CompraDeAutos. Refresh to see the result.');
        cell.textContent = 'Queued';
      } catch (error) {
        toast(errorMessage(error), 'error');
      } finally {
        button.disabled = false;
      }
    });
    const check = h('button', { class: 'secondary', type: 'button', text: 'Check status' });
    check.addEventListener('click', async () => {
      try {
        const { items: external } = await api(`/listings/${encodeURIComponent(item.id)}/external`);
        cell.textContent = external.length ? external.map((row) => `${row.provider}: ${row.status}${row.lastError ? ` (${row.lastError})` : ''}`).join('; ') : 'Not published';
      } catch (error) {
        toast(errorMessage(error), 'error');
      }
    });
    return h('div', { class: 'stack' }, cell, h('div', { class: 'actions' }, button, check));
  };
  const renew = (item) => {
    const button = h('button', { class: 'secondary', type: 'button', text: 'Renew', disabled: item.status !== 'active' ? true : undefined });
    button.addEventListener('click', async () => {
      try {
        await api(`/listings/${encodeURIComponent(item.id)}/renew`, { method: 'POST' });
        toast('Listing renewed.');
        render();
      } catch (error) {
        toast(errorMessage(error), 'error');
      }
    });
    return button;
  };

  return h('section', {},
    h('div', { class: 'actions' }, h('h1', { text: 'My listings' }), h('a', { class: 'button', href: '#/sell', text: 'Sell a car' })),
    h('div', { class: 'table-wrap' }, h('table', {},
      h('thead', {}, h('tr', {}, ['Car', 'Price', 'Status', 'Photos', 'Inquiries', 'Published', 'Actions', 'CompraDeAutos'].map((label) => h('th', { text: label })))),
      h('tbody', {}, items.map((item) => h('tr', {},
        h('td', {}, h('a', { href: `#/listings/${item.id}`, text: `${item.year} ${item.make} ${item.model}` })),
        h('td', { text: money(item.price) }),
        h('td', {}, statusFor(item)),
        h('td', { text: String(item.photoCount ?? 0) }),
        h('td', {}, h('a', { href: '#/inquiries', text: String(item.inquiryCount ?? 0) })),
        h('td', { text: dateText(item.publishedAt) }),
        h('td', {}, h('div', { class: 'actions' }, h('a', { href: `#/sell/${item.id}`, text: 'Edit' }), renew(item))),
        h('td', {}, externalCell(item))
      )))
    ))
  );
}

async function inquiriesView() {
  loading();
  const filter = h('select', { 'aria-label': 'Filter by status' }, options(Object.keys(LABELS.inquiry), LABELS.inquiry, '', 'All statuses'));
  const body = h('tbody');
  const table = h('div', { class: 'table-wrap' }, h('table', {},
    h('thead', {}, h('tr', {}, ['Received', 'Car', 'Buyer', 'Message', 'Status'].map((label) => h('th', { text: label })))), body));
  const exportLink = h('a', { class: 'button secondary', href: '/api/me/inquiries.csv', download: '', text: 'Export CSV' });

  async function load() {
    const params = new URLSearchParams({ limit: 100 });
    if (filter.value) params.set('status', filter.value);
    const { items, total } = await api(`/me/inquiries?${params}`);
    body.replaceChildren(...(items.length ? items.map(inquiryRow) : [h('tr', {}, h('td', { colspan: 5, text: total === 0 ? 'No inquiries yet.' : 'No inquiries match this filter.' }))]));
  }
  function inquiryRow(item) {
    const select = h('select', { 'aria-label': `Status for inquiry from ${item.buyer.name}` }, options(Object.keys(LABELS.inquiry), LABELS.inquiry, item.status));
    select.addEventListener('change', async () => {
      try {
        await api(`/inquiries/${encodeURIComponent(item.id)}`, { method: 'PATCH', body: { status: select.value } });
        toast('Inquiry updated.');
      } catch (error) {
        toast(errorMessage(error), 'error');
        select.value = item.status;
      }
    });
    return h('tr', {},
      h('td', { text: dateText(item.createdAt) }),
      h('td', { text: `${item.listing.year} ${item.listing.make} ${item.listing.model}` }),
      h('td', {}, h('strong', { text: item.buyer.name }), h('br'), h('a', { href: `mailto:${item.buyer.email}`, text: item.buyer.email }),
        item.buyer.phone ? h('div', { class: 'meta', text: item.buyer.phone }) : null),
      h('td', { text: item.message }),
      h('td', {}, select));
  }
  filter.addEventListener('change', () => load().catch((error) => toast(errorMessage(error), 'error')));
  load().catch((error) => body.replaceChildren(h('tr', {}, h('td', { colspan: 5 }, alertBox(errorMessage(error))))));

  return h('section', {},
    h('div', { class: 'actions' }, h('h1', { text: 'Inquiries' }), filter, exportLink),
    table);
}

function authForm(mode) {
  const status = h('div', { role: 'status' });
  const isRegister = mode === 'register';
  const form = h('form', { class: 'stack' },
    isRegister ? h('label', {}, 'Full name', h('input', { name: 'name', required: true, maxlength: 80, autocomplete: 'name' })) : null,
    h('label', {}, 'Email', h('input', { name: 'email', type: 'email', required: true, maxlength: 254, autocomplete: 'email' })),
    h('label', {}, 'Password', h('input', { name: 'password', type: 'password', required: true, minlength: isRegister ? 10 : 1, maxlength: 128, autocomplete: isRegister ? 'new-password' : 'current-password' })),
    isRegister ? h('label', {}, 'Phone (optional)', h('input', { name: 'phone', type: 'tel', maxlength: 30, autocomplete: 'tel' })) : null,
    isRegister ? h('label', { class: 'check' }, h('input', { name: 'whatsappOptIn', type: 'checkbox' }), 'Send me WhatsApp notifications for new inquiries (requires a phone number).') : null,
    h('button', { type: 'submit', text: isRegister ? 'Create account' : 'Sign in' }),
    status
  );
  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    const data = Object.fromEntries(new FormData(form));
    const body = isRegister
      ? { name: data.name, email: data.email, password: data.password, phone: data.phone || '', whatsappOptIn: data.whatsappOptIn === 'on' }
      : { email: data.email, password: data.password };
    try {
      const result = await api(`/auth/${isRegister ? 'register' : 'login'}`, { method: 'POST', body });
      state.user = result.user;
      renderNav();
      toast(isRegister ? 'Welcome to RutaMotor! Check your inbox to confirm your email address.' : 'Signed in.');
      location.hash = '#/mine';
    } catch (error) {
      status.replaceChildren(alertBox(errorMessage(error)));
    }
  });
  return h('div', { class: 'panel', style: undefined },
    h('h1', { text: isRegister ? 'Create account' : 'Sign in' }),
    form,
    h('p', { class: 'meta' }, isRegister
      ? h('span', {}, 'Already have an account? ', h('a', { href: '#/login', text: 'Sign in' }))
      : h('span', {}, 'New to RutaMotor? ', h('a', { href: '#/register', text: 'Create an account' }))),
    isRegister ? null : h('p', { class: 'meta' }, h('a', { href: '#/forgot', text: 'Forgot your password?' })));
}

// Removes a one-time token from the address bar and history, so it is not left behind after the page loads.
function clearTokenFromUrl(replacement) {
  history.replaceState(null, '', `${location.pathname}${location.search}${replacement}`);
}

function forgotView() {
  const status = h('div', { role: 'status' });
  const form = h('form', { class: 'stack' },
    h('label', {}, 'Email', h('input', { name: 'email', type: 'email', required: true, maxlength: 254, autocomplete: 'email' })),
    h('button', { type: 'submit', text: 'Send reset link' }),
    status);
  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    const data = Object.fromEntries(new FormData(form));
    try {
      const result = await api('/auth/forgot-password', { method: 'POST', body: { email: data.email } });
      status.replaceChildren(alertBox(result.message, 'ok'));
    } catch (error) {
      status.replaceChildren(alertBox(errorMessage(error)));
    }
  });
  return h('div', { class: 'panel' },
    h('h1', { text: 'Reset your password' }),
    h('p', { class: 'meta', text: 'Enter the email you registered with. If an account exists, we will send a link that works for one hour.' }),
    form);
}

function resetView(token) {
  if (!token) {
    return h('div', { class: 'panel' },
      h('h1', { text: 'Reset link incomplete' }),
      h('p', {}, 'This page needs the link from your email. ', h('a', { href: '#/forgot', text: 'Request a new reset link' })));
  }
  clearTokenFromUrl('#/reset');
  const status = h('div', { role: 'status' });
  const form = h('form', { class: 'stack' },
    h('label', {}, 'New password', h('input', { name: 'password', type: 'password', required: true, minlength: 10, maxlength: 128, autocomplete: 'new-password' })),
    h('label', {}, 'Confirm new password', h('input', { name: 'confirm', type: 'password', required: true, minlength: 10, maxlength: 128, autocomplete: 'new-password' })),
    h('button', { type: 'submit', text: 'Set new password' }),
    status);
  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    const data = Object.fromEntries(new FormData(form));
    if (data.password !== data.confirm) {
      status.replaceChildren(alertBox('The two passwords do not match.'));
      return;
    }
    try {
      await api('/auth/reset-password', { method: 'POST', body: { token, password: data.password } });
      state.user = null;
      renderNav();
      toast('Password updated. Sign in with your new password.');
      location.hash = '#/login';
    } catch (error) {
      status.replaceChildren(alertBox(errorMessage(error)));
    }
  });
  return h('div', { class: 'panel' }, h('h1', { text: 'Choose a new password' }), form);
}

function verifyView(token) {
  clearTokenFromUrl('#/verify');
  const panel = h('div', { class: 'panel' }, h('h1', { text: 'Confirming your email' }), h('p', { class: 'muted', text: 'One moment…' }));
  api('/auth/verify-email', { method: 'POST', body: { token } })
    .then(() => {
      if (state.user) state.user.emailVerified = true;
      panel.replaceChildren(
        h('h1', { text: 'Email confirmed' }),
        h('p', { text: 'Thanks. Your account is verified.' }),
        h('a', { class: 'button', href: state.user ? '#/mine' : '#/login', text: state.user ? 'Go to my listings' : 'Sign in' }));
    })
    .catch((error) => {
      panel.replaceChildren(
        h('h1', { text: 'Link not valid' }),
        alertBox(errorMessage(error)),
        h('p', {}, h('a', { href: state.user ? '#/mine' : '#/login', text: state.user ? 'Back to my listings' : 'Sign in' }), ' to request a new link.'));
    });
  return panel;
}

// Shown to signed-in accounts whose email is not confirmed yet.
function verificationBanner() {
  if (!state.user || state.user.emailVerified) return null;
  const button = h('button', { type: 'button', class: 'secondary', text: 'Send a new link' });
  button.addEventListener('click', async () => {
    button.disabled = true;
    try {
      await api('/auth/resend-verification', { method: 'POST', body: {} });
      toast('A new confirmation link is on its way. Check your spam folder if it does not arrive.');
    } catch (error) {
      toast(errorMessage(error), 'error');
    } finally {
      button.disabled = false;
    }
  });
  return h('div', { class: 'alert info', role: 'status' },
    h('strong', { text: 'Confirm your email address. ' }),
    'Check your inbox for the link we sent when you registered. ',
    button);
}

async function adminView() {
  if (state.user?.role !== 'admin') return alertBox('Administrator access is required.');
  loading();
  const filter = h('select', { 'aria-label': 'Job status' }, options(['queued', 'running', 'done', 'failed'], {}, 'failed', 'All'));
  const body = h('tbody');
  async function load() {
    const params = new URLSearchParams({ limit: 100 });
    if (filter.value) params.set('status', filter.value);
    const { items } = await api(`/admin/jobs?${params}`);
    body.replaceChildren(...(items.length ? items.map((job) => {
      const retry = h('button', { class: 'secondary', type: 'button', text: 'Retry', disabled: job.status !== 'failed' ? true : undefined });
      retry.addEventListener('click', async () => {
        try {
          await api(`/admin/jobs/${encodeURIComponent(job.id)}/retry`, { method: 'POST' });
          toast('Job requeued.');
          load();
        } catch (error) {
          toast(errorMessage(error), 'error');
        }
      });
      return h('tr', {}, h('td', { text: job.type }), h('td', { text: job.status }),
        h('td', { text: `${job.attempts}/${job.maxAttempts}` }), h('td', { text: dateText(job.updatedAt) }),
        h('td', { text: job.lastError || '' }), h('td', {}, retry));
    }) : [h('tr', {}, h('td', { colspan: 6, text: 'No jobs.' }))]));
  }
  filter.addEventListener('change', load);
  load().catch((error) => body.replaceChildren(h('tr', {}, h('td', { colspan: 6 }, alertBox(errorMessage(error))))));
  return h('section', {},
    h('div', { class: 'actions' }, h('h1', { text: 'Background jobs' }), filter),
    h('p', { class: 'meta', text: 'Failed jobs stop retrying after the maximum attempts. Retry them once the underlying problem is fixed.' }),
    h('div', { class: 'table-wrap' }, h('table', {},
      h('thead', {}, h('tr', {}, ['Type', 'Status', 'Attempts', 'Updated', 'Last error', ''].map((label) => h('th', { text: label })))), body)));
}

function requireAuth(view) {
  return (...args) => (state.user
    ? view(...args)
    : h('div', { class: 'panel' }, h('p', { text: 'Please sign in to continue.' }), h('a', { class: 'button', href: '#/login', text: 'Sign in' })));
}

const ROUTES = [
  [/^#?\/?$/, () => browseView()],
  [/^#\/listings\/([^/]+)$/, (id) => listingDetailView(decodeURIComponent(id))],
  [/^#\/compare$/, () => compareView()],
  [/^#\/sell$/, requireAuth(() => sellView())],
  [/^#\/sell\/([^/]+)$/, requireAuth((id) => sellView(decodeURIComponent(id)))],
  [/^#\/mine$/, requireAuth(() => mineView())],
  [/^#\/inquiries$/, requireAuth(() => inquiriesView())],
  [/^#\/login$/, () => authForm('login')],
  [/^#\/register$/, () => authForm('register')],
  [/^#\/forgot$/, () => forgotView()],
  [/^#\/reset$/, () => resetView('')],
  [/^#\/reset\/([^/]+)$/, (token) => resetView(decodeURIComponent(token))],
  [/^#\/verify\/([^/]+)$/, (token) => verifyView(decodeURIComponent(token))],
  [/^#\/admin$/, () => adminView()]
];

let renderId = 0;
async function render() {
  const id = ++renderId;
  const hash = location.hash || '#/';
  renderNav();
  const route = ROUTES.find(([pattern]) => pattern.test(hash));
  if (!route) {
    setView(h('div', { class: 'panel' }, h('h1', { text: 'Page not found' }), h('a', { href: '#/', text: 'Back to browsing' })));
    return;
  }
  const args = hash.match(route[0]).slice(1);
  try {
    const node = await route[1](...args);
    if (id === renderId) {
      const banner = hash.startsWith('#/verify') || hash.startsWith('#/reset') ? null : verificationBanner();
      setView(...[banner, node].filter(Boolean));
    }
  } catch (error) {
    if (id === renderId) setView(alertBox(errorMessage(error)));
  }
}

async function start() {
  try {
    const [session, facets] = await Promise.all([
      api('/auth/me').catch(() => ({ user: null })),
      api('/facets')
    ]);
    state.user = session.user;
    state.facets = facets;
  } catch (error) {
    toast(`Could not load RutaMotor: ${errorMessage(error)}`, 'error');
  }
  window.addEventListener('hashchange', render);
  render();
}

start();
