// Applies pending database migrations: `npm run migrate`.
import { bootstrap } from '../src/bootstrap.js';
import { migrate } from '../src/db.js';

const { db, logger } = await bootstrap({ migrateSchema: false });
try {
  const applied = await migrate(db);
  logger.info('migrate.done', { dialect: db.dialect, applied });
} finally {
  await db.close();
}
