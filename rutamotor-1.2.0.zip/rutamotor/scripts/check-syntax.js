// Parses every JavaScript file with `node --check`. Works on any OS without shell globbing.
import { readdirSync, statSync } from 'node:fs';
import path from 'node:path';
import { execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const SKIP = new Set(['node_modules', '.git', 'data']);

function walk(dir, out = []) {
  for (const name of readdirSync(dir)) {
    if (SKIP.has(name)) continue;
    const full = path.join(dir, name);
    if (statSync(full).isDirectory()) walk(full, out);
    else if (name.endsWith('.js')) out.push(full);
  }
  return out;
}

const files = ['src', 'scripts', 'test', 'public'].flatMap((dir) => walk(path.join(root, dir)));
let failures = 0;
for (const file of files) {
  try {
    execFileSync(process.execPath, ['--check', file], { stdio: 'pipe' });
  } catch (error) {
    failures += 1;
    console.error(`Syntax error in ${path.relative(root, file)}:\n${error.stderr?.toString() || error.message}`);
  }
}
console.log(`Checked ${files.length} files, ${failures} with errors.`);
process.exit(failures ? 1 : 0);
