// Adds FICTIONAL demo sellers and listings for local development: `npm run seed`.
// Never run against production data. Demo accounts are skipped if they already exist.
import crypto from 'node:crypto';
import { bootstrap } from '../src/bootstrap.js';
import * as store from '../src/store.js';
import { hashPassword } from '../src/security.js';

const { db, logger } = await bootstrap();
const password = process.env.DEMO_PASSWORD || crypto.randomBytes(9).toString('base64url');
const now = new Date().toISOString();

const sellers = [
  { name: 'Demo Seller Alpha', email: 'seller.alpha@demo.rutamotor.invalid' },
  { name: 'Demo Seller Bravo', email: 'seller.bravo@demo.rutamotor.invalid' }
];

const cars = [
  { seller: 0, make: 'Toyota', model: 'Corolla', trim: 'XLI', year: 2021, price: 12500000, mileage: 45000, transmission: 'automatic', fuel: 'petrol', body: 'sedan', engineCc: 1800, region: 'Metropolitan Region', city: 'Ñuñoa', description: 'Demo listing. Single owner, well maintained, service records available on request.' },
  { seller: 0, make: 'Hyundai', model: 'Tucson', trim: 'GLS', year: 2019, price: 15900000, mileage: 78000, transmission: 'automatic', fuel: 'diesel', body: 'suv', engineCc: 2000, region: 'Valparaíso Region', city: 'Viña del Mar', description: 'Demo listing. Spacious family SUV with recent tyres and a full set of keys.' },
  { seller: 1, make: 'Suzuki', model: 'Swift', trim: 'GL', year: 2020, price: 8490000, mileage: 31000, transmission: 'manual', fuel: 'petrol', body: 'hatchback', engineCc: 1200, region: 'Metropolitan Region', city: 'Providencia', description: 'Demo listing. Economical city hatchback, ideal for first-time buyers.' },
  { seller: 1, make: 'Ford', model: 'Ranger', trim: 'XLT', year: 2018, price: 21900000, mileage: 110000, transmission: 'automatic', fuel: 'diesel', body: 'pickup', engineCc: 3200, region: 'Biobío Region', city: 'Concepción', description: 'Demo listing. Work-ready pickup with tow bar and bed liner.' },
  { seller: 1, make: 'Kia', model: 'Sportage', trim: 'EX', year: 2022, price: 18900000, mileage: 22000, transmission: 'automatic', fuel: 'hybrid', body: 'suv', engineCc: 1600, region: 'Metropolitan Region', city: 'Las Condes', description: 'Demo listing. Low mileage hybrid with lane assist and reversing camera.' }
];

try {
  const existing = await store.findUserByEmail(db, sellers[0].email);
  if (existing) {
    logger.info('seed.skipped', { reason: 'demo accounts already exist' });
  } else {
    const ids = [];
    const passwordHash = await hashPassword(password);
    for (const seller of sellers) {
      const id = crypto.randomUUID();
      ids.push(id);
      await store.insertUser(db, { id, name: seller.name, email: seller.email, passwordHash, role: 'user', phone: '', whatsappOptIn: false, createdAt: now, emailVerifiedAt: now });
    }
    for (const car of cars) {
      await store.insertListing(db, { id: crypto.randomUUID(), sellerId: ids[car.seller], sellerType: 'private', engineCc: car.engineCc, now, ...car });
    }
    logger.info('seed.done', { sellers: sellers.length, listings: cars.length });
    // Printed directly, not through the logger, because the logger redacts credential-like fields.
    if (!process.env.DEMO_PASSWORD) console.log(`Demo seller password (shown once, not stored): ${password}`);
  }
} finally {
  await db.close();
}
