// Small HTTP toolkit on top of node:http: errors, JSON I/O, routing, rate limits, security headers.

export class HttpError extends Error {
  constructor(status, message, { details, headers } = {}) {
    super(message);
    this.status = status;
    this.details = details;
    this.headers = headers;
  }
}

export const CONTENT_SECURITY_POLICY = [
  "default-src 'self'",
  "img-src 'self' data: blob:",
  "style-src 'self'",
  "script-src 'self'",
  "connect-src 'self'",
  "font-src 'self'",
  "object-src 'none'",
  "base-uri 'none'",
  "frame-ancestors 'none'",
  "form-action 'self'"
].join('; ');

export function securityHeaders(res, { production }) {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
  res.setHeader('Cross-Origin-Opener-Policy', 'same-origin');
  if (production) res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
}

export function sendJson(res, status, body, headers = {}) {
  const payload = JSON.stringify(body);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': Buffer.byteLength(payload),
    'Cache-Control': 'no-store',
    ...headers
  });
  res.end(payload);
}

export function sendRaw(res, status, body, headers = {}) {
  res.writeHead(status, { 'Content-Length': Buffer.byteLength(body), ...headers });
  res.end(body);
}

/** Reads a JSON body. Requires application/json for non-empty bodies. */
export async function readJson(req, limitBytes) {
  const declared = Number(req.headers['content-length'] || 0);
  if (!declared && !req.headers['transfer-encoding']) return {};
  const type = String(req.headers['content-type'] || '').split(';')[0].trim().toLowerCase();
  if (type !== 'application/json') throw new HttpError(415, 'Content-Type must be application/json.');
  if (declared > limitBytes) throw new HttpError(413, 'Request body is too large.');
  const chunks = [];
  let size = 0;
  for await (const chunk of req) {
    size += chunk.length;
    if (size > limitBytes) throw new HttpError(413, 'Request body is too large.');
    chunks.push(chunk);
  }
  if (!size) return {};
  try {
    return JSON.parse(Buffer.concat(chunks).toString('utf8'));
  } catch {
    throw new HttpError(400, 'Request body is not valid JSON.');
  }
}

/** Minimal router with `:param` segments. Methods are matched after the path. */
export function createRouter() {
  const routes = [];
  const add = (method) => (pattern, options, handler) => {
    if (typeof options === 'function') {
      handler = options;
      options = {};
    }
    const keys = [];
    // Odd parts of the split are the `:param` names; even parts are literals and must be regex-escaped.
    const source = pattern.split(/:([A-Za-z]+)/).map((part, index) => {
      if (index % 2 === 1) {
        keys.push(part);
        return '([^/]+)';
      }
      return part.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    }).join('');
    routes.push({ method, regex: new RegExp(`^${source}$`), keys, handler, ...options });
  };
  return {
    get: add('GET'),
    post: add('POST'),
    patch: add('PATCH'),
    delete: add('DELETE'),
    match(method, pathname) {
      let pathMatched = false;
      for (const route of routes) {
        const found = route.regex.exec(pathname);
        if (!found) continue;
        pathMatched = true;
        if (route.method !== method) continue;
        const params = {};
        route.keys.forEach((key, index) => {
          try {
            params[key] = decodeURIComponent(found[index + 1]);
          } catch {
            params[key] = found[index + 1];
          }
        });
        return { route, params, pathMatched: true };
      }
      return { route: null, params: {}, pathMatched };
    }
  };
}

/** Fixed-window rate limiter kept in memory (one instance per process). */
export function createRateLimiter({ now = () => Date.now() } = {}) {
  const buckets = new Map();
  const prune = (time) => {
    for (const [key, bucket] of buckets) {
      if (bucket.reset <= time) buckets.delete(key);
    }
  };
  return {
    hit(key, limit, windowMs) {
      const time = now();
      let bucket = buckets.get(key);
      if (!bucket || bucket.reset <= time) {
        bucket = { count: 0, reset: time + windowMs };
        buckets.set(key, bucket);
      }
      bucket.count += 1;
      if (buckets.size > 50_000) prune(time);
      return {
        allowed: bucket.count <= limit,
        retryAfterSeconds: Math.max(1, Math.ceil((bucket.reset - time) / 1000))
      };
    }
  };
}

export function clientIp(req, trustProxy) {
  if (trustProxy) {
    const forwarded = String(req.headers['x-forwarded-for'] || '').split(',')[0].trim();
    if (forwarded) return forwarded;
  }
  return req.socket.remoteAddress || 'unknown';
}

export function readCookie(header, name) {
  if (!header) return null;
  for (const part of String(header).split(';')) {
    const index = part.indexOf('=');
    if (index === -1) continue;
    if (part.slice(0, index).trim() === name) return part.slice(index + 1).trim();
  }
  return null;
}
