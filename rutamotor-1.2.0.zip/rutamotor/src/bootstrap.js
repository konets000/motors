import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { loadConfig } from './config.js';
import { createDatabase, migrate } from './db.js';
import { createServices } from './services.js';
import { createLogger } from './logger.js';

/**
 * Development only: a secret shared by every local process, kept in ./data (git-ignored).
 * Without it, the API and the worker would generate different secrets and the worker could not open
 * the one-time links the API sealed into the job queue. Production never uses this; it requires AUTH_SECRET.
 */
export function devAuthSecret(dataDir = path.resolve('data')) {
  const file = path.join(dataDir, '.dev-auth-secret');
  if (fs.existsSync(file)) return fs.readFileSync(file, 'utf8').trim();
  fs.mkdirSync(dataDir, { recursive: true });
  const secret = crypto.randomBytes(32).toString('hex');
  try {
    fs.writeFileSync(file, secret, { mode: 0o600, flag: 'wx' });
    return secret;
  } catch (error) {
    // Another process created it first; use that one.
    if (error.code === 'EEXIST') return fs.readFileSync(file, 'utf8').trim();
    throw error;
  }
}

/**
 * Shared startup for the API server and the worker: .env, configuration, database, migrations, integrations.
 */
export async function bootstrap({ env = process.env, migrateSchema = true, logger = createLogger() } = {}) {
  if (env === process.env && fs.existsSync('.env') && typeof process.loadEnvFile === 'function') {
    process.loadEnvFile('.env');
  }
  if (!env.AUTH_SECRET && (env.NODE_ENV || 'development') !== 'production') {
    env = { ...env, AUTH_SECRET: devAuthSecret() };
  }
  const config = loadConfig(env);
  const db = await createDatabase(config.databaseUrl);
  if (migrateSchema && config.migrateOnStart) {
    const applied = await migrate(db);
    if (applied.length) logger.info('db.migrated', { versions: applied });
  }
  if (config.production && config.email.provider === 'log') {
    logger.warn('config.email_provider_log', { message: 'Emails are only logged. Set EMAIL_PROVIDER=resend for production.' });
  }
  const services = createServices(config, { logger });
  return { config, db, services, logger, now: () => new Date() };
}
