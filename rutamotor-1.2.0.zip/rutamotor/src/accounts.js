// Account email flows: one-time links for email verification and password reset, and a password-change notice.
import { escapeHtml } from './domain.js';

const HOUR_MS = 60 * 60 * 1000;

/** How long each kind of link stays valid. */
export const ACCOUNT_TOKEN_TTL_MS = {
  verify_email: 72 * HOUR_MS,
  reset_password: HOUR_MS
};

/** Tokens travel in the URL fragment, which browsers never send to the server or write to server logs. */
export function accountLink(appUrl, purpose, token) {
  return `${appUrl}/#/${purpose === 'verify_email' ? 'verify' : 'reset'}/${token}`;
}

const COPY = {
  verify_email: {
    subject: 'Confirm your RutaMotor email address',
    intro: 'Confirm your email address to finish setting up your RutaMotor account.',
    action: 'Confirm email address',
    expiry: 'This link expires in 72 hours and works once.'
  },
  reset_password: {
    subject: 'Reset your RutaMotor password',
    intro: 'We received a request to reset your RutaMotor password. If it was not you, ignore this email and your password will not change.',
    action: 'Choose a new password',
    expiry: 'This link expires in 1 hour and works once.'
  },
  password_changed: {
    subject: 'Your RutaMotor password was changed',
    intro: 'The password for your RutaMotor account was just changed. If this was not you, reset your password right away.',
    action: null,
    expiry: null
  }
};

/** Returns { subject, text, html } for an account message. `link` is required for the two token kinds. */
export function renderAccountEmail(kind, { name, link }) {
  const copy = COPY[kind];
  if (!copy) throw new Error(`Unknown account email: ${kind}`);
  const greeting = `Hi ${name || 'there'},`;
  const lines = [greeting, '', copy.intro];
  if (link) lines.push('', link);
  if (copy.expiry) lines.push('', copy.expiry);
  const htmlParts = [`<p>${escapeHtml(greeting)}</p>`, `<p>${escapeHtml(copy.intro)}</p>`];
  if (link) htmlParts.push(`<p><a href="${escapeHtml(link)}">${escapeHtml(copy.action)}</a></p>`);
  if (copy.expiry) htmlParts.push(`<p>${escapeHtml(copy.expiry)}</p>`);
  return { subject: copy.subject, text: lines.join('\n'), html: htmlParts.join('') };
}
