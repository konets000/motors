import crypto from 'node:crypto';

const isTrue = (value) => ['1', 'true', 'yes', 'on'].includes(String(value ?? '').trim().toLowerCase());
const list = (value) => String(value ?? '').split(',').map((item) => item.trim()).filter(Boolean);
const int = (value, fallback) => {
  if (value === undefined || value === null || String(value).trim() === '') return fallback;
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : fallback;
};

/**
 * Reads and validates configuration from environment variables.
 * Throws early on unsafe production settings so the process never starts half-configured.
 */
export function loadConfig(env = process.env) {
  const nodeEnv = env.NODE_ENV || 'development';
  const production = nodeEnv === 'production';

  let authSecret = env.AUTH_SECRET || '';
  if (authSecret && authSecret.length < 32) {
    throw new Error('AUTH_SECRET must be at least 32 characters long.');
  }
  if (!authSecret) {
    if (production) throw new Error('AUTH_SECRET must be set in production (at least 32 random characters).');
    // Development only: a random secret means sessions are invalidated on restart.
    authSecret = crypto.randomBytes(32).toString('hex');
  }

  const emailProvider = env.EMAIL_PROVIDER || 'log';
  if (!['log', 'resend', 'disabled'].includes(emailProvider)) {
    throw new Error('EMAIL_PROVIDER must be one of: log, resend, disabled.');
  }

  const webhookUrl = env.WEBHOOK_URL || '';
  if (webhookUrl && production && !webhookUrl.startsWith('https://')) {
    throw new Error('WEBHOOK_URL must use https:// in production.');
  }

  // Public address of the web app. Links in account emails are built from it.
  const rawAppUrl = String(env.APP_URL || '').trim();
  if (production && !rawAppUrl) {
    throw new Error('APP_URL must be set in production (the public https address of the web app).');
  }
  const appUrl = rawAppUrl.replace(/\/+$/, '') || 'http://localhost:3000';
  if (production && !appUrl.startsWith('https://')) {
    throw new Error('APP_URL must use https:// in production.');
  }

  const rateLimitStore = String(env.RATE_LIMIT_STORE || 'memory').trim().toLowerCase();
  if (!['memory', 'database'].includes(rateLimitStore)) {
    throw new Error('RATE_LIMIT_STORE must be one of: memory, database.');
  }

  return {
    env: nodeEnv,
    production,
    host: env.HOST || '0.0.0.0',
    port: int(env.PORT, 3000),
    appUrl,
    databaseUrl: env.DATABASE_URL || 'sqlite:./data/rutamotor.db',
    migrateOnStart: env.MIGRATE_ON_START !== 'false',
    workerInProcess: isTrue(env.WORKER_IN_PROCESS),
    authSecret,
    sessionTtlSeconds: int(env.SESSION_TTL_SECONDS, 43200),
    trustProxy: isTrue(env.TRUST_PROXY),
    corsOrigins: list(env.CORS_ORIGINS),
    adminEmails: list(env.ADMIN_EMAILS).map((email) => email.toLowerCase()),
    requireVerifiedEmail: isTrue(env.REQUIRE_VERIFIED_EMAIL),
    rateLimitStore,
    currency: env.CURRENCY || 'CLP',
    uploadDir: env.UPLOAD_DIR || './data/uploads',
    maxPhotoBytes: int(env.MAX_PHOTO_BYTES, 5 * 1024 * 1024),
    maxPhotosPerListing: int(env.MAX_PHOTOS_PER_LISTING, 10),
    email: {
      provider: emailProvider,
      resendApiKey: env.RESEND_API_KEY || '',
      from: env.MAIL_FROM || ''
    },
    whatsapp: {
      accessToken: env.WHATSAPP_ACCESS_TOKEN || '',
      phoneNumberId: env.WHATSAPP_PHONE_NUMBER_ID || '',
      graphVersion: env.WHATSAPP_GRAPH_API_VERSION || '',
      leadTemplate: env.WHATSAPP_LEAD_TEMPLATE || 'lead_received',
      language: env.WHATSAPP_TEMPLATE_LANGUAGE || 'en'
    },
    ai: {
      baseUrl: env.AI_BASE_URL || 'https://api.openai.com/v1',
      apiKey: env.AI_API_KEY || '',
      model: env.AI_MODEL || '',
      timeoutMs: int(env.AI_TIMEOUT_MS, 20000)
    },
    webhooks: {
      url: webhookUrl,
      secret: env.WEBHOOK_SECRET || ''
    },
    compradeautos: {
      apiKey: env.COMPRADEAUTOS_API_KEY || '',
      baseUrl: env.COMPRADEAUTOS_API_BASE_URL || 'https://www.compradeautos.cl/api/v1'
    },
    worker: {
      pollMs: int(env.WORKER_POLL_MS, 3000),
      staleLockSeconds: 600,
      maxAttempts: 6,
      staleListingDays: int(env.STALE_LISTING_DAYS, 60),
      staleCheckMinutes: 360
    }
  };
}
