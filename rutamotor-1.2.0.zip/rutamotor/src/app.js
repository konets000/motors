import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import pkg from '../package.json' with { type: 'json' };
import {
  HttpError, createRouter, createRateLimiter, readJson, sendJson, sendRaw,
  securityHeaders, clientIp, readCookie, CONTENT_SECURITY_POLICY
} from './http.js';
import { hashPassword, verifyPassword, signToken, verifyToken, newToken, hashToken, sealText } from './security.js';
import { ACCOUNT_TOKEN_TTL_MS } from './accounts.js';
import { createDatabaseRateLimiter } from './rate-limit.js';
import * as store from './store.js';
import * as v from './validation.js';
import { canChangeListingStatus, toCsv, INQUIRY_CSV_COLUMNS } from './domain.js';
import { detectImage } from './media.js';
import { enqueue } from './jobs.js';
import { isUniqueViolation } from './db.js';

const PUBLIC_DIR = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../public');
const SESSION_COOKIE = 'rm_session';
const UNSAFE_METHODS = new Set(['POST', 'PATCH', 'PUT', 'DELETE']);
const MIME_TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.ico': 'image/x-icon',
  '.json': 'application/json; charset=utf-8'
};
const LIMITS = {
  auth: { name: 'auth', max: 10, windowMs: 15 * 60_000 },
  inquiry: { name: 'inquiry', max: 10, windowMs: 60_000 },
  assistant: { name: 'assistant', max: 20, windowMs: 60 * 60_000 },
  ai: { name: 'ai', max: 30, windowMs: 60 * 60_000 },
  upload: { name: 'upload', max: 60, windowMs: 60_000 },
  // Account links: low per-IP cap. Tokens are 256-bit, so this limits abuse rather than guessing.
  token: { name: 'token', max: 10, windowMs: 15 * 60_000 }
};
// Form field -> database column. Only these columns can ever be updated from a request.
const LISTING_COLUMNS = {
  make: 'make', model: 'model', trim: 'trim', year: 'year', price: 'price', mileage: 'mileage_km',
  transmission: 'transmission', fuel: 'fuel', body: 'body', engineCc: 'engine_cc', region: 'region',
  city: 'city', description: 'description', sellerType: 'seller_type'
};

const notFound = (message) => new HttpError(404, message);
const conflict = (message) => new HttpError(409, message);

function parse(schema, data) {
  const result = schema.safeParse(data);
  if (!result.success) {
    throw new HttpError(422, 'Please correct the highlighted fields.', {
      details: result.error.issues.map((issue) => ({ path: issue.path.join('.'), message: issue.message }))
    });
  }
  return result.data;
}

const publicUser = (user) => ({
  id: user.id, name: user.name, email: user.email, role: user.role, phone: user.phone || '',
  whatsappOptIn: Boolean(user.whatsappOptIn), emailVerified: Boolean(user.emailVerified)
});

/**
 * Builds the HTTP request handler. `ctx` carries config, db, services, logger and an optional clock.
 */
export function createApp(ctx) {
  const { config, db, services, logger } = ctx;
  const now = ctx.now || (() => new Date());
  const iso = () => now().toISOString();
  const newId = () => crypto.randomUUID();
  const router = createRouter();
  // Memory by default (one process). RATE_LIMIT_STORE=database shares the counters across API instances.
  const limiter = config.rateLimitStore === 'database'
    ? createDatabaseRateLimiter(db, { now: () => now().getTime() })
    : createRateLimiter({ now: () => now().getTime() });
  let dummyHashPromise = null;
  // Verifying against a fixed hash keeps login timing the same whether or not the email exists.
  const dummyHash = () => (dummyHashPromise ??= hashPassword('timing-equaliser-not-a-real-password'));

  const queue = (executor, type, payload, extra = {}) => enqueue(executor, type, payload, {
    now: now(), maxAttempts: config.worker.maxAttempts, ...extra
  });
  const audit = (executor, actorId, event, entityType, entityId, metadata = {}) => store.recordAudit(executor, {
    id: newId(), actorId, event, entityType, entityId, metadata, now: iso()
  });
  const emitWebhook = async (executor, event, data) => {
    if (services.webhooks.configured) await queue(executor, 'webhook.deliver', { event, data });
  };

  async function enforceRate(req, limit) {
    const result = await limiter.hit(`${limit.name}:${clientIp(req, config.trustProxy)}`, limit.max, limit.windowMs);
    if (!result.allowed) {
      throw new HttpError(429, 'Too many requests. Please try again later.', {
        headers: { 'Retry-After': String(result.retryAfterSeconds) }
      });
    }
  }

  async function loadListing(id) {
    if (!v.isUuid(id)) throw notFound('Listing not found.');
    const listing = await store.getListing(db, id);
    if (!listing) throw notFound('Listing not found.');
    return listing;
  }

  async function ownedListing(id, userId) {
    const listing = await loadListing(id);
    if (listing.sellerId !== userId) throw notFound('Listing not found.');
    return listing;
  }

  function issueSession(user) {
    // `v` lets a password change invalidate every session issued before it.
    return signToken({ sub: user.id, role: user.role, v: user.sessionVersion ?? 0 }, config.authSecret, config.sessionTtlSeconds, Math.floor(now().getTime() / 1000));
  }

  /**
   * Creates a single-use link token and schedules its email in the same transaction.
   * The database keeps only the hash; the job keeps the token sealed with AUTH_SECRET.
   */
  async function issueAccountToken(executor, user, purpose) {
    const token = newToken();
    const tokenId = newId();
    const current = now();
    await store.revokeAccountTokens(executor, { userId: user.id, purpose, now: current.toISOString() });
    await store.insertAccountToken(executor, {
      id: tokenId, userId: user.id, purpose, tokenHash: hashToken(token),
      expiresAt: new Date(current.getTime() + ACCOUNT_TOKEN_TTL_MS[purpose]).toISOString(),
      now: current.toISOString()
    });
    await queue(executor, 'account.token_email', { userId: user.id, purpose, tokenId, sealed: sealText(token, config.authSecret) });
  }

  function requireVerifiedEmail(user) {
    if (config.requireVerifiedEmail && !user.emailVerified) {
      throw new HttpError(403, 'Verify your email address before publishing listings. Check your inbox or request a new link.');
    }
  }

  const cookieSuffix = config.production ? '; Secure' : '';
  const sessionCookie = (token) => `${SESSION_COOKIE}=${token}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${config.sessionTtlSeconds}${cookieSuffix}`;
  const clearedCookie = `${SESSION_COOKIE}=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0${cookieSuffix}`;

  /** Bearer tokens are used by API clients; the HttpOnly cookie is used by the web app. */
  async function authenticate(req) {
    const header = String(req.headers.authorization || '');
    let token = null;
    let viaCookie = false;
    if (header.startsWith('Bearer ')) {
      token = header.slice(7).trim();
    } else {
      token = readCookie(req.headers.cookie, SESSION_COOKIE);
      viaCookie = Boolean(token);
    }
    if (!token) return { user: null, viaCookie: false };
    const claims = verifyToken(token, config.authSecret, Math.floor(now().getTime() / 1000));
    if (!claims) return { user: null, viaCookie };
    const row = await store.findUserById(db, claims.sub);
    // Sessions issued before a password change carry an older version and stop working here.
    if (!row || row.sessionVersion !== Number(claims.v ?? 0)) return { user: null, viaCookie };
    return { user: row, viaCookie };
  }

  /** Cookie-authenticated writes must come from our own origin (CSRF defence in depth). */
  function assertSameOriginWrite(req) {
    const site = req.headers['sec-fetch-site'];
    if (site && site !== 'same-origin' && site !== 'none') throw new HttpError(403, 'Cross-site requests are not allowed.');
    const origin = req.headers.origin;
    if (!origin) return;
    let originHost = '';
    try {
      originHost = new URL(origin).host;
    } catch {
      throw new HttpError(403, 'Origin not allowed.');
    }
    if (originHost !== req.headers.host && !config.corsOrigins.includes(origin)) throw new HttpError(403, 'Origin not allowed.');
  }

  function corsHeaders(req) {
    const origin = req.headers.origin;
    if (!origin || !config.corsOrigins.includes(origin)) return {};
    return {
      'Access-Control-Allow-Origin': origin,
      'Access-Control-Allow-Credentials': 'true',
      'Access-Control-Allow-Methods': 'GET,POST,PATCH,DELETE,OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type,Authorization',
      'Access-Control-Max-Age': '600',
      Vary: 'Origin'
    };
  }

  // ---- Health and reference data ----------------------------------------------------

  router.get('/api/health', async () => {
    try {
      await db.ping();
      return { body: { ok: true, database: 'up', dialect: db.dialect, version: pkg.version } };
    } catch {
      return { status: 503, body: { ok: false, database: 'down' } };
    }
  });

  router.get('/api/facets', async () => ({
    body: {
      currency: config.currency,
      limits: { maxPhotoBytes: config.maxPhotoBytes, maxPhotosPerListing: config.maxPhotosPerListing },
      ...(await store.facets(db)),
      bodies: v.BODIES,
      fuels: v.FUELS,
      transmissions: v.TRANSMISSIONS,
      sorts: v.SORTS
    }
  }));

  // ---- Accounts ---------------------------------------------------------------------

  router.post('/api/auth/register', { limit: LIMITS.auth }, async ({ body }) => {
    const input = parse(v.registerSchema, body);
    if (await store.findUserByEmail(db, input.email)) throw conflict('An account with this email already exists.');
    const user = {
      id: newId(),
      name: input.name,
      email: input.email,
      passwordHash: await hashPassword(input.password),
      role: config.adminEmails.includes(input.email) ? 'admin' : 'user',
      phone: input.phone || '',
      whatsappOptIn: Boolean(input.whatsappOptIn),
      createdAt: iso(),
      sessionVersion: 0
    };
    try {
      await db.transaction(async (tx) => {
        await store.insertUser(tx, user);
        await audit(tx, user.id, 'user.registered', 'user', user.id);
        await issueAccountToken(tx, user, 'verify_email');
      });
    } catch (error) {
      if (isUniqueViolation(error)) throw conflict('An account with this email already exists.');
      throw error;
    }
    const token = issueSession(user);
    return { status: 201, body: { user: publicUser(user), token }, headers: { 'Set-Cookie': sessionCookie(token) } };
  });

  router.post('/api/auth/login', { limit: LIMITS.auth }, async ({ body }) => {
    const input = parse(v.loginSchema, body);
    const row = await store.findUserByEmail(db, input.email);
    const passwordOk = await verifyPassword(input.password, row ? row.password_hash : await dummyHash());
    if (!row || !passwordOk) throw new HttpError(401, 'Incorrect email or password.');
    const user = store.mapUser(row);
    const token = issueSession(user);
    return { body: { user: publicUser(user), token }, headers: { 'Set-Cookie': sessionCookie(token) } };
  });

  router.post('/api/auth/logout', async () => ({ body: { ok: true }, headers: { 'Set-Cookie': clearedCookie } }));

  // Logout only clears this browser's cookie. A token copied elsewhere stays valid until this runs,
  // which ends every session of the account (phones, other browsers, API clients).
  router.post('/api/auth/sessions/revoke-all', { auth: 'required' }, async ({ user }) => {
    await db.transaction(async (tx) => {
      await store.revokeSessions(tx, { userId: user.id });
      await audit(tx, user.id, 'user.sessions_revoked', 'user', user.id);
    });
    return { body: { ok: true }, headers: { 'Set-Cookie': clearedCookie } };
  });

  router.get('/api/auth/me', { auth: 'required' }, async ({ user }) => ({ body: { user: publicUser(user) } }));

  // ---- Email verification and password reset ----------------------------------------
  // Every response that depends on whether an account exists is identical, so the API does not reveal who has an account.

  router.post('/api/auth/verify-email', { limit: LIMITS.token }, async ({ body }) => {
    const input = parse(v.tokenSchema, body);
    const verified = await db.transaction(async (tx) => {
      const userId = await store.consumeAccountToken(tx, { tokenHash: hashToken(input.token), purpose: 'verify_email', now: iso() });
      if (!userId) return false;
      await store.markEmailVerified(tx, { userId, now: iso() });
      await audit(tx, userId, 'user.email_verified', 'user', userId);
      return true;
    });
    if (!verified) throw new HttpError(400, 'This link is invalid or has expired. Request a new one from your account.');
    return { body: { ok: true } };
  });

  router.post('/api/auth/resend-verification', { auth: 'required', limit: LIMITS.token }, async ({ user }) => {
    if (user.emailVerified) return { body: { ok: true, alreadyVerified: true } };
    const perUser = await limiter.hit(`resend-verification:${user.id}`, 3, 60 * 60_000);
    if (!perUser.allowed) {
      throw new HttpError(429, 'Too many requests. Please try again later.', { headers: { 'Retry-After': String(perUser.retryAfterSeconds) } });
    }
    await db.transaction((tx) => issueAccountToken(tx, user, 'verify_email'));
    return { body: { ok: true, alreadyVerified: false } };
  });

  router.post('/api/auth/forgot-password', { limit: LIMITS.token }, async ({ body }) => {
    const input = parse(v.emailOnlySchema, body);
    const response = { ok: true, message: 'If an account exists for that email, we have sent reset instructions.' };
    // A per-address cap stops one inbox being flooded from many IP addresses. The response is the same either way.
    const perAddress = await limiter.hit(`reset-address:${hashToken(input.email)}`, 3, 60 * 60_000);
    if (!perAddress.allowed) return { body: response };
    const row = await store.findUserByEmail(db, input.email);
    if (row) await db.transaction((tx) => issueAccountToken(tx, store.mapUser(row), 'reset_password'));
    return { body: response };
  });

  router.post('/api/auth/reset-password', { limit: LIMITS.token }, async ({ body }) => {
    const input = parse(v.resetPasswordSchema, body);
    const passwordHash = await hashPassword(input.password);
    const reset = await db.transaction(async (tx) => {
      const userId = await store.consumeAccountToken(tx, { tokenHash: hashToken(input.token), purpose: 'reset_password', now: iso() });
      if (!userId) return false;
      // Bumps session_version (signs out other sessions) and proves the inbox, so the email counts as verified.
      await store.updatePassword(tx, { userId, passwordHash, now: iso() });
      await store.revokeAccountTokens(tx, { userId, purpose: 'reset_password', now: iso() });
      await audit(tx, userId, 'user.password_reset', 'user', userId);
      await queue(tx, 'account.password_changed', { userId });
      return true;
    });
    if (!reset) throw new HttpError(400, 'This link is invalid or has expired. Request a new one.');
    return { body: { ok: true } };
  });

  // ---- Public catalogue -------------------------------------------------------------

  router.get('/api/listings', async ({ query }) => {
    const filters = parse(v.listingsQuerySchema, Object.fromEntries(query));
    const result = await store.searchListings(db, filters);
    return { body: { items: result.items, total: result.total, limit: filters.limit, offset: filters.offset } };
  });

  router.get('/api/listings/:id', { auth: 'optional' }, async ({ params, user }) => {
    const listing = await loadListing(params.id);
    const isOwner = Boolean(user && user.id === listing.sellerId);
    if (listing.status !== 'active' && !isOwner) throw notFound('Listing not found.');
    const photos = (await store.listPhotos(db, listing.id)).map(store.mapPhoto);
    return { body: { item: listing, photos, isOwner } };
  });

  // ---- Seller: listings -------------------------------------------------------------

  router.post('/api/listings', { auth: 'required' }, async ({ user, body }) => {
    requireVerifiedEmail(user);
    const input = parse(v.listingSchema, body);
    const listing = {
      id: newId(),
      sellerId: user.id,
      ...input,
      trim: input.trim || '',
      engineCc: input.engineCc ?? null,
      now: iso()
    };
    await db.transaction(async (tx) => {
      await store.insertListing(tx, listing);
      await audit(tx, user.id, 'listing.created', 'listing', listing.id);
      await emitWebhook(tx, 'listing.created', { listingId: listing.id, make: listing.make, model: listing.model, year: listing.year, status: 'active' });
    });
    return { status: 201, body: { item: await store.getListing(db, listing.id) } };
  });

  router.patch('/api/listings/:id', { auth: 'required' }, async ({ user, params, body }) => {
    const listing = await ownedListing(params.id, user.id);
    if (listing.status === 'sold') throw conflict('Sold listings can no longer be edited.');
    const input = parse(v.listingUpdateSchema, body);
    const columns = {};
    for (const [field, value] of Object.entries(input)) {
      if (value !== undefined && LISTING_COLUMNS[field]) columns[LISTING_COLUMNS[field]] = value;
    }
    if (!Object.keys(columns).length) throw new HttpError(422, 'Nothing to update.');
    await db.transaction(async (tx) => {
      await store.updateListingColumns(tx, { id: listing.id, sellerId: user.id, columns, now: iso() });
      await audit(tx, user.id, 'listing.updated', 'listing', listing.id, { fields: Object.keys(input) });
    });
    return { body: { item: await store.getListing(db, listing.id) } };
  });

  router.patch('/api/listings/:id/status', { auth: 'required' }, async ({ user, params, body }) => {
    const input = parse(v.statusChangeSchema, body);
    if (!v.isUuid(params.id)) throw notFound('Listing not found.');
    const result = await db.transaction(async (tx) => {
      const current = await store.getListingStatus(tx, params.id);
      if (!current || current.seller_id !== user.id) throw notFound('Listing not found.');
      if (current.status === input.status) return { changed: false, status: current.status };
      if (!canChangeListingStatus(current.status, input.status)) {
        throw conflict(`A ${current.status} listing cannot change to ${input.status}.`);
      }
      await store.setListingStatus(tx, { id: params.id, status: input.status, now: iso() });
      await audit(tx, user.id, 'listing.status_changed', 'listing', params.id, { from: current.status, to: input.status });
      await emitWebhook(tx, 'listing.status_changed', { listingId: params.id, status: input.status });
      return { changed: true, status: input.status };
    });
    return { body: result };
  });

  router.post('/api/listings/:id/renew', { auth: 'required' }, async ({ user, params }) => {
    const listing = await ownedListing(params.id, user.id);
    if (listing.status !== 'active') throw conflict('Only active listings can be renewed.');
    await db.transaction(async (tx) => {
      await store.renewListing(tx, { id: listing.id, sellerId: user.id, now: iso() });
      await audit(tx, user.id, 'listing.renewed', 'listing', listing.id);
    });
    return { body: { item: await store.getListing(db, listing.id) } };
  });

  router.get('/api/me/listings', { auth: 'required' }, async ({ user }) => ({
    body: { items: await store.listOwnerListings(db, user.id) }
  }));

  // ---- Photos -----------------------------------------------------------------------

  router.post('/api/listings/:id/photos', {
    auth: 'required',
    limit: LIMITS.upload,
    bodyLimit: Math.ceil((config.maxPhotoBytes * 4) / 3) + 2048
  }, async ({ user, params, body }) => {
    const listing = await ownedListing(params.id, user.id);
    if (listing.status === 'sold' || listing.status === 'archived') throw conflict('Photos cannot be added to this listing.');
    const input = parse(v.photoUploadSchema, body);
    if (input.dataBase64.length > Math.ceil((config.maxPhotoBytes * 4) / 3) + 4) {
      throw new HttpError(413, `Each photo must be ${Math.round(config.maxPhotoBytes / 1024 / 1024)} MB or smaller.`);
    }
    const bytes = Buffer.from(input.dataBase64, 'base64');
    if (!bytes.length) throw new HttpError(422, 'The uploaded file is empty.');
    if (bytes.length > config.maxPhotoBytes) throw new HttpError(413, `Each photo must be ${Math.round(config.maxPhotoBytes / 1024 / 1024)} MB or smaller.`);
    const image = detectImage(bytes);
    if (!image) throw new HttpError(422, 'Upload a JPEG, PNG or WebP image.');

    const storageKey = await services.storage.save(bytes, image.ext);
    try {
      const photo = await db.transaction(async (tx) => {
        // Row lock on the listing (FOR UPDATE on PostgreSQL): concurrent uploads queue here, so the count below is current.
        const current = await store.getListingStatus(tx, listing.id);
        if (!current || current.seller_id !== user.id) throw notFound('Listing not found.');
        if (current.status === 'sold' || current.status === 'archived') throw conflict('Photos cannot be added to this listing.');
        const count = await store.countPhotos(tx, listing.id);
        if (count >= config.maxPhotosPerListing) throw conflict(`A listing can have at most ${config.maxPhotosPerListing} photos.`);
        const id = newId();
        await store.insertPhoto(tx, {
          id, listingId: listing.id, storageKey, contentType: image.contentType,
          sizeBytes: bytes.length, position: count, createdAt: iso()
        });
        return { id, position: count };
      });
      return {
        status: 201,
        body: { photo: store.mapPhoto({ id: photo.id, listing_id: listing.id, content_type: image.contentType, size_bytes: bytes.length, position: photo.position }) }
      };
    } catch (error) {
      await services.storage.remove(storageKey);
      throw error;
    }
  });

  router.delete('/api/listings/:id/photos/:photoId', { auth: 'required' }, async ({ user, params }) => {
    const listing = await ownedListing(params.id, user.id);
    if (!v.isUuid(params.photoId)) throw notFound('Photo not found.');
    const removed = await db.transaction(async (tx) => {
      const row = await store.deletePhoto(tx, { id: params.photoId, listingId: listing.id });
      if (row) await audit(tx, user.id, 'photo.deleted', 'listing', listing.id, { photoId: params.photoId });
      return row;
    });
    if (!removed) throw notFound('Photo not found.');
    await services.storage.remove(removed.storage_key);
    return { body: { ok: true } };
  });

  // ---- Inquiries (buyer -> seller) --------------------------------------------------

  router.post('/api/listings/:id/inquiries', { limit: LIMITS.inquiry }, async ({ params, body }) => {
    const input = parse(v.inquirySchema, body);
    if (!v.isUuid(params.id)) throw notFound('Listing not found.');
    const inquiryId = newId();
    await db.transaction(async (tx) => {
      const listing = await store.getListingStatus(tx, params.id);
      if (!listing || listing.status !== 'active') throw notFound('This listing is no longer available.');
      await store.insertInquiry(tx, {
        id: inquiryId, listingId: params.id, buyerName: input.name, buyerEmail: input.email,
        buyerPhone: input.phone || null, message: input.message, now: iso()
      });
      // Scheduled in the same transaction: the lead and its notification commit together.
      await queue(tx, 'lead.created', { inquiryId });
      await audit(tx, null, 'inquiry.created', 'inquiry', inquiryId, { listingId: params.id });
      await emitWebhook(tx, 'inquiry.created', { inquiryId, listingId: params.id });
    });
    return { status: 201, body: { id: inquiryId, message: 'Your message was sent to the seller.' } };
  });

  router.get('/api/me/inquiries', { auth: 'required' }, async ({ user, query }) => {
    const input = parse(v.inquiriesQuerySchema, Object.fromEntries(query));
    const result = await store.listInquiries(db, {
      sellerId: user.id, listingId: input.carId, status: input.status, limit: input.limit, offset: input.offset
    });
    return { body: { ...result, limit: input.limit, offset: input.offset } };
  });

  router.get('/api/me/inquiries.csv', { auth: 'required' }, async ({ user, query }) => {
    const input = parse(v.inquiriesQuerySchema, Object.fromEntries(query));
    const { items } = await store.listInquiries(db, {
      sellerId: user.id, listingId: input.carId, status: input.status, limit: 5000, offset: 0
    });
    const rows = items.map((item) => ({
      created: item.createdAt, make: item.listing.make, model: item.listing.model, year: item.listing.year,
      buyerName: item.buyer.name, buyerEmail: item.buyer.email, buyerPhone: item.buyer.phone,
      message: item.message, status: item.status
    }));
    return {
      raw: toCsv(INQUIRY_CSV_COLUMNS, rows),
      headers: {
        'Content-Type': 'text/csv; charset=utf-8',
        'Content-Disposition': 'attachment; filename="rutamotor-inquiries.csv"',
        'Cache-Control': 'no-store'
      }
    };
  });

  router.patch('/api/inquiries/:id', { auth: 'required' }, async ({ user, params, body }) => {
    const input = parse(v.inquiryStatusSchema, body);
    if (!v.isUuid(params.id)) throw notFound('Inquiry not found.');
    const updated = await db.transaction(async (tx) => {
      const row = await store.updateInquiryStatus(tx, { id: params.id, sellerId: user.id, status: input.status, now: iso() });
      if (row) await audit(tx, user.id, 'inquiry.status_changed', 'inquiry', params.id, { status: input.status });
      return row;
    });
    if (!updated) throw notFound('Inquiry not found.');
    return { body: { ok: true, id: updated.id, status: updated.status } };
  });

  // ---- External integrations --------------------------------------------------------

  router.post('/api/listings/:id/publish/compradeautos', { auth: 'required' }, async ({ user, params }) => {
    requireVerifiedEmail(user);
    const listing = await ownedListing(params.id, user.id);
    if (!services.compradeautos.configured) throw new HttpError(503, 'CompraDeAutos is not configured on this server.');
    if (!['active', 'reserved'].includes(listing.status)) throw conflict('Only active or reserved listings can be published externally.');
    if (listing.engineCc === null) throw new HttpError(422, 'Add the engine displacement (cc) before publishing externally.');
    if (!(await store.countPhotos(db, listing.id))) throw new HttpError(422, 'Add at least one photo before publishing externally.');
    const queued = await db.transaction(async (tx) => {
      const existing = await store.getExternalListing(tx, listing.id, 'compradeautos');
      if (existing && (existing.status === 'pending' || existing.status === 'published')) return false;
      await store.markExternalPending(tx, { id: newId(), listingId: listing.id, provider: 'compradeautos', now: iso() });
      await queue(tx, 'external.compradeautos.publish', { listingId: listing.id });
      await audit(tx, user.id, 'external.requested', 'listing', listing.id, { provider: 'compradeautos' });
      return true;
    });
    if (!queued) throw conflict('This listing is already queued or published on CompraDeAutos.');
    return { status: 202, body: { ok: true, status: 'pending' } };
  });

  router.get('/api/listings/:id/external', { auth: 'required' }, async ({ user, params }) => {
    const listing = await ownedListing(params.id, user.id);
    const rows = await store.listExternalListings(db, listing.id);
    return {
      body: {
        items: rows.map((row) => ({
          provider: row.provider,
          externalId: row.external_id,
          status: row.status,
          lastError: row.last_error,
          updatedAt: row.updated_at instanceof Date ? row.updated_at.toISOString() : String(row.updated_at)
        }))
      }
    };
  });

  // ---- AI ---------------------------------------------------------------------------

  router.post('/api/ai/listing-description', { auth: 'required', limit: LIMITS.ai }, async ({ body }) => {
    const input = parse(v.descriptionSchema, body);
    const result = await services.ai.describeListing({
      make: input.make, model: input.model, year: input.year, mileage: input.mileage,
      transmission: input.transmission, fuel: input.fuel, body: input.body,
      features: input.features, notes: input.notes
    });
    return { body: { text: result.text, source: result.source } };
  });

  router.post('/api/ai/assistant', { limit: LIMITS.assistant }, async ({ body }) => {
    const input = parse(v.assistantSchema, body);
    if (!services.ai.enabled) throw new HttpError(503, 'The AI assistant is not configured on this server.');
    const { items } = await store.searchListings(db, { sort: 'newest', limit: 20, offset: 0 });
    const listings = items.map((item) => ({
      id: item.id, make: item.make, model: item.model, year: item.year, price: item.price,
      mileage: item.mileage, transmission: item.transmission, fuel: item.fuel, body: item.body,
      region: item.region, city: item.city
    }));
    const answer = await services.ai.answer(input.message, listings);
    return { body: { answer, listingCount: listings.length } };
  });

  // ---- Administration and moderation ------------------------------------------------

  router.get('/api/admin/jobs', { auth: 'required', admin: true }, async ({ query }) => {
    const input = parse(v.adminJobsQuerySchema, Object.fromEntries(query));
    return { body: { items: await store.listJobs(db, input) } };
  });

  router.post('/api/admin/jobs/:id/retry', { auth: 'required', admin: true }, async ({ user, params }) => {
    if (!v.isUuid(params.id)) throw notFound('Job not found.');
    const requeued = await db.transaction(async (tx) => {
      const ok = await store.requeueFailedJob(tx, { id: params.id, now: iso() });
      if (ok) await audit(tx, user.id, 'job.retried', 'job', params.id);
      return ok;
    });
    if (!requeued) throw conflict('Only failed jobs can be retried.');
    return { body: { ok: true } };
  });

  router.patch('/api/admin/listings/:id/status', { auth: 'required', admin: true }, async ({ user, params, body }) => {
    const input = parse(v.moderationSchema, body);
    if (!v.isUuid(params.id)) throw notFound('Listing not found.');
    return {
      body: await db.transaction(async (tx) => {
        const current = await store.getListingStatus(tx, params.id);
        if (!current) throw notFound('Listing not found.');
        if (current.status === input.status) return { changed: false, status: current.status };
        if (!canChangeListingStatus(current.status, input.status)) throw conflict(`A ${current.status} listing cannot change to ${input.status}.`);
        await store.setListingStatus(tx, { id: params.id, status: input.status, now: iso() });
        await audit(tx, user.id, 'listing.moderated', 'listing', params.id, { from: current.status, to: input.status, reason: input.reason });
        await emitWebhook(tx, 'listing.status_changed', { listingId: params.id, status: input.status });
        return { changed: true, status: input.status };
      })
    };
  });

  // ---- Request pipeline -------------------------------------------------------------

  async function handleApi(req, url) {
    await enforceRate(req, { name: 'api', max: 300, windowMs: 60_000 });
    const { route, params, pathMatched } = router.match(req.method === 'HEAD' ? 'GET' : req.method, url.pathname);
    if (!route) throw pathMatched ? new HttpError(405, 'Method not allowed.') : notFound('Route not found.');
    const auth = await authenticate(req);
    if (route.auth === 'required' && !auth.user) throw new HttpError(401, 'Please sign in to continue.');
    if (route.admin && auth.user.role !== 'admin') throw new HttpError(403, 'Administrator access is required.');
    const unsafe = UNSAFE_METHODS.has(req.method);
    if (unsafe && auth.viaCookie) assertSameOriginWrite(req);
    if (route.limit) await enforceRate(req, route.limit);
    const body = unsafe ? await readJson(req, route.bodyLimit || 16 * 1024) : {};
    return route.handler({ req, url, params, body, user: auth.user, query: url.searchParams });
  }

  async function handleMedia(pathname) {
    const id = pathname.slice('/media/'.length);
    if (!v.isUuid(id)) throw notFound('Photo not found.');
    const photo = await store.getPhotoWithListing(db, id);
    if (!photo || photo.listing_status === 'archived') throw notFound('Photo not found.');
    const bytes = await services.storage.read(photo.storage_key);
    return {
      raw: bytes,
      headers: {
        'Content-Type': photo.content_type,
        'Cache-Control': 'public, max-age=86400',
        'X-Content-Type-Options': 'nosniff'
      }
    };
  }

  async function serveStatic(method, pathname) {
    if (method !== 'GET' && method !== 'HEAD') throw new HttpError(405, 'Method not allowed.');
    const relative = pathname === '/' ? 'index.html' : pathname.slice(1);
    if (relative !== 'index.html' && !relative.startsWith('assets/')) throw notFound('Not found.');
    const filePath = path.resolve(PUBLIC_DIR, relative);
    if (!filePath.startsWith(PUBLIC_DIR + path.sep)) throw notFound('Not found.');
    let bytes;
    try {
      bytes = await fs.readFile(filePath);
    } catch {
      throw notFound('Not found.');
    }
    return {
      raw: bytes,
      headers: {
        'Content-Type': MIME_TYPES[path.extname(filePath)] || 'application/octet-stream',
        'Cache-Control': relative === 'index.html' ? 'no-cache' : 'public, max-age=300'
      }
    };
  }

  function respond(res, result) {
    const status = result.status || 200;
    if (result.raw !== undefined) return sendRaw(res, status, result.raw, result.headers || {});
    if (status === 204) {
      res.writeHead(204, result.headers || {});
      return res.end();
    }
    return sendJson(res, status, result.body, result.headers || {});
  }

  function respondError(res, error) {
    if (res.headersSent) return res.end();
    if (error instanceof HttpError) {
      const body = { error: error.message };
      if (error.details) body.details = error.details;
      return sendJson(res, error.status, body, error.headers || {});
    }
    logger.error('request.failed', { reason: error.message });
    return sendJson(res, 500, { error: 'Something went wrong. Please try again.' });
  }

  return async function handle(req, res) {
    const started = process.hrtime.bigint();
    // Clients may send their own correlation ID (e.g. from a load balancer). Anything unusual is replaced.
    const incoming = String(req.headers['x-request-id'] || '');
    const requestId = /^[A-Za-z0-9._-]{1,64}$/.test(incoming) ? incoming : crypto.randomUUID();
    res.setHeader('X-Request-Id', requestId);
    res.once('finish', () => {
      // Path only: the query string is never logged, and one-time tokens never appear in paths.
      logger.info('request.completed', {
        requestId, method: req.method, path: new URL(req.url || '/', 'http://localhost').pathname,
        status: res.statusCode, durationMs: Number(process.hrtime.bigint() - started) / 1e6
      });
    });
    securityHeaders(res, config);
    res.setHeader('Content-Security-Policy', CONTENT_SECURITY_POLICY);
    for (const [name, value] of Object.entries(corsHeaders(req))) res.setHeader(name, value);
    try {
      const url = new URL(req.url || '/', 'http://localhost');
      if (req.method === 'OPTIONS') {
        res.writeHead(204, corsHeaders(req));
        return res.end();
      }
      if (url.pathname.startsWith('/api/')) return respond(res, await handleApi(req, url));
      if (url.pathname.startsWith('/media/')) return respond(res, await handleMedia(url.pathname));
      return respond(res, await serveStatic(req.method, url.pathname));
    } catch (error) {
      return respondError(res, error);
    }
  };
}
