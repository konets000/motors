import { z } from 'zod';

export const TRANSMISSIONS = ['automatic', 'manual'];
export const FUELS = ['petrol', 'diesel', 'hybrid', 'electric', 'lpg'];
export const BODIES = ['suv', 'sedan', 'hatchback', 'pickup', 'coupe', 'van'];
export const SELLER_TYPES = ['private', 'dealer'];
export const LISTING_STATUSES = ['active', 'reserved', 'sold', 'archived'];
export const INQUIRY_STATUSES = ['new', 'contacted', 'qualified', 'closed', 'spam'];
export const JOB_STATUSES = ['queued', 'running', 'done', 'failed'];
export const SORTS = ['newest', 'priceAsc', 'priceDesc', 'yearDesc', 'mileageAsc'];
export const MAX_PRICE = 500_000_000;
const maxYear = () => new Date().getFullYear() + 1;

const CONTROL_CHARS = /[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g;
const cleanText = (value) => value.replace(CONTROL_CHARS, '').trim();
/** Trimmed text with control characters removed and a length window. */
const plain = (min, max) => z.string().transform(cleanText).pipe(z.string().min(min).max(max));
const email = z.string().transform((value) => value.trim().toLowerCase()).pipe(z.string().email().max(254));
const emptyToUndefined = (value) => (value === '' || value === null ? undefined : value);
const optionalText = (max) => z.preprocess(emptyToUndefined, plain(0, max).optional());
const optionalInt = (min, max) => z.preprocess(emptyToUndefined, z.coerce.number().int().min(min).max(max).optional());
const optionalEnum = (values) => z.preprocess(emptyToUndefined, z.enum(values).optional());
const optionalUuid = z.preprocess(emptyToUndefined, z.string().uuid().optional());

const newPassword = z.string().min(10, 'Password must be at least 10 characters.').max(128);
const accountToken = z.string().trim().min(20).max(200);

export const registerSchema = z.object({
  name: plain(1, 80),
  email,
  password: newPassword,
  phone: optionalText(30),
  whatsappOptIn: z.boolean().optional().default(false)
}).strict();

export const loginSchema = z.object({
  email,
  password: z.string().min(1).max(128)
}).strict();

export const emailOnlySchema = z.object({ email }).strict();
export const tokenSchema = z.object({ token: accountToken }).strict();
export const resetPasswordSchema = z.object({ token: accountToken, password: newPassword }).strict();

export const listingSchema = z.object({
  make: plain(1, 50),
  model: plain(1, 70),
  trim: plain(0, 100).default(''),
  year: z.coerce.number().int().min(1980).max(maxYear()),
  price: z.coerce.number().int().min(100_000).max(MAX_PRICE),
  mileage: z.coerce.number().int().min(0).max(2_000_000),
  transmission: z.enum(TRANSMISSIONS),
  fuel: z.enum(FUELS),
  body: z.enum(BODIES),
  // null is meaningful here (clears the value), so only the empty string is treated as absent.
  engineCc: z.preprocess((value) => (value === '' ? undefined : value), z.coerce.number().int().min(50).max(10_000).nullable().optional()),
  region: plain(1, 70),
  city: plain(1, 70),
  description: plain(10, 1200),
  sellerType: z.enum(SELLER_TYPES).default('private')
}).strict();

export const listingUpdateSchema = listingSchema.partial().strict();

export const statusChangeSchema = z.object({
  status: z.enum(LISTING_STATUSES)
}).strict();

export const moderationSchema = z.object({
  status: z.enum(['active', 'archived']),
  reason: plain(3, 200)
}).strict();

export const listingsQuerySchema = z.object({
  q: optionalText(80),
  make: optionalText(50),
  body: optionalEnum(BODIES),
  fuel: optionalEnum(FUELS),
  transmission: optionalEnum(TRANSMISSIONS),
  region: optionalText(70),
  minPrice: optionalInt(0, MAX_PRICE),
  maxPrice: optionalInt(0, MAX_PRICE),
  minYear: optionalInt(1980, 2100),
  maxYear: optionalInt(1980, 2100),
  maxMileage: optionalInt(0, 2_000_000),
  sort: z.preprocess(emptyToUndefined, z.enum(SORTS).default('newest')),
  limit: z.preprocess(emptyToUndefined, z.coerce.number().int().min(1).max(100).default(24)),
  offset: z.preprocess(emptyToUndefined, z.coerce.number().int().min(0).max(100_000).default(0))
});

export const inquirySchema = z.object({
  name: plain(1, 80),
  email,
  phone: optionalText(30),
  message: plain(5, 1200),
  consent: z.literal(true, { errorMap: () => ({ message: 'Consent is required so the seller can reply.' }) })
}).strict();

export const inquiryStatusSchema = z.object({
  status: z.enum(INQUIRY_STATUSES)
}).strict();

export const inquiriesQuerySchema = z.object({
  carId: optionalUuid,
  status: optionalEnum(INQUIRY_STATUSES),
  limit: z.preprocess(emptyToUndefined, z.coerce.number().int().min(1).max(100).default(25)),
  offset: z.preprocess(emptyToUndefined, z.coerce.number().int().min(0).max(100_000).default(0))
});

export const photoUploadSchema = z.object({
  filename: plain(1, 180),
  // The byte limit is enforced in the route against MAX_PHOTO_BYTES; this bound only guards memory.
  dataBase64: z.string().min(8).max(20_000_000)
}).strict();

export const descriptionSchema = z.object({
  make: plain(1, 50),
  model: plain(1, 70),
  year: z.coerce.number().int().min(1980).max(maxYear()),
  mileage: z.coerce.number().int().min(0).max(2_000_000),
  transmission: z.enum(TRANSMISSIONS),
  fuel: z.enum(FUELS),
  body: z.enum(BODIES),
  features: z.array(plain(1, 80)).max(20).default([]),
  notes: plain(0, 600).default('')
}).strict();

export const assistantSchema = z.object({
  message: plain(3, 500)
}).strict();

export const adminJobsQuerySchema = z.object({
  status: optionalEnum(JOB_STATUSES),
  limit: z.preprocess(emptyToUndefined, z.coerce.number().int().min(1).max(200).default(50))
});

export const isUuid = (value) => z.string().uuid().safeParse(value).success;
