// Background automation: a persistent job queue in the same database, processed by the worker.
// Jobs are enqueued inside the same transaction as the business change (transactional outbox),
// so a lead is never saved without its notification being scheduled.
import crypto from 'node:crypto';
import * as store from './store.js';
import { escapeHtml, listingLabel } from './domain.js';
import { permanentError } from './integrations/compradeautos.js';
import { openText } from './security.js';
import { accountLink, renderAccountEmail } from './accounts.js';

const DAY_MS = 86_400_000;

/** Seconds to wait before the next attempt: 30, 60, 120 … capped at one hour. */
export function retryDelaySeconds(attempts) {
  return Math.min(3600, 15 * (2 ** Math.min(Math.max(Number(attempts) || 0, 0), 8)));
}

/** Schedules a job. `executor` is either the database or an open transaction. Returns false when deduplicated. */
export async function enqueue(executor, type, payload, { dedupeKey, delaySeconds = 0, now = new Date(), maxAttempts = 6 } = {}) {
  const runAt = new Date(now.getTime() + delaySeconds * 1000).toISOString();
  return store.enqueueJob(executor, {
    id: crypto.randomUUID(),
    type,
    payload,
    runAt,
    maxAttempts,
    dedupeKey,
    now: now.toISOString()
  });
}

/** Builds the handler table. Each handler must be idempotent: a retry must not repeat completed side effects. */
export function createHandlers({ db, services, config, now = () => new Date() }) {
  const newId = () => crypto.randomUUID();
  const audit = (actorId, event, entityType, entityId, metadata = {}) => store.recordAudit(db, {
    id: newId(), actorId, event, entityType, entityId, metadata, now: now().toISOString()
  });

  return {
    'lead.created': async ({ inquiryId }) => {
      const ctx = await store.getInquiryContext(db, inquiryId);
      if (!ctx) throw permanentError('The inquiry no longer exists.');
      const label = listingLabel({ year: ctx.year, make: ctx.make, model: ctx.model });

      if (!(await store.hasAudit(db, { entityType: 'inquiry', entityId: inquiryId, event: 'notify.email' }))) {
        const result = await services.email.send({
          to: ctx.seller_email,
          subject: `New inquiry: ${label}`,
          text: `Hi ${ctx.seller_name},\n\n${ctx.buyer_name} (${ctx.buyer_email}${ctx.buyer_phone ? `, ${ctx.buyer_phone}` : ''}) asked about your ${label}.\n\nMessage:\n${ctx.message}\n\nReply directly to the buyer to continue the conversation.`,
          html: `<p>Hi ${escapeHtml(ctx.seller_name)},</p><p><strong>${escapeHtml(ctx.buyer_name)}</strong> (${escapeHtml(ctx.buyer_email)}) asked about your <strong>${escapeHtml(label)}</strong>.</p><blockquote>${escapeHtml(ctx.message)}</blockquote><p>Reply directly to the buyer to continue.</p>`
        });
        if (result.sent) await audit(ctx.seller_id, 'notify.email', 'inquiry', inquiryId, { reason: result.reason });
      }

      if (Boolean(ctx.whatsapp_opt_in) && ctx.seller_phone && !(await store.hasAudit(db, { entityType: 'inquiry', entityId: inquiryId, event: 'notify.whatsapp' }))) {
        const result = await services.whatsapp.sendTemplate({
          to: ctx.seller_phone,
          template: config.whatsapp.leadTemplate,
          parameters: [ctx.buyer_name, label]
        });
        if (result.sent) await audit(ctx.seller_id, 'notify.whatsapp', 'inquiry', inquiryId, { reason: result.reason });
      }
    },

    'webhook.deliver': async ({ event, data }, { job }) => {
      if (!services.webhooks.configured) return;
      await services.webhooks.deliver({ deliveryId: job.id, event, data });
    },

    // The raw token exists only inside the sealed payload; it is opened here and nowhere else.
    'account.token_email': async ({ userId, purpose, tokenId, sealed }) => {
      const account = await store.getAccountToken(db, tokenId);
      // Used, superseded or expired links are not sent: only the newest request matters.
      if (!account || account.used_at || new Date(account.expires_at).getTime() <= now().getTime()) return;
      if (await store.hasAudit(db, { entityType: 'account_token', entityId: tokenId, event: 'notify.email' })) return;
      const user = await store.findUserRowById(db, userId);
      if (!user) throw permanentError('The account no longer exists.');
      const token = openText(sealed, config.authSecret);
      if (!token) throw permanentError('The stored link could not be read. Request a new one.');
      const message = renderAccountEmail(purpose, { name: user.name, link: accountLink(config.appUrl, purpose, token) });
      const result = await services.email.send({ to: user.email, ...message });
      if (result.sent) await audit(null, 'notify.email', 'account_token', tokenId, { purpose });
    },

    'account.password_changed': async ({ userId }) => {
      const user = await store.findUserRowById(db, userId);
      if (!user) return;
      await services.email.send({ to: user.email, ...renderAccountEmail('password_changed', { name: user.name }) });
    },

    'maintenance.prune': async () => {
      const current = now();
      const day = 86_400_000;
      return store.pruneOperationalRecords(db, {
        doneJobsBefore: new Date(current.getTime() - 30 * day).toISOString(),
        linksExpiredBefore: new Date(current.getTime() - 7 * day).toISOString()
      });
    },

    'listing.stale_check': async () => {
      const current = now();
      const rows = await store.findStaleListings(db, {
        publishedBefore: new Date(current.getTime() - config.worker.staleListingDays * DAY_MS).toISOString(),
        remindedBefore: new Date(current.getTime() - 30 * DAY_MS).toISOString(),
        limit: 200
      });
      const month = current.toISOString().slice(0, 7);
      for (const row of rows) {
        await enqueue(db, 'listing.reminder', { listingId: row.id }, { dedupeKey: `reminder:${row.id}:${month}`, now: current, maxAttempts: config.worker.maxAttempts });
      }
      return rows.length;
    },

    'listing.reminder': async ({ listingId }) => {
      const listing = await store.getListingContact(db, listingId);
      if (!listing) throw permanentError('The listing no longer exists.');
      if (listing.status !== 'active') return;
      const label = listingLabel({ year: listing.year, make: listing.make, model: listing.model });
      await services.email.send({
        to: listing.seller_email,
        subject: `Is your ${label} still for sale?`,
        text: `Hi ${listing.seller_name},\n\nYour ${label} has been listed for a while. Renew it or update the price and photos so buyers keep finding it.`,
        html: `<p>Hi ${escapeHtml(listing.seller_name)},</p><p>Your <strong>${escapeHtml(label)}</strong> has been listed for a while. Renew it or update the price and photos so buyers keep finding it.</p>`
      });
      await store.markListingReminded(db, { id: listingId, now: now().toISOString() });
    },

    'external.compradeautos.publish': async ({ listingId }, { job }) => {
      const provider = 'compradeautos';
      const existing = await store.getExternalListing(db, listingId, provider);
      if (existing?.status === 'published') return;
      const lastAttempt = job.attempts >= job.maxAttempts;
      try {
        const listing = await store.getListingContact(db, listingId);
        if (!listing) throw permanentError('The listing no longer exists.');
        if (!services.compradeautos.configured) throw permanentError('CompraDeAutos is not configured on this server.');
        const full = await store.getListing(db, listingId);
        const rows = await store.listPhotos(db, listingId);
        if (!rows.length) throw permanentError('Add at least one photo before publishing externally.');
        const photos = [];
        for (const row of rows) {
          photos.push({
            fileName: row.storage_key,
            mimeType: row.content_type,
            bytes: await services.storage.read(row.storage_key),
            isMain: Number(row.position) === 0
          });
        }
        const result = await services.compradeautos.publish({
          listing: full,
          photos,
          contact: { showName: true, showEmail: true, showPhone: false, showWhatsApp: false }
        });
        await store.markExternalResult(db, { listingId, provider, status: 'published', externalId: result.externalId, error: null, now: now().toISOString() });
        await audit(null, 'external.published', 'listing', listingId, { provider });
      } catch (error) {
        if (error.permanent || lastAttempt) {
          await store.markExternalResult(db, { listingId, provider, status: 'failed', externalId: null, error: error.message, now: now().toISOString() });
        }
        throw error;
      }
    }
  };
}

/** Processes one ready job. Returns null when the queue is empty. */
export async function runNextJob({ db, handlers, config, now = () => new Date() }) {
  const current = now();
  const nowIso = current.toISOString();
  const staleBefore = new Date(current.getTime() - config.worker.staleLockSeconds * 1000).toISOString();
  const job = await store.claimJob(db, { now: nowIso, staleBefore });
  if (!job) return null;
  try {
    const handler = handlers[job.type];
    if (!handler) throw permanentError(`Unknown job type: ${job.type}`);
    await handler(job.payload, { job, now: current });
    await store.completeJob(db, { id: job.id, now: nowIso });
    return { job, ok: true };
  } catch (error) {
    const status = error.permanent || job.attempts >= job.maxAttempts ? 'failed' : 'queued';
    const runAt = new Date(current.getTime() + retryDelaySeconds(job.attempts) * 1000).toISOString();
    await store.failJob(db, { id: job.id, error: String(error.message || 'Unknown error').slice(0, 500), status, runAt, now: nowIso });
    return { job, ok: false, status, error };
  }
}

/** Runs jobs until the queue is empty. Used by tests and by one-off maintenance. */
export async function drainQueue(context, limit = 1000) {
  const results = [];
  for (let i = 0; i < limit; i += 1) {
    const result = await runNextJob(context);
    if (!result) break;
    results.push(result);
  }
  return results;
}

function sleep(ms, signal) {
  return new Promise((resolve) => {
    const timer = setTimeout(resolve, ms);
    signal?.addEventListener('abort', () => {
      clearTimeout(timer);
      resolve();
    }, { once: true });
  });
}

/** Long-running worker loop with a periodic stale-listing scan. Stops when `signal` aborts. */
export async function runWorker({ db, handlers, config, logger, signal, now = () => new Date() }) {
  let nextStaleCheck = 0;
  let nextPrune = 0;
  logger.info('worker.started', { pollMs: config.worker.pollMs });
  while (!signal.aborted) {
    try {
      const current = now();
      if (current.getTime() >= nextStaleCheck) {
        const bucket = current.toISOString().slice(0, 13);
        await enqueue(db, 'listing.stale_check', {}, { dedupeKey: `stale-check:${bucket}`, now: current, maxAttempts: config.worker.maxAttempts });
        nextStaleCheck = current.getTime() + config.worker.staleCheckMinutes * 60_000;
      }
      if (current.getTime() >= nextPrune) {
        // Once per day: the dedupe key stops the 6-hourly check from queuing duplicates.
        await enqueue(db, 'maintenance.prune', {}, { dedupeKey: `prune:${current.toISOString().slice(0, 10)}`, now: current, maxAttempts: config.worker.maxAttempts });
        nextPrune = current.getTime() + 6 * 3_600_000;
      }
      const result = await runNextJob({ db, handlers, config, now });
      if (result) {
        if (result.ok) logger.info('job.done', { jobId: result.job.id, type: result.job.type });
        else logger.warn('job.failed', { jobId: result.job.id, type: result.job.type, attempt: result.job.attempts, status: result.status, reason: result.error.message });
        continue;
      }
    } catch (error) {
      logger.error('worker.error', { reason: error.message });
    }
    await sleep(config.worker.pollMs, signal);
  }
  logger.info('worker.stopped', {});
}
