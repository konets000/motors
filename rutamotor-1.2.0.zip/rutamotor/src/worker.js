// Background worker entry point: `npm run worker`. Run one or more instances next to the API.
import { bootstrap } from './bootstrap.js';
import { createHandlers, runWorker } from './jobs.js';

const ctx = await bootstrap({ migrateSchema: false });
const controller = new AbortController();
for (const signal of ['SIGINT', 'SIGTERM']) {
  process.on(signal, () => controller.abort());
}

await runWorker({ ...ctx, handlers: createHandlers(ctx), signal: controller.signal });
await ctx.db.close();
process.exit(0);
