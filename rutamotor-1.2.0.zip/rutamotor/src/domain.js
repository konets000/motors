// Pure business rules: no database, no network. Kept separate so they can be unit tested directly.

export const LISTING_TRANSITIONS = Object.freeze({
  active: ['reserved', 'sold', 'archived'],
  reserved: ['active', 'sold', 'archived'],
  archived: ['active'],
  sold: []
});

export function canChangeListingStatus(from, to) {
  return Object.hasOwn(LISTING_TRANSITIONS, from) && LISTING_TRANSITIONS[from].includes(to);
}

export const INQUIRY_CSV_COLUMNS = Object.freeze([
  { key: 'created', label: 'Received' },
  { key: 'make', label: 'Make' },
  { key: 'model', label: 'Model' },
  { key: 'year', label: 'Year' },
  { key: 'buyerName', label: 'Buyer' },
  { key: 'buyerEmail', label: 'Buyer email' },
  { key: 'buyerPhone', label: 'Buyer phone' },
  { key: 'message', label: 'Message' },
  { key: 'status', label: 'Status' }
]);

// Cells starting with these characters are interpreted as formulas by spreadsheet apps.
const FORMULA_START = /^[=+\-@\t\r]/;

/** Escapes one CSV cell (RFC 4180) and neutralises spreadsheet formula injection. */
export function csvCell(value) {
  if (value === null || value === undefined) return '';
  if (typeof value === 'number' || typeof value === 'bigint') return String(value);
  let text = value instanceof Date ? value.toISOString() : String(value);
  if (FORMULA_START.test(text)) text = `'${text}`;
  if (/[",\r\n]/.test(text)) return `"${text.replace(/"/g, '""')}"`;
  return text;
}

/** Builds a CSV document with a UTF-8 BOM so Excel renders accents correctly. */
export function toCsv(columns, rows) {
  const lines = [columns.map((column) => csvCell(column.label)).join(',')];
  for (const row of rows) {
    lines.push(columns.map((column) => csvCell(row[column.key])).join(','));
  }
  return `\uFEFF${lines.join('\r\n')}\r\n`;
}

const HTML_ESCAPES = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
export const escapeHtml = (value) => String(value ?? '').replace(/[&<>"']/g, (char) => HTML_ESCAPES[char]);

export function maskEmail(email) {
  const [user, domain] = String(email || '').split('@');
  if (!user || !domain) return '***';
  return `${user.slice(0, 1)}***@${domain}`;
}

/** Returns a comparable label for a listing, e.g. "2021 Toyota Corolla". */
export const listingLabel = (listing) => `${listing.year} ${listing.make} ${listing.model}`;

export function formatMoney(amount, currency) {
  return new Intl.NumberFormat('en-US', { style: 'currency', currency, maximumFractionDigits: 0 }).format(amount);
}
