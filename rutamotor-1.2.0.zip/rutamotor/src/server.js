import http from 'node:http';
import { bootstrap } from './bootstrap.js';
import { createApp } from './app.js';
import { createHandlers, runWorker } from './jobs.js';

const ctx = await bootstrap();
const { config, logger, db } = ctx;
const server = http.createServer(createApp(ctx));
server.requestTimeout = 30_000;
server.headersTimeout = 15_000;

server.listen(config.port, config.host, () => {
  logger.info('server.listening', { host: config.host, port: config.port, env: config.env, database: db.dialect });
});

// Optional single-process deployment: run the worker alongside the API.
const worker = new AbortController();
if (config.workerInProcess) {
  runWorker({ db, handlers: createHandlers(ctx), config, logger, signal: worker.signal, now: ctx.now }).catch((error) => {
    logger.error('worker.fatal', { reason: error.message });
  });
}

let stopping = false;
function shutdown(signal) {
  if (stopping) return;
  stopping = true;
  logger.info('server.stopping', { signal });
  worker.abort();
  server.close(async () => {
    await db.close();
    process.exit(0);
  });
  setTimeout(() => process.exit(1), 10_000).unref();
}
process.on('SIGINT', () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));
