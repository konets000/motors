import crypto from 'node:crypto';
import { promisify } from 'node:util';

const scryptAsync = promisify(crypto.scrypt);
const SCRYPT_PARAMS = { N: 16384, r: 8, p: 1 };
const KEY_LENGTH = 64;

/** Hashes a password with scrypt. Format: scrypt$N$r$p$salt$hash (base64). */
export async function hashPassword(password) {
  const salt = crypto.randomBytes(16);
  const key = await scryptAsync(password, salt, KEY_LENGTH, SCRYPT_PARAMS);
  return ['scrypt', SCRYPT_PARAMS.N, SCRYPT_PARAMS.r, SCRYPT_PARAMS.p, salt.toString('base64'), key.toString('base64')].join('$');
}

export async function verifyPassword(password, stored) {
  const [algorithm, N, r, p, saltB64, keyB64] = String(stored || '').split('$');
  if (algorithm !== 'scrypt' || !saltB64 || !keyB64) return false;
  const expected = Buffer.from(keyB64, 'base64');
  const actual = await scryptAsync(String(password), Buffer.from(saltB64, 'base64'), expected.length, {
    N: Number(N), r: Number(r), p: Number(p)
  });
  return expected.length === actual.length && crypto.timingSafeEqual(expected, actual);
}

const b64url = (input) => Buffer.from(input).toString('base64url');

/** Issues an HS256 token with an expiry. */
export function signToken(claims, secret, ttlSeconds, nowSeconds = Math.floor(Date.now() / 1000)) {
  const header = b64url(JSON.stringify({ alg: 'HS256', typ: 'JWT' }));
  const payload = b64url(JSON.stringify({ ...claims, iat: nowSeconds, exp: nowSeconds + ttlSeconds }));
  const signature = crypto.createHmac('sha256', secret).update(`${header}.${payload}`).digest('base64url');
  return `${header}.${payload}.${signature}`;
}

/** Returns the claims for a valid, unexpired token, or null. */
export function verifyToken(token, secret, nowSeconds = Math.floor(Date.now() / 1000)) {
  if (typeof token !== 'string' || token.length > 4096) return null;
  const parts = token.split('.');
  if (parts.length !== 3) return null;
  const [header, payload, signature] = parts;
  const expected = crypto.createHmac('sha256', secret).update(`${header}.${payload}`).digest();
  const given = Buffer.from(signature, 'base64url');
  if (given.length !== expected.length || !crypto.timingSafeEqual(given, expected)) return null;
  let claims;
  try {
    claims = JSON.parse(Buffer.from(payload, 'base64url').toString('utf8'));
  } catch {
    return null;
  }
  if (!claims || typeof claims.exp !== 'number' || claims.exp <= nowSeconds) return null;
  return claims;
}

/** A new random token for email links: 256 bits, URL-safe. */
export const newToken = () => crypto.randomBytes(32).toString('base64url');

/**
 * SHA-256 of a token. Tokens are high-entropy and never typed by people, so a fast hash is enough,
 * and storing only the hash means a database leak does not expose usable links.
 */
export const hashToken = (token) => crypto.createHash('sha256').update(String(token)).digest('hex');

const SEAL_INFO = 'rutamotor:sealed-payload:v1';
const sealKey = (secret) => Buffer.from(crypto.hkdfSync('sha256', String(secret), Buffer.alloc(0), SEAL_INFO, 32));

/**
 * Encrypts a short secret so it can sit in the job queue without being readable from a database dump.
 * AES-256-GCM; the key is derived from AUTH_SECRET.
 */
export function sealText(plaintext, secret) {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', sealKey(secret), iv);
  const data = Buffer.concat([cipher.update(String(plaintext), 'utf8'), cipher.final()]);
  return [iv, cipher.getAuthTag(), data].map((part) => part.toString('base64url')).join('.');
}

/** Returns the plaintext from sealText, or null if the value was altered or the secret differs. */
export function openText(sealed, secret) {
  const parts = String(sealed || '').split('.');
  if (parts.length !== 3) return null;
  try {
    const [iv, tag, data] = parts.map((part) => Buffer.from(part, 'base64url'));
    const decipher = crypto.createDecipheriv('aes-256-gcm', sealKey(secret), iv);
    decipher.setAuthTag(tag);
    return Buffer.concat([decipher.update(data), decipher.final()]).toString('utf8');
  } catch {
    return null;
  }
}
