-- Email verification and password reset. Tokens are stored as SHA-256 hashes and are single-use.
ALTER TABLE users ADD COLUMN email_verified_at TIMESTAMPTZ;
-- Bumped on password change; sessions carry the version they were issued with.
ALTER TABLE users ADD COLUMN session_version INTEGER NOT NULL DEFAULT 0;

CREATE TABLE account_tokens (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users (id) ON DELETE CASCADE,
  purpose TEXT NOT NULL CHECK (purpose IN ('verify_email', 'reset_password')),
  token_hash TEXT NOT NULL UNIQUE,
  expires_at TIMESTAMPTZ NOT NULL,
  used_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL
);
CREATE INDEX account_tokens_user_idx ON account_tokens (user_id, purpose, used_at);
