-- RutaMotor schema (SQLite). Timestamps are ISO-8601 UTC text; ids are UUID text.
CREATE TABLE users (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'user' CHECK (role IN ('user', 'admin')),
  phone TEXT,
  whatsapp_opt_in INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL
);

CREATE TABLE listings (
  id TEXT PRIMARY KEY,
  seller_id TEXT NOT NULL REFERENCES users (id) ON DELETE RESTRICT,
  make TEXT NOT NULL,
  model TEXT NOT NULL,
  trim TEXT NOT NULL DEFAULT '',
  year INTEGER NOT NULL CHECK (year BETWEEN 1980 AND 2100),
  price INTEGER NOT NULL CHECK (price >= 0),
  mileage_km INTEGER NOT NULL CHECK (mileage_km BETWEEN 0 AND 2000000),
  transmission TEXT NOT NULL CHECK (transmission IN ('automatic', 'manual')),
  fuel TEXT NOT NULL CHECK (fuel IN ('petrol', 'diesel', 'hybrid', 'electric', 'lpg')),
  body TEXT NOT NULL CHECK (body IN ('suv', 'sedan', 'hatchback', 'pickup', 'coupe', 'van')),
  engine_cc INTEGER,
  region TEXT NOT NULL,
  city TEXT NOT NULL,
  description TEXT NOT NULL,
  seller_type TEXT NOT NULL DEFAULT 'private' CHECK (seller_type IN ('private', 'dealer')),
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'reserved', 'sold', 'archived')),
  published_at TEXT NOT NULL,
  last_reminded_at TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE INDEX listings_status_published_idx ON listings (status, published_at);
CREATE INDEX listings_seller_idx ON listings (seller_id, updated_at);
CREATE INDEX listings_make_model_idx ON listings (make, model);
CREATE INDEX listings_region_idx ON listings (region);

CREATE TABLE photos (
  id TEXT PRIMARY KEY,
  listing_id TEXT NOT NULL REFERENCES listings (id) ON DELETE CASCADE,
  storage_key TEXT NOT NULL,
  content_type TEXT NOT NULL,
  size_bytes INTEGER NOT NULL,
  position INTEGER NOT NULL,
  created_at TEXT NOT NULL
);
CREATE INDEX photos_listing_idx ON photos (listing_id, position);

CREATE TABLE inquiries (
  id TEXT PRIMARY KEY,
  listing_id TEXT NOT NULL REFERENCES listings (id) ON DELETE RESTRICT,
  buyer_name TEXT NOT NULL,
  buyer_email TEXT NOT NULL,
  buyer_phone TEXT,
  message TEXT NOT NULL,
  consent_at TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'new' CHECK (status IN ('new', 'contacted', 'qualified', 'closed', 'spam')),
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE INDEX inquiries_listing_idx ON inquiries (listing_id, created_at);

CREATE TABLE jobs (
  id TEXT PRIMARY KEY,
  type TEXT NOT NULL,
  payload TEXT NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('queued', 'running', 'done', 'failed')),
  attempts INTEGER NOT NULL DEFAULT 0,
  max_attempts INTEGER NOT NULL DEFAULT 6,
  run_at TEXT NOT NULL,
  locked_at TEXT,
  last_error TEXT,
  dedupe_key TEXT UNIQUE,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE INDEX jobs_ready_idx ON jobs (status, run_at);

CREATE TABLE external_listings (
  id TEXT PRIMARY KEY,
  listing_id TEXT NOT NULL REFERENCES listings (id) ON DELETE CASCADE,
  provider TEXT NOT NULL,
  external_id TEXT,
  status TEXT NOT NULL CHECK (status IN ('pending', 'published', 'failed')),
  last_error TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  UNIQUE (listing_id, provider)
);

CREATE TABLE audit_events (
  id TEXT PRIMARY KEY,
  actor_id TEXT,
  event TEXT NOT NULL,
  entity_type TEXT NOT NULL,
  entity_id TEXT NOT NULL,
  metadata TEXT NOT NULL DEFAULT '{}',
  created_at TEXT NOT NULL
);
CREATE INDEX audit_entity_idx ON audit_events (entity_type, entity_id, event);
