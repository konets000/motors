-- Shared fixed-window rate limits (RATE_LIMIT_STORE=database). One row per bucket.
CREATE TABLE rate_limits (
  bucket TEXT PRIMARY KEY,
  hits INTEGER NOT NULL,
  reset_at TEXT NOT NULL
);
CREATE INDEX rate_limits_reset_idx ON rate_limits (reset_at);
