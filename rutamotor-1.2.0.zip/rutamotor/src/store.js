// Data access. Every function takes a database scope (the adapter or a transaction) as its first argument.
// SQL here must run on both SQLite and PostgreSQL: no NOW(), no ILIKE, no BIGINT columns.

const iso = (value) => (value === null || value === undefined ? null : value instanceof Date ? value.toISOString() : String(value));

export const mapUser = (row) => ({
  id: row.id,
  name: row.name,
  email: row.email,
  role: row.role,
  phone: row.phone || '',
  whatsappOptIn: Boolean(row.whatsapp_opt_in),
  emailVerified: Boolean(row.email_verified_at),
  // Internal: compared against the session token, never returned to clients.
  sessionVersion: Number(row.session_version ?? 0)
});

export function mapListing(row) {
  return {
    id: row.id,
    sellerId: row.seller_id,
    sellerName: row.seller_name,
    sellerType: row.seller_type,
    make: row.make,
    model: row.model,
    trim: row.trim,
    year: Number(row.year),
    price: Number(row.price),
    mileage: Number(row.mileage_km),
    transmission: row.transmission,
    fuel: row.fuel,
    body: row.body,
    engineCc: row.engine_cc === null || row.engine_cc === undefined ? null : Number(row.engine_cc),
    region: row.region,
    city: row.city,
    description: row.description,
    status: row.status,
    coverPhotoId: row.cover_photo_id || null,
    photoCount: row.photo_count === undefined ? undefined : Number(row.photo_count),
    inquiryCount: row.inquiry_count === undefined ? undefined : Number(row.inquiry_count),
    publishedAt: iso(row.published_at),
    lastRemindedAt: iso(row.last_reminded_at),
    createdAt: iso(row.created_at),
    updatedAt: iso(row.updated_at)
  };
}

export const mapPhoto = (row) => ({
  id: row.id,
  listingId: row.listing_id,
  contentType: row.content_type,
  sizeBytes: Number(row.size_bytes),
  position: Number(row.position),
  url: `/media/${row.id}`
});

export function mapInquiry(row) {
  return {
    id: row.id,
    listingId: row.listing_id,
    status: row.status,
    message: row.message,
    createdAt: iso(row.created_at),
    buyer: { name: row.buyer_name, email: row.buyer_email, phone: row.buyer_phone || '' },
    listing: { make: row.make, model: row.model, year: Number(row.year) }
  };
}

// ---- Users -----------------------------------------------------------------------------

export async function insertUser(db, user) {
  await db.execute(
    `INSERT INTO users (id, name, email, password_hash, role, phone, whatsapp_opt_in, created_at, email_verified_at)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)`,
    [user.id, user.name, user.email, user.passwordHash, user.role, user.phone || null, Boolean(user.whatsappOptIn),
      user.createdAt, user.emailVerifiedAt || null]
  );
}

export async function findUserByEmail(db, email) {
  const rows = await db.query(
    'SELECT id, name, email, password_hash, role, phone, whatsapp_opt_in, email_verified_at, session_version FROM users WHERE email = $1',
    [email]
  );
  return rows[0] || null;
}

const USER_COLUMNS = 'id, name, email, role, phone, whatsapp_opt_in, email_verified_at, session_version';

export async function findUserById(db, id) {
  const rows = await db.query(`SELECT ${USER_COLUMNS} FROM users WHERE id = $1`, [id]);
  return rows[0] ? mapUser(rows[0]) : null;
}

export async function findUserRowById(db, id) {
  const rows = await db.query(`SELECT ${USER_COLUMNS} FROM users WHERE id = $1`, [id]);
  return rows[0] || null;
}

// ---- Listings --------------------------------------------------------------------------

const LISTING_SELECT = `
  SELECT l.*, u.name AS seller_name,
    (SELECT p.id FROM photos p WHERE p.listing_id = l.id ORDER BY p.position LIMIT 1) AS cover_photo_id,
    (SELECT CAST(COUNT(*) AS INTEGER) FROM photos p WHERE p.listing_id = l.id) AS photo_count,
    (SELECT CAST(COUNT(*) AS INTEGER) FROM inquiries i WHERE i.listing_id = l.id) AS inquiry_count
  FROM listings l
  JOIN users u ON u.id = l.seller_id`;

const SORT_SQL = {
  newest: 'l.published_at DESC, l.id',
  priceAsc: 'l.price ASC, l.id',
  priceDesc: 'l.price DESC, l.id',
  yearDesc: 'l.year DESC, l.id',
  mileageAsc: 'l.mileage_km ASC, l.id'
};

export async function insertListing(db, listing) {
  await db.execute(
    `INSERT INTO listings (id, seller_id, make, model, trim, year, price, mileage_km, transmission, fuel, body,
       engine_cc, region, city, description, seller_type, status, published_at, created_at, updated_at)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, 'active', $17, $17, $17)`,
    [listing.id, listing.sellerId, listing.make, listing.model, listing.trim, listing.year, listing.price,
      listing.mileage, listing.transmission, listing.fuel, listing.body, listing.engineCc, listing.region,
      listing.city, listing.description, listing.sellerType, listing.now]
  );
}

/** Updates whitelisted columns (names come from code, never from request input). */
export async function updateListingColumns(db, { id, sellerId, columns, now }) {
  const params = [];
  const sets = Object.entries(columns).map(([column, value]) => {
    params.push(value);
    return `${column} = $${params.length}`;
  });
  params.push(now);
  sets.push(`updated_at = $${params.length}`);
  params.push(id, sellerId);
  const rows = await db.query(
    `UPDATE listings SET ${sets.join(', ')} WHERE id = $${params.length - 1} AND seller_id = $${params.length} RETURNING id`,
    params
  );
  return rows.length > 0;
}

export async function setListingStatus(db, { id, status, now }) {
  await db.execute('UPDATE listings SET status = $1, updated_at = $2 WHERE id = $3', [status, now, id]);
}

export async function renewListing(db, { id, sellerId, now }) {
  const rows = await db.query(
    'UPDATE listings SET published_at = $1, last_reminded_at = NULL, updated_at = $1 WHERE id = $2 AND seller_id = $3 RETURNING id',
    [now, id, sellerId]
  );
  return rows.length > 0;
}

export async function getListing(db, id) {
  const rows = await db.query(`${LISTING_SELECT} WHERE l.id = $1`, [id]);
  return rows[0] ? mapListing(rows[0]) : null;
}

export async function getListingStatus(db, id) {
  const rows = await db.query(`SELECT status, seller_id FROM listings WHERE id = $1 ${db.rowLock}`, [id]);
  return rows[0] || null;
}

export async function searchListings(db, filters) {
  const where = ["l.status = 'active'"];
  const params = [];
  const add = (value) => {
    params.push(value);
    return `$${params.length}`;
  };
  if (filters.q) {
    const pattern = `%${filters.q.toLowerCase().replace(/[\\%_]/g, '\\$&')}%`;
    const ph = add(pattern);
    where.push(`(LOWER(l.make) LIKE ${ph} ESCAPE '\\' OR LOWER(l.model) LIKE ${ph} ESCAPE '\\' OR LOWER(l.trim) LIKE ${ph} ESCAPE '\\')`);
  }
  if (filters.make) where.push(`LOWER(l.make) = LOWER(${add(filters.make)})`);
  if (filters.body) where.push(`l.body = ${add(filters.body)}`);
  if (filters.fuel) where.push(`l.fuel = ${add(filters.fuel)}`);
  if (filters.transmission) where.push(`l.transmission = ${add(filters.transmission)}`);
  if (filters.region) where.push(`l.region = ${add(filters.region)}`);
  if (filters.minPrice !== undefined) where.push(`l.price >= ${add(filters.minPrice)}`);
  if (filters.maxPrice !== undefined) where.push(`l.price <= ${add(filters.maxPrice)}`);
  if (filters.minYear !== undefined) where.push(`l.year >= ${add(filters.minYear)}`);
  if (filters.maxYear !== undefined) where.push(`l.year <= ${add(filters.maxYear)}`);
  if (filters.maxMileage !== undefined) where.push(`l.mileage_km <= ${add(filters.maxMileage)}`);
  const clause = where.join(' AND ');
  const order = SORT_SQL[filters.sort] || SORT_SQL.newest;

  // The count query must not receive LIMIT/OFFSET values, so the page parameters are appended separately.
  const pageParams = [...params, filters.limit, filters.offset];
  const limitPh = `$${params.length + 1}`;
  const offsetPh = `$${params.length + 2}`;
  const [countRows, rows] = await Promise.all([
    db.query(`SELECT CAST(COUNT(*) AS INTEGER) AS total FROM listings l WHERE ${clause}`, params),
    db.query(`${LISTING_SELECT} WHERE ${clause} ORDER BY ${order} LIMIT ${limitPh} OFFSET ${offsetPh}`, pageParams)
  ]);
  return { items: rows.map(mapListing), total: Number(countRows[0].total) };
}

export async function listOwnerListings(db, sellerId) {
  const rows = await db.query(`${LISTING_SELECT} WHERE l.seller_id = $1 ORDER BY l.updated_at DESC LIMIT 200`, [sellerId]);
  return rows.map(mapListing);
}

export async function findStaleListings(db, { publishedBefore, remindedBefore, limit }) {
  return db.query(
    `SELECT l.id, l.seller_id FROM listings l
     WHERE l.status = 'active' AND l.published_at < $1 AND (l.last_reminded_at IS NULL OR l.last_reminded_at < $2)
     ORDER BY l.published_at LIMIT $3`,
    [publishedBefore, remindedBefore, limit]
  );
}

export async function markListingReminded(db, { id, now }) {
  await db.execute('UPDATE listings SET last_reminded_at = $1 WHERE id = $2', [now, id]);
}

export async function facets(db) {
  const makes = await db.query("SELECT DISTINCT make AS value FROM listings WHERE status = 'active' ORDER BY make LIMIT 300");
  const regions = await db.query("SELECT DISTINCT region AS value FROM listings WHERE status = 'active' ORDER BY region LIMIT 300");
  return { makes: makes.map((row) => row.value), regions: regions.map((row) => row.value) };
}

// ---- Photos ----------------------------------------------------------------------------

export async function countPhotos(db, listingId) {
  const rows = await db.query('SELECT CAST(COUNT(*) AS INTEGER) AS n FROM photos WHERE listing_id = $1', [listingId]);
  return Number(rows[0].n);
}

export async function insertPhoto(db, photo) {
  await db.execute(
    `INSERT INTO photos (id, listing_id, storage_key, content_type, size_bytes, position, created_at)
     VALUES ($1, $2, $3, $4, $5, $6, $7)`,
    [photo.id, photo.listingId, photo.storageKey, photo.contentType, photo.sizeBytes, photo.position, photo.createdAt]
  );
}

export async function listPhotos(db, listingId) {
  const rows = await db.query('SELECT * FROM photos WHERE listing_id = $1 ORDER BY position', [listingId]);
  return rows;
}

/** Returns the photo with its listing status and seller, for access checks and streaming. */
export async function getPhotoWithListing(db, photoId) {
  const rows = await db.query(
    `SELECT p.*, l.status AS listing_status, l.seller_id FROM photos p
     JOIN listings l ON l.id = p.listing_id WHERE p.id = $1`,
    [photoId]
  );
  return rows[0] || null;
}

export async function deletePhoto(db, { id, listingId }) {
  const rows = await db.query('DELETE FROM photos WHERE id = $1 AND listing_id = $2 RETURNING storage_key', [id, listingId]);
  return rows[0] || null;
}

// ---- Inquiries -------------------------------------------------------------------------

const INQUIRY_SELECT = `SELECT i.*, l.make, l.model, l.year, l.seller_id FROM inquiries i JOIN listings l ON l.id = i.listing_id`;

export async function insertInquiry(db, inquiry) {
  await db.execute(
    `INSERT INTO inquiries (id, listing_id, buyer_name, buyer_email, buyer_phone, message, consent_at, status, created_at, updated_at)
     VALUES ($1, $2, $3, $4, $5, $6, $7, 'new', $7, $7)`,
    [inquiry.id, inquiry.listingId, inquiry.buyerName, inquiry.buyerEmail, inquiry.buyerPhone || null, inquiry.message, inquiry.now]
  );
}

export async function listInquiries(db, { sellerId, listingId, status, limit, offset }) {
  const where = ['l.seller_id = $1'];
  const params = [sellerId];
  if (listingId) {
    params.push(listingId);
    where.push(`i.listing_id = $${params.length}`);
  }
  if (status) {
    params.push(status);
    where.push(`i.status = $${params.length}`);
  }
  const clause = where.join(' AND ');
  const countRows = await db.query(
    `SELECT CAST(COUNT(*) AS INTEGER) AS total FROM inquiries i JOIN listings l ON l.id = i.listing_id WHERE ${clause}`,
    params
  );
  const rows = await db.query(
    `${INQUIRY_SELECT} WHERE ${clause} ORDER BY i.created_at DESC, i.id LIMIT $${params.length + 1} OFFSET $${params.length + 2}`,
    [...params, limit, offset]
  );
  return { items: rows.map(mapInquiry), total: Number(countRows[0].total) };
}

export async function updateInquiryStatus(db, { id, sellerId, status, now }) {
  const rows = await db.query(
    `UPDATE inquiries SET status = $1, updated_at = $2
     WHERE id = $3 AND listing_id IN (SELECT id FROM listings WHERE seller_id = $4)
     RETURNING id, status`,
    [status, now, id, sellerId]
  );
  return rows[0] || null;
}

/** Everything the notification handlers need, joined in one query. */
export async function getInquiryContext(db, inquiryId) {
  const rows = await db.query(
    `SELECT i.id, i.buyer_name, i.buyer_email, i.buyer_phone, i.message, i.listing_id,
            l.make, l.model, l.year, l.status AS listing_status,
            u.id AS seller_id, u.name AS seller_name, u.email AS seller_email, u.phone AS seller_phone, u.whatsapp_opt_in
     FROM inquiries i JOIN listings l ON l.id = i.listing_id JOIN users u ON u.id = l.seller_id
     WHERE i.id = $1`,
    [inquiryId]
  );
  return rows[0] || null;
}

export async function getListingContact(db, listingId) {
  const rows = await db.query(
    `SELECT l.id, l.make, l.model, l.year, l.status, u.id AS seller_id, u.name AS seller_name, u.email AS seller_email
     FROM listings l JOIN users u ON u.id = l.seller_id WHERE l.id = $1`,
    [listingId]
  );
  return rows[0] || null;
}

// ---- Outbound integrations ------------------------------------------------------------

export async function getExternalListing(db, listingId, provider) {
  const rows = await db.query('SELECT * FROM external_listings WHERE listing_id = $1 AND provider = $2', [listingId, provider]);
  return rows[0] || null;
}

export async function listExternalListings(db, listingId) {
  return db.query('SELECT provider, external_id, status, last_error, updated_at FROM external_listings WHERE listing_id = $1 ORDER BY provider', [listingId]);
}

export async function markExternalPending(db, { id, listingId, provider, now }) {
  await db.execute(
    `INSERT INTO external_listings (id, listing_id, provider, status, created_at, updated_at)
     VALUES ($1, $2, $3, 'pending', $4, $4)
     ON CONFLICT (listing_id, provider) DO UPDATE SET status = 'pending', last_error = NULL, updated_at = excluded.updated_at`,
    [id, listingId, provider, now]
  );
}

export async function markExternalResult(db, { listingId, provider, status, externalId, error, now }) {
  await db.execute(
    'UPDATE external_listings SET status = $1, external_id = COALESCE($2, external_id), last_error = $3, updated_at = $4 WHERE listing_id = $5 AND provider = $6',
    [status, externalId || null, error || null, now, listingId, provider]
  );
}

// ---- Jobs ------------------------------------------------------------------------------

export async function enqueueJob(db, job) {
  const result = await db.execute(
    `INSERT INTO jobs (id, type, payload, status, attempts, max_attempts, run_at, dedupe_key, created_at, updated_at)
     VALUES ($1, $2, $3, 'queued', 0, $4, $5, $6, $7, $7)
     ON CONFLICT (dedupe_key) DO NOTHING`,
    [job.id, job.type, JSON.stringify(job.payload), job.maxAttempts, job.runAt, job.dedupeKey || null, job.now]
  );
  return result.changes > 0;
}

/** Claims one ready job (or one whose lock expired). Row locking is applied where the dialect supports it. */
export async function claimJob(db, { now, staleBefore }) {
  const rows = await db.query(
    `UPDATE jobs SET status = 'running', attempts = attempts + 1, locked_at = $1, updated_at = $1
     WHERE id = (
       SELECT id FROM jobs
       WHERE (status = 'queued' AND run_at <= $1) OR (status = 'running' AND locked_at <= $2)
       ORDER BY run_at, id
       LIMIT 1 ${db.lockClause}
     )
     RETURNING id, type, payload, attempts, max_attempts`,
    [now, staleBefore]
  );
  const row = rows[0];
  if (!row) return null;
  return { id: row.id, type: row.type, payload: JSON.parse(row.payload), attempts: Number(row.attempts), maxAttempts: Number(row.max_attempts) };
}

export async function completeJob(db, { id, now }) {
  await db.execute("UPDATE jobs SET status = 'done', last_error = NULL, locked_at = NULL, updated_at = $1 WHERE id = $2", [now, id]);
}

export async function failJob(db, { id, error, status, runAt, now }) {
  await db.execute(
    'UPDATE jobs SET status = $1, last_error = $2, locked_at = NULL, run_at = $3, updated_at = $4 WHERE id = $5',
    [status, error, runAt, now, id]
  );
}

export async function requeueFailedJob(db, { id, now }) {
  const rows = await db.query(
    "UPDATE jobs SET status = 'queued', attempts = 0, run_at = $1, last_error = NULL, updated_at = $1 WHERE id = $2 AND status = 'failed' RETURNING id",
    [now, id]
  );
  return rows.length > 0;
}

export async function listJobs(db, { status, limit }) {
  const params = [];
  let clause = '';
  if (status) {
    params.push(status);
    clause = 'WHERE status = $1';
  }
  params.push(limit);
  const rows = await db.query(
    `SELECT id, type, status, attempts, max_attempts, run_at, last_error, created_at, updated_at FROM jobs ${clause}
     ORDER BY updated_at DESC LIMIT $${params.length}`,
    params
  );
  return rows.map((row) => ({
    id: row.id,
    type: row.type,
    status: row.status,
    attempts: Number(row.attempts),
    maxAttempts: Number(row.max_attempts),
    runAt: iso(row.run_at),
    lastError: row.last_error,
    updatedAt: iso(row.updated_at)
  }));
}

// ---- Audit -----------------------------------------------------------------------------

export async function recordAudit(db, { id, actorId, event, entityType, entityId, metadata = {}, now }) {
  await db.execute(
    'INSERT INTO audit_events (id, actor_id, event, entity_type, entity_id, metadata, created_at) VALUES ($1, $2, $3, $4, $5, $6, $7)',
    [id, actorId || null, event, entityType, String(entityId), JSON.stringify(metadata), now]
  );
}

export async function hasAudit(db, { entityType, entityId, event }) {
  const rows = await db.query(
    'SELECT id FROM audit_events WHERE entity_type = $1 AND entity_id = $2 AND event = $3 LIMIT 1',
    [entityType, String(entityId), event]
  );
  return rows.length > 0;
}

// ---- Account tokens (email verification, password reset) -------------------------------

export async function insertAccountToken(db, { id, userId, purpose, tokenHash, expiresAt, now }) {
  await db.execute(
    'INSERT INTO account_tokens (id, user_id, purpose, token_hash, expires_at, created_at) VALUES ($1, $2, $3, $4, $5, $6)',
    [id, userId, purpose, tokenHash, expiresAt, now]
  );
}

export async function getAccountToken(db, id) {
  const rows = await db.query('SELECT id, user_id, purpose, used_at, expires_at FROM account_tokens WHERE id = $1', [id]);
  return rows[0] || null;
}

/** Revokes every unused token of one purpose, so only the most recent link works. */
export async function revokeAccountTokens(db, { userId, purpose, now }) {
  await db.execute(
    'UPDATE account_tokens SET used_at = $3 WHERE user_id = $1 AND purpose = $2 AND used_at IS NULL',
    [userId, purpose, now]
  );
}

/**
 * Marks a token as used and returns its user id. Returns null when the token is unknown, already used,
 * expired or for another purpose. The UPDATE is conditional, so two concurrent clicks cannot both succeed.
 */
export async function consumeAccountToken(db, { tokenHash, purpose, now }) {
  const rows = await db.query(
    `UPDATE account_tokens SET used_at = $3
     WHERE token_hash = $1 AND purpose = $2 AND used_at IS NULL AND expires_at > $3
     RETURNING user_id`,
    [tokenHash, purpose, now]
  );
  return rows[0] ? rows[0].user_id : null;
}

export async function markEmailVerified(db, { userId, now }) {
  await db.execute('UPDATE users SET email_verified_at = COALESCE(email_verified_at, $2) WHERE id = $1', [userId, now]);
}

/** Invalidates every session of an account without changing its password. */
export async function revokeSessions(db, { userId }) {
  await db.execute('UPDATE users SET session_version = session_version + 1 WHERE id = $1', [userId]);
}

/** Replaces the password and bumps session_version, which signs out every existing session. */
export async function updatePassword(db, { userId, passwordHash, now }) {
  await db.execute(
    `UPDATE users SET password_hash = $2, session_version = session_version + 1,
       email_verified_at = COALESCE(email_verified_at, $3) WHERE id = $1`,
    [userId, passwordHash, now]
  );
}

// ---- Shared rate limits (RATE_LIMIT_STORE=database) ------------------------------------

/** Adds one hit to a fixed window and returns the count and the window's end, in one statement. */
export async function incrementRateBucket(db, { bucket, nowIso, resetIso }) {
  const rows = await db.query(
    `INSERT INTO rate_limits (bucket, hits, reset_at) VALUES ($1, 1, $3)
     ON CONFLICT (bucket) DO UPDATE SET
       hits = CASE WHEN rate_limits.reset_at <= $2 THEN 1 ELSE rate_limits.hits + 1 END,
       reset_at = CASE WHEN rate_limits.reset_at <= $2 THEN $3 ELSE rate_limits.reset_at END
     RETURNING hits, reset_at`,
    [bucket, nowIso, resetIso]
  );
  return { hits: Number(rows[0].hits), resetAt: new Date(rows[0].reset_at).getTime() };
}

export async function deleteExpiredRateBuckets(db, nowIso) {
  await db.execute('DELETE FROM rate_limits WHERE reset_at <= $1', [nowIso]);
}

/**
 * Retention for rows that only matter while they are fresh. Failed jobs and the audit log are kept:
 * admins need the former, and the latter is a record of account and listing events.
 */
export async function pruneOperationalRecords(db, { doneJobsBefore, linksExpiredBefore }) {
  const jobs = await db.execute("DELETE FROM jobs WHERE status = 'done' AND updated_at < $1", [doneJobsBefore]);
  const tokens = await db.execute('DELETE FROM account_tokens WHERE expires_at < $1', [linksExpiredBefore]);
  return { jobs: jobs.changes, accountTokens: tokens.changes };
}
