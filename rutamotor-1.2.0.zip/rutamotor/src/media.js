import crypto from 'node:crypto';
import fs from 'node:fs/promises';
import path from 'node:path';

const PNG_SIGNATURE = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]);
const KEY_PATTERN = /^[0-9a-f-]{36}\.(jpg|png|webp)$/;

/** Identifies JPEG, PNG and WebP by their magic bytes. The client-supplied type is ignored. */
export function detectImage(buffer) {
  if (buffer.length >= 3 && buffer[0] === 0xff && buffer[1] === 0xd8 && buffer[2] === 0xff) return { contentType: 'image/jpeg', ext: 'jpg' };
  if (buffer.length >= 8 && buffer.subarray(0, 8).equals(PNG_SIGNATURE)) return { contentType: 'image/png', ext: 'png' };
  if (buffer.length >= 12 && buffer.subarray(0, 4).toString('ascii') === 'RIFF' && buffer.subarray(8, 12).toString('ascii') === 'WEBP') {
    return { contentType: 'image/webp', ext: 'webp' };
  }
  return null;
}

/** Local-disk photo storage. Keys are generated server-side, so user input never forms a path. */
export function createStorage(dir) {
  const resolved = path.resolve(dir);
  return {
    async save(buffer, ext) {
      await fs.mkdir(resolved, { recursive: true });
      const key = `${crypto.randomUUID()}.${ext}`;
      await fs.writeFile(path.join(resolved, key), buffer, { flag: 'wx' });
      return key;
    },
    async read(key) {
      if (!KEY_PATTERN.test(key)) throw new Error('Invalid storage key.');
      return fs.readFile(path.join(resolved, key));
    },
    async remove(key) {
      if (KEY_PATTERN.test(key)) await fs.rm(path.join(resolved, key), { force: true });
    }
  };
}
