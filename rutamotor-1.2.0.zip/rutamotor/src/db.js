import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const SCHEMA_DIR = path.join(path.dirname(fileURLToPath(import.meta.url)), 'schema');

// Queries are written once with PostgreSQL-style $1 placeholders.
const toSqliteSql = (sql) => sql.replace(/\$(\d+)/g, '?$1');

function toSqliteParam(value) {
  if (value === undefined || value === null) return null;
  if (value instanceof Date) return value.toISOString();
  if (typeof value === 'boolean') return value ? 1 : 0;
  return value;
}

async function createSqlite(file) {
  const { DatabaseSync } = await import('node:sqlite');
  if (file !== ':memory:') fs.mkdirSync(path.dirname(path.resolve(file)), { recursive: true });
  const native = new DatabaseSync(file);
  native.exec('PRAGMA foreign_keys = ON; PRAGMA busy_timeout = 5000;');
  if (file !== ':memory:') native.exec('PRAGMA journal_mode = WAL;');

  // node:sqlite is synchronous. Serialising every operation keeps an open transaction
  // from interleaving with other requests that share the same connection.
  let tail = Promise.resolve();
  const exclusive = (task) => {
    const run = tail.then(task);
    tail = run.catch(() => {});
    return run;
  };
  const all = (sql, params = []) => native.prepare(toSqliteSql(sql)).all(...params.map(toSqliteParam));
  const run = (sql, params = []) => {
    const result = native.prepare(toSqliteSql(sql)).run(...params.map(toSqliteParam));
    return { changes: Number(result.changes) };
  };
  // Transaction scopes expose the same dialect properties as the adapter, so queries built from them stay correct.
  const scope = {
    dialect: 'sqlite',
    lockClause: '',
    rowLock: '',
    query: async (sql, params) => all(sql, params),
    execute: async (sql, params) => run(sql, params),
    exec: async (sql) => native.exec(sql)
  };

  return {
    dialect: 'sqlite',
    lockClause: '',
    rowLock: '',
    query: (sql, params) => exclusive(async () => all(sql, params)),
    execute: (sql, params) => exclusive(async () => run(sql, params)),
    exec: (sql) => exclusive(async () => native.exec(sql)),
    transaction: (fn) => exclusive(async () => {
      native.exec('BEGIN IMMEDIATE');
      try {
        const result = await fn(scope);
        native.exec('COMMIT');
        return result;
      } catch (error) {
        native.exec('ROLLBACK');
        throw error;
      }
    }),
    async ping() {
      native.prepare('SELECT 1 AS ok').get();
    },
    async close() {
      native.close();
    }
  };
}

const SCHEMA_NAME = /^[a-z_][a-z0-9_]{0,62}$/;

async function createPostgres(url, { schema } = {}) {
  const { default: pg } = await import('pg');
  if (schema) {
    // Isolated schemas let parallel test processes share one PostgreSQL server safely.
    if (!SCHEMA_NAME.test(schema)) throw new Error('Invalid PostgreSQL schema name.');
    const admin = new pg.Pool({ connectionString: url, max: 1 });
    try {
      await admin.query(`CREATE SCHEMA IF NOT EXISTS ${schema}`);
    } finally {
      await admin.end();
    }
  }
  const pool = new pg.Pool({
    connectionString: url,
    max: Number(process.env.PG_POOL_MAX || 10),
    idleTimeoutMillis: 30_000,
    connectionTimeoutMillis: 5_000,
    ssl: process.env.PGSSL === 'true' ? { rejectUnauthorized: true } : undefined,
    options: schema ? `-c search_path=${schema}` : undefined
  });
  pool.on('error', (error) => console.error('PostgreSQL pool error:', error.message));

  const scopeFor = (client) => ({
    dialect: 'postgres',
    lockClause: 'FOR UPDATE SKIP LOCKED',
    rowLock: 'FOR UPDATE',
    query: async (sql, params = []) => (await client.query(sql, params)).rows,
    execute: async (sql, params = []) => ({ changes: (await client.query(sql, params)).rowCount ?? 0 }),
    // No parameters: pg uses the simple protocol, which accepts several statements.
    exec: async (sql) => {
      await client.query(sql);
    }
  });
  const pooled = scopeFor(pool);

  return {
    dialect: 'postgres',
    lockClause: 'FOR UPDATE SKIP LOCKED',
    rowLock: 'FOR UPDATE',
    query: pooled.query,
    execute: pooled.execute,
    exec: pooled.exec,
    async transaction(fn) {
      const client = await pool.connect();
      try {
        await client.query('BEGIN');
        const result = await fn(scopeFor(client));
        await client.query('COMMIT');
        return result;
      } catch (error) {
        await client.query('ROLLBACK').catch(() => {});
        throw error;
      } finally {
        client.release();
      }
    },
    async ping() {
      await pool.query('SELECT 1');
    },
    async close() {
      await pool.end();
    }
  };
}

export async function createDatabase(url, options = {}) {
  if (/^postgres(ql)?:\/\//i.test(url)) return createPostgres(url, options);
  if (url.startsWith('sqlite:')) return createSqlite(url.slice('sqlite:'.length));
  throw new Error('DATABASE_URL must start with sqlite: or postgres://');
}

// Arbitrary constant. Every migrator takes this lock, so only one runs at a time.
const MIGRATION_LOCK_KEY = 727245;

/**
 * Applies pending schema files for the active dialect in one transaction.
 * Several API instances may start at once: the lock (PostgreSQL advisory lock, or SQLite's
 * BEGIN IMMEDIATE) makes the others wait, and then they find nothing left to apply.
 */
export async function migrate(db) {
  const dir = path.join(SCHEMA_DIR, db.dialect);
  const files = fs.readdirSync(dir).filter((name) => name.endsWith('.sql')).sort();
  return db.transaction(async (scope) => {
    if (scope.dialect === 'postgres') await scope.query('SELECT pg_advisory_xact_lock($1)', [MIGRATION_LOCK_KEY]);
    await scope.exec('CREATE TABLE IF NOT EXISTS schema_migrations (version TEXT PRIMARY KEY, applied_at TEXT NOT NULL)');
    const applied = new Set((await scope.query('SELECT version FROM schema_migrations')).map((row) => row.version));
    const pending = [];
    for (const file of files) {
      const version = file.replace(/\.sql$/, '');
      if (applied.has(version)) continue;
      await scope.exec(fs.readFileSync(path.join(dir, file), 'utf8'));
      await scope.execute('INSERT INTO schema_migrations (version, applied_at) VALUES ($1, $2)', [version, new Date().toISOString()]);
      pending.push(version);
    }
    return pending;
  });
}

export function isUniqueViolation(error) {
  return error?.code === '23505' || /UNIQUE constraint failed/.test(String(error?.message || ''));
}
