// Fixed-window rate limiter backed by the database, so every API instance shares the same counters.
// Each request costs one upsert, so it is opt-in (RATE_LIMIT_STORE=database) for multi-instance deployments.
import * as store from './store.js';

const PRUNE_EVERY = 100;

export function createDatabaseRateLimiter(db, { now = () => Date.now() } = {}) {
  let calls = 0;
  return {
    async hit(key, limit, windowMs) {
      const time = now();
      const { hits, resetAt } = await store.incrementRateBucket(db, {
        bucket: key,
        nowIso: new Date(time).toISOString(),
        resetIso: new Date(time + windowMs).toISOString()
      });
      calls += 1;
      if (calls % PRUNE_EVERY === 0) await store.deleteExpiredRateBuckets(db, new Date(time).toISOString());
      return { allowed: hits <= limit, retryAfterSeconds: Math.max(1, Math.ceil((resetAt - time) / 1000)) };
    }
  };
}
