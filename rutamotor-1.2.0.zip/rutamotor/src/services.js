import { createLogger } from './logger.js';
import { createEmailService } from './integrations/email.js';
import { createWhatsAppService } from './integrations/whatsapp.js';
import { createAiService } from './integrations/ai.js';
import { createWebhookSender } from './integrations/webhooks.js';
import { createCompraDeAutosClient } from './integrations/compradeautos.js';
import { createStorage } from './media.js';

/** Wires every external integration. Tests pass a fake `fetchImpl` and a capturing logger. */
export function createServices(config, { fetchImpl = fetch, logger = createLogger() } = {}) {
  return {
    logger,
    email: createEmailService({
      provider: config.email.provider, resendApiKey: config.email.resendApiKey, from: config.email.from,
      fetchImpl, logger, logBody: config.env === 'development'
    }),
    whatsapp: createWhatsAppService({
      accessToken: config.whatsapp.accessToken,
      phoneNumberId: config.whatsapp.phoneNumberId,
      graphVersion: config.whatsapp.graphVersion,
      language: config.whatsapp.language,
      fetchImpl
    }),
    ai: createAiService({ baseUrl: config.ai.baseUrl, apiKey: config.ai.apiKey, model: config.ai.model, timeoutMs: config.ai.timeoutMs, fetchImpl, logger }),
    webhooks: createWebhookSender({ url: config.webhooks.url, secret: config.webhooks.secret, fetchImpl }),
    compradeautos: createCompraDeAutosClient({ apiKey: config.compradeautos.apiKey, baseUrl: config.compradeautos.baseUrl, fetchImpl }),
    storage: createStorage(config.uploadDir)
  };
}
