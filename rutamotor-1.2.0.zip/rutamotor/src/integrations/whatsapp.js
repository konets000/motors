/**
 * WhatsApp Business Cloud API, template messages only.
 * Proactive messages require an approved template and the recipient's explicit opt-in (checked by the caller).
 */
export function createWhatsAppService({ accessToken, phoneNumberId, graphVersion, language = 'en', fetchImpl = fetch }) {
  const configured = Boolean(accessToken && phoneNumberId && graphVersion);
  return {
    configured,
    async sendTemplate({ to, template, parameters = [] }) {
      if (!configured) return { sent: false, reason: 'whatsapp_not_configured' };
      if (!/^v\d+\.\d+$/.test(graphVersion)) throw new Error('WHATSAPP_GRAPH_API_VERSION must look like v21.0');
      const digits = String(to || '').replace(/\D/g, '');
      if (digits.length < 8) return { sent: false, reason: 'invalid_phone' };
      const templatePayload = {
        name: template,
        language: { code: language },
        ...(parameters.length ? { components: [{ type: 'body', parameters: parameters.map((text) => ({ type: 'text', text: String(text).slice(0, 200) })) }] } : {})
      };
      const response = await fetchImpl(`https://graph.facebook.com/${graphVersion}/${phoneNumberId}/messages`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${accessToken}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ messaging_product: 'whatsapp', recipient_type: 'individual', to: digits, type: 'template', template: templatePayload }),
        signal: AbortSignal.timeout(15_000),
        redirect: 'error'
      });
      if (!response.ok) throw new Error(`WhatsApp Cloud API responded with HTTP ${response.status}.`);
      return { sent: true, reason: 'sent' };
    }
  };
}
