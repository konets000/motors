import crypto from 'node:crypto';

/** Signature format: `t=<unix seconds>,v1=<hex HMAC-SHA256 of "t.body">`. */
export function signWebhook(secret, timestamp, body) {
  return crypto.createHmac('sha256', secret).update(`${timestamp}.${body}`).digest('hex');
}

/** Receivers should call this; it rejects bad signatures and stale timestamps. */
export function verifyWebhookSignature(secret, header, body, { toleranceSeconds = 300, nowSeconds = Math.floor(Date.now() / 1000) } = {}) {
  const parts = Object.fromEntries(String(header || '').split(',').map((part) => part.split('=')));
  const timestamp = Number(parts.t);
  if (!Number.isFinite(timestamp) || Math.abs(nowSeconds - timestamp) > toleranceSeconds || !parts.v1) return false;
  const expected = Buffer.from(signWebhook(secret, timestamp, body), 'hex');
  const given = Buffer.from(parts.v1, 'hex');
  return given.length === expected.length && crypto.timingSafeEqual(given, expected);
}

export function createWebhookSender({ url, secret, fetchImpl = fetch, now = () => Date.now() }) {
  return {
    configured: Boolean(url),
    async deliver({ deliveryId, event, data }) {
      const body = JSON.stringify({ id: deliveryId, event, occurredAt: new Date(now()).toISOString(), data });
      const timestamp = Math.floor(now() / 1000);
      const headers = {
        'Content-Type': 'application/json',
        'User-Agent': 'RutaMotor-Webhooks/1.0',
        'X-RutaMotor-Event': event,
        'X-RutaMotor-Delivery': deliveryId
      };
      if (secret) headers['X-RutaMotor-Signature'] = `t=${timestamp},v1=${signWebhook(secret, timestamp, body)}`;
      const response = await fetchImpl(url, { method: 'POST', headers, body, signal: AbortSignal.timeout(10_000), redirect: 'error' });
      if (!response.ok) throw new Error(`Webhook endpoint responded with HTTP ${response.status}.`);
      return { delivered: true };
    }
  };
}
