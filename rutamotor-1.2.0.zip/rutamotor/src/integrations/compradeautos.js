// Client for publishing listings to CompraDeAutos.cl.
// Endpoints and field names follow the public API notes used when this was written.
// Verify them against the current CompraDeAutos documentation before enabling in production.
// The external API expects its own Spanish field names and values (marca, modelo, comuna, "Automática", "Bencina", …).
// RutaMotor's domain stays in English; the mappings below translate at this boundary only.

const TRANSMISSION_LABELS = { automatic: 'Automática', manual: 'Manual' };
const FUEL_LABELS = { petrol: 'Bencina', diesel: 'Diesel', hybrid: 'Híbrido', electric: 'Eléctrico', lpg: 'Gas' };
const ALLOWED_IMAGE_TYPES = new Set(['image/jpeg', 'image/png', 'image/webp']);
const MAX_PHOTOS = 10;
const MAX_PHOTO_BYTES = 15 * 1024 * 1024;

/** An error that retrying cannot fix (validation, rejected content). The job runner does not retry these. */
export function permanentError(message) {
  const error = new Error(message);
  error.permanent = true;
  return error;
}

async function requestJson(fetchImpl, url, { token, method = 'GET', body, timeoutMs = 15_000 }) {
  const response = await fetchImpl(url, {
    method,
    headers: {
      Accept: 'application/json',
      Authorization: `Bearer ${token}`,
      ...(body === undefined ? {} : { 'Content-Type': 'application/json' })
    },
    ...(body === undefined ? {} : { body: JSON.stringify(body) }),
    signal: AbortSignal.timeout(timeoutMs),
    redirect: 'error'
  });
  let data = {};
  try {
    data = await response.json();
  } catch {
    data = {};
  }
  if (!response.ok && response.status !== 202) {
    const detail = data?.message ? `: ${String(data.message).slice(0, 180)}` : '';
    const error = new Error(`CompraDeAutos responded with HTTP ${response.status}${detail}.`);
    error.permanent = [400, 401, 403, 404, 422].includes(response.status);
    throw error;
  }
  return { status: response.status, data };
}

export function createCompraDeAutosClient({ apiKey, baseUrl, fetchImpl = fetch, pollIntervalMs = 2000, pollTimeoutMs = 90_000, sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms)) }) {
  const configured = Boolean(apiKey);
  const root = (baseUrl || '').replace(/\/$/, '');

  /**
   * @param {{listing: object, photos: {fileName: string, mimeType: string, bytes: Buffer, isMain?: boolean}[], contact: object}} input
   */
  async function publish({ listing, photos, contact }) {
    if (!configured) throw permanentError('CompraDeAutos is not configured on this server.');
    if (!Array.isArray(photos) || photos.length < 1 || photos.length > MAX_PHOTOS) throw permanentError(`CompraDeAutos requires between 1 and ${MAX_PHOTOS} photos.`);
    if (listing.engineCc === null || listing.engineCc === undefined) throw permanentError('Engine displacement (cc) is required before publishing externally.');
    const fuel = FUEL_LABELS[listing.fuel];
    if (!fuel) throw permanentError('This fuel type is not supported by CompraDeAutos.');
    const transmission = TRANSMISSION_LABELS[listing.transmission];
    if (!transmission) throw permanentError('This transmission type is not supported by CompraDeAutos.');
    if (listing.price > 300_000_000) throw permanentError('Price exceeds the maximum accepted by CompraDeAutos.');
    if (listing.mileage > 1_000_000) throw permanentError('Mileage exceeds the maximum accepted by CompraDeAutos.');
    if (!contact.showEmail && !contact.showPhone && !contact.showWhatsApp) throw permanentError('At least one contact channel must be shown.');

    const images = [];
    for (const photo of photos) {
      if (!ALLOWED_IMAGE_TYPES.has(photo.mimeType)) throw permanentError(`Unsupported photo type: ${photo.mimeType}.`);
      if (!Buffer.isBuffer(photo.bytes) || photo.bytes.length < 1 || photo.bytes.length > MAX_PHOTO_BYTES) throw permanentError('Each photo must be between 1 byte and 15 MB.');

      const upload = await requestJson(fetchImpl, `${root}/autos/images`, {
        token: apiKey,
        method: 'POST',
        body: { fileName: String(photo.fileName).slice(0, 180), fileType: photo.mimeType, fileSize: photo.bytes.length }
      });
      const { uploadUrl, objectKey, method, headers } = upload.data || {};
      if (!uploadUrl || !objectKey) throw new Error('CompraDeAutos did not return an upload URL.');
      if (new URL(uploadUrl).protocol !== 'https:') throw permanentError('The upload URL must use https.');

      const putResponse = await fetchImpl(uploadUrl, {
        method: method || 'PUT',
        headers: { ...(headers || {}), 'Content-Type': photo.mimeType },
        body: photo.bytes,
        signal: AbortSignal.timeout(30_000),
        redirect: 'error'
      });
      if (!putResponse.ok) throw new Error(`Photo upload failed with HTTP ${putResponse.status}.`);

      const deadline = Date.now() + pollTimeoutMs;
      let accepted = null;
      while (Date.now() < deadline) {
        const statusUrl = new URL(`${root}/autos/images/status`);
        statusUrl.searchParams.set('objectKey', objectKey);
        const status = await requestJson(fetchImpl, statusUrl, { token: apiKey, timeoutMs: 15_000 });
        if (status.data.status === 'accepted' && status.data.url) {
          accepted = status.data.url;
          break;
        }
        if (status.data.status === 'rejected') throw permanentError(`CompraDeAutos rejected a photo: ${String(status.data.message || 'no reason given').slice(0, 180)}`);
        await sleep(pollIntervalMs);
      }
      if (!accepted) throw new Error('Photo validation did not finish in time.');
      images.push({ url: accepted, is_main: photo.isMain === true });
    }
    if (!images.some((image) => image.is_main)) images[0].is_main = true;

    const payload = {
      marca: listing.make,
      modelo: listing.model,
      'año': listing.year,
      precio: listing.price,
      region: listing.region,
      comuna: listing.city,
      kilometraje: listing.mileage,
      tipo_combustible: fuel,
      transmision: transmission,
      cilindrada: listing.engineCc,
      estado: 'Usado',
      comentario: listing.description || null,
      mostrar_whatsapp: Boolean(contact.showWhatsApp),
      mostrar_telefono: Boolean(contact.showPhone),
      mostrar_correo: Boolean(contact.showEmail),
      mostrar_nombre: Boolean(contact.showName),
      imagen_url: images,
      publicado: true
    };
    const published = await requestJson(fetchImpl, `${root}/autos`, { token: apiKey, method: 'POST', body: payload, timeoutMs: 20_000 });
    if (!published.data?.id) throw new Error('CompraDeAutos did not confirm a listing id.');
    return { externalId: String(published.data.id), message: published.data.message || 'Published.' };
  }

  return { configured, publish };
}
