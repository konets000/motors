import { maskEmail } from '../domain.js';

/**
 * Transactional email. Providers:
 *  - log: prints a redacted line (development)
 *  - resend: Resend HTTP API (production)
 *  - disabled: sends nothing
 */
export function createEmailService({ provider = 'log', resendApiKey, from, fetchImpl = fetch, logger, logBody = false }) {
  return {
    provider,
    async send({ to, subject, html, text }) {
      if (provider === 'disabled') return { sent: false, reason: 'email_disabled' };
      if (provider === 'log') {
        // Development only: the body carries one-time links, so it is never logged in production.
        logger?.info('email.logged', logBody ? { to: maskEmail(to), subject, body: text } : { to: maskEmail(to), subject });
        return { sent: true, reason: 'logged' };
      }
      if (provider !== 'resend') throw new Error(`Unknown email provider: ${provider}`);
      if (!resendApiKey || !from) return { sent: false, reason: 'email_not_configured' };
      const response = await fetchImpl('https://api.resend.com/emails', {
        method: 'POST',
        headers: { Authorization: `Bearer ${resendApiKey}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ from, to: [to], subject, html, text }),
        signal: AbortSignal.timeout(15_000),
        redirect: 'error'
      });
      if (!response.ok) throw new Error(`Email provider responded with HTTP ${response.status}.`);
      return { sent: true, reason: 'sent' };
    }
  };
}
