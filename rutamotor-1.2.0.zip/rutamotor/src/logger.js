// One JSON object per line. Fields whose names look like credentials are redacted.
const SECRET_FIELD = /token|secret|password|authorization|api[_-]?key|cookie/i;

function scrub(fields) {
  return Object.fromEntries(Object.entries(fields).map(([key, value]) => [key, SECRET_FIELD.test(key) ? '[redacted]' : value]));
}

export function createLogger(sink = console) {
  const write = (level, event, fields = {}) => {
    const line = JSON.stringify({ time: new Date().toISOString(), level, event, ...scrub(fields) });
    (level === 'error' ? sink.error : sink.log)(line);
  };
  return {
    info: (event, fields) => write('info', event, fields),
    warn: (event, fields) => write('warn', event, fields),
    error: (event, fields) => write('error', event, fields)
  };
}
