# RutaMotor

A used-car marketplace where sellers publish vehicles and buyers search, compare and contact sellers directly. The platform also connects to external services (email, WhatsApp, an AI model, CompraDeAutos.cl and signed outbound webhooks), runs background automations, and includes an AI buying assistant.

Interface and documentation are in English. The launch market configuration uses Chilean pesos (`CURRENCY=CLP`) and sample regions; both are configurable.

## Features

**For buyers**
- Search and filter by make, body type, fuel, transmission, region, price, year and mileage; sort by price, year or mileage.
- Listing pages with photo gallery, full specifications and a description written by the seller.
- Contact the seller through a form with explicit consent. Messages are stored and the seller is notified.
- Compare up to three cars side by side.
- AI buying assistant that recommends only from current listings.

**For sellers**
- Create, edit and renew listings. Upload up to 10 photos per listing (JPEG, PNG or WebP, checked by file signature).
- Draft descriptions with AI; the fallback draft uses only the facts you entered.
- Manage status (active, reserved, sold, archived) under enforced transition rules.
- Inbox for inquiries with status tracking and CSV export.
- Publish a listing to CompraDeAutos.cl from the seller dashboard.

**Accounts**
- Confirm the email address with a one-time link (valid 72 hours). Until then, the account shows a reminder and can request a new link.
- Reset a forgotten password with a one-time link (valid 1 hour). A completed reset signs out every other session and emails the account holder.
- Optionally require a confirmed email before publishing listings (`REQUIRE_VERIFIED_EMAIL=true`).

**For operators**
- Admin job console: inspect the queue, retry failed jobs.
- Listing moderation with a recorded reason.
- Audit log of account, listing, inquiry and integration events.

## Architecture at a glance

```
Browser (SPA)  ──HTTP──►  API server (node:http)  ──►  PostgreSQL (production)
                              │                        or SQLite (development/single node)
                              │  transactional outbox (jobs table)
                              ▼
                         Worker process  ──►  Email (Resend)
                                         ──►  WhatsApp Business Cloud API
                                         ──►  Outbound webhooks (signed)
                                         ──►  CompraDeAutos.cl API
                                         ──►  AI provider (OpenAI-compatible)
```

See [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) for data model, job lifecycle and security decisions. See [docs/API.md](docs/API.md) for every endpoint.

## Quick start (development, no external services)

Requirements: Node.js 22.13 or newer. SQLite is built into Node, so no database server is needed.

```bash
npm install
npm run migrate                    # creates ./data/rutamotor.db
DEMO_PASSWORD=choose-a-password npm run seed   # optional fictional demo sellers and listings
npm run dev                        # API and web app on http://localhost:3000
npm run worker                     # in a second terminal: background automations
```

Open http://localhost:3000. Development uses `EMAIL_PROVIDER=log`: emails are printed to the console with their full text, including the confirmation and reset links, so you can follow them without a mail server. On first run a development secret is written to `data/.dev-auth-secret`, which the API and the worker share. Production never uses that file; it requires `AUTH_SECRET`.

Copy `.env.example` to `.env` to change settings. `.env` is read automatically at startup and is git-ignored.

## Production (PostgreSQL + Docker)

```bash
export POSTGRES_PASSWORD="$(openssl rand -base64 24)"
export AUTH_SECRET="$(openssl rand -hex 32)"
export APP_URL=https://rutamotor.example.com
export EMAIL_PROVIDER=resend RESEND_API_KEY=re_xxx MAIL_FROM="RutaMotor <notifications@yourdomain.com>"
docker compose up --build -d
```

This starts PostgreSQL, the API (port 3000) and a worker. Put the API behind HTTPS (a reverse proxy or load balancer). Session cookies are `Secure` in production and will not be sent over plain HTTP. Only set `TRUST_PROXY=true` when your own proxy sets `X-Forwarded-For`.

Every response carries an `X-Request-Id`, and each request writes one JSON log line with that ID, so an incident can be traced from the load balancer through to the response. Migrations run when the API starts (`MIGRATE_ON_START=true`). For a large deployment, run `npm run migrate` once as a separate step and set `MIGRATE_ON_START=false` on the API and worker.

## Configuration

| Variable | Default | Purpose |
|---|---|---|
| `NODE_ENV` | `development` | `production` enables strict checks and secure cookies. |
| `DATABASE_URL` | `sqlite:./data/rutamotor.db` | `sqlite:<path>` or `postgres://…`. |
| `AUTH_SECRET` | generated (dev only) | Signs session tokens. At least 32 characters; required in production. |
| `SESSION_TTL_SECONDS` | `43200` | Session lifetime. |
| `APP_URL` | `http://localhost:3000` | Public address of the web app. Account email links are built from it. Required, and `https://`, in production. |
| `REQUIRE_VERIFIED_EMAIL` | `false` | When `true`, accounts with an unconfirmed email cannot publish listings. Recommended for production. |
| `RATE_LIMIT_STORE` | `memory` | `memory` limits per process. `database` shares the counters across API instances at the cost of one write per request. |
| `ADMIN_EMAILS` | empty | Comma-separated emails that get the admin role at registration. |
| `TRUST_PROXY` | `false` | Use `X-Forwarded-For` for rate limiting. Enable only behind your proxy. |
| `CORS_ORIGINS` | empty | Extra origins allowed to call the API with credentials. |
| `CURRENCY` | `CLP` | Display currency code. |
| `UPLOAD_DIR` | `./data/uploads` | Local photo storage. Mount a volume in containers. |
| `MAX_PHOTO_BYTES` / `MAX_PHOTOS_PER_LISTING` | `5242880` / `10` | Photo limits. |
| `EMAIL_PROVIDER` | `log` | `log`, `resend` or `disabled`. |
| `RESEND_API_KEY`, `MAIL_FROM` | empty | Required for `resend`. The sender domain must be verified. |
| `WHATSAPP_*` | empty | WhatsApp Cloud API. Needs an approved template and seller opt-in. |
| `AI_BASE_URL`, `AI_API_KEY`, `AI_MODEL`, `AI_TIMEOUT_MS` | OpenAI defaults, no key | Any OpenAI-compatible Chat Completions endpoint. |
| `WEBHOOK_URL`, `WEBHOOK_SECRET` | empty | Outbound event delivery. Must be `https://` in production. |
| `COMPRADEAUTOS_API_KEY`, `COMPRADEAUTOS_API_BASE_URL` | empty | CompraDeAutos.cl publishing. |
| `WORKER_POLL_MS` | `3000` | Worker polling interval. |
| `STALE_LISTING_DAYS` | `60` | Age after which sellers receive a renewal reminder. |
| `WORKER_IN_PROCESS` | `false` | Run the worker inside the API process (single-node deployments). |

## Integrations

| Service | Status | Notes |
|---|---|---|
| Email (Resend) | Implemented | Lead notifications and renewal reminders. Errors are retried. |
| WhatsApp Business Cloud API | Implemented | Template messages only, and only to sellers who opted in. |
| AI (OpenAI-compatible) | Implemented | Listing drafts and buyer assistant. Drafts fall back to a facts-only template when the provider fails. |
| Outbound webhooks | Implemented | Events: `listing.created`, `listing.status_changed`, `inquiry.created`. HMAC-SHA256 signed, timestamped, retried. |
| CompraDeAutos.cl | Implemented, unverified against live API | Requires photos and engine size. The external API uses its own Spanish field names and values, which RutaMotor maps from its English domain. Endpoints follow the notes used at write time; check them against the current API docs before go-live. |
| Mercado Libre and other portals | Not implemented | Planned. Requires OAuth and partner approval. |
| Vehicle history, liens, fines | Not implemented | Requires an authorised data provider. The platform never claims a vehicle is verified. |
| Payments and financing | Not implemented | Requires legal and compliance review. |

## Automations

All automations run in the worker from a persistent `jobs` table:

- **Lead notification:** when a buyer sends an inquiry, the seller gets an email and, if opted in, a WhatsApp template. Retries do not resend the email that already went out.
- **Renewal reminders:** listings older than `STALE_LISTING_DAYS` get at most one reminder per month. Renewing a listing resets the schedule.
- **Webhook delivery:** signed events to your systems, with exponential backoff.
- **External publishing:** CompraDeAutos.cl publishing with its own status per listing.
- **Recovery:** a job locked by a crashed worker is released after 10 minutes.
- **Retention:** once a day the worker deletes finished jobs older than 30 days and account links that expired more than 7 days ago. Failed jobs and the audit log are kept. Jobs that keep failing stop after six attempts and are visible to admins, who can requeue them.

## Testing

```bash
npm run check              # syntax of every JavaScript file
npm test                   # 62 unit tests + 53 integration tests, SQLite
TEST_DATABASE_URL=postgres://user:pass@localhost:5432/db npm run test:integration   # same integration suite on PostgreSQL
E2E_CHROME_PATH=/path/to/chrome npm run test:e2e   # 2 browser suites: account screens and the marketplace (opt-in; run `npm i -D puppeteer-core` first)
```

Integration tests start the real HTTP server against a fresh database, with external services replaced by fake `fetch` implementations that fail the test if called unexpectedly. On PostgreSQL each test file runs in its own schema.

CI (`.github/workflows/ci.yml`) runs syntax checks, unit and SQLite tests, the integration suite against PostgreSQL 16, and a Docker build.

## Project layout

```
src/
  server.js, worker.js, bootstrap.js   entry points
  app.js                               HTTP routes, auth, CSRF, validation pipeline
  http.js, security.js, logger.js      HTTP toolkit, hashing and tokens, structured logs
  db.js, schema/{sqlite,postgres}/     database adapters and migrations
  store.js, domain.js, validation.js   data access, business rules, input schemas
  jobs.js, media.js                    job queue and handlers, photo storage
  accounts.js, rate-limit.js           account email copy and links, shared rate limits
  integrations/                        AI, email, WhatsApp, webhooks, CompraDeAutos
public/                                single-page web app (no build step)
scripts/                               migrate, seed, syntax check
test/unit/, test/integration/          test suites
test/e2e/                              opt-in browser tests
docs/                                  architecture and API reference
```

## Status and known limitations

- The API, persistence, background worker, and integrations are covered by the automated test suite. The PostgreSQL path runs in CI; it was not executed in the environment where this version was written.
- The web app has no build step. Opt-in browser tests in `test/e2e` cover registration, email confirmation, password reset, browsing, publishing, photo upload, inquiries, comparison, the seller inbox and the admin console. Run them before a release.
- Passwords are hashed with scrypt. Sign-in and account links are rate limited. Email confirmation and password reset are implemented; see Security.
- Photos are stored on local disk. Object storage with signed URLs and malware scanning is the next step for multi-node deployments.
- The default rate limiter is in memory per process. Set `RATE_LIMIT_STORE=database` to share limits across API instances. The PostgreSQL path for these features runs in CI; it was not executed in the environment where version 1.1.0 was written.
- Mercado Libre, vehicle history, payments and live CompraDeAutos verification are not built. [docs/ROADMAP.md](docs/ROADMAP.md) lists what each one needs before work can start.
- Listings are not verified. The product must not describe any listing as inspected or certified.

## Security

Report vulnerabilities privately to the maintainers rather than in a public issue. Key controls: parameterised SQL everywhere, server-side validation of every input, HttpOnly SameSite cookies with same-origin checks on cookie-authenticated writes, scrypt password hashing, constant-time signature checks, file-signature validation of uploads, CSP and other security headers, redacted logs, and no client access to provider credentials. Account links are single-use, stored only as SHA-256 hashes and sealed in the job queue. A password change ends every existing session, and `POST /api/auth/sessions/revoke-all` ends them on demand.

## Licence

Proprietary. All rights reserved.
