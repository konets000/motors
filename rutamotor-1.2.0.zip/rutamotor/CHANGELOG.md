# Changelog

## 1.2.0

Hardening and operations pass, found by reviewing and testing the 1.1.0 code.

- **Fix:** running migrations from several API instances at once could fail with "database is locked". Migrations now run in one transaction under a lock. Covered by a test that runs two real processes.
- **Fix:** photo uploads counted the listing's photos without a row lock, so concurrent uploads on PostgreSQL could exceed `MAX_PHOTOS_PER_LISTING`. The listing is now locked and its status re-checked first.
- **Fix:** `HEAD` requests to API routes returned 405. They now answer like `GET`, which load balancers rely on.
- **Fix:** the browser hardcoded the 5 MB photo limit. The limits now come from `GET /api/facets`.
- **Fix:** comparing a car re-rendered the whole list. The compare buttons now update in place.
- **New:** `POST /api/auth/sessions/revoke-all` signs out every session of an account, including copied tokens.
- **New:** `X-Request-Id` on every response, and one `request.completed` log line per request (path only, never the query string).
- **New:** daily retention job. Finished jobs older than 30 days and links expired for over 7 days are deleted.
- **Tests:** 115 unit and integration tests (was 101), including concurrency, retention, hostile-input and tracing tests, and a second browser suite covering the marketplace.
- Browser tests (`npm run test:e2e`) now cover browsing, publishing, photo upload, inquiries, comparison, the seller inbox and the admin console, in addition to the account screens.

## 1.1.0

Account security and the first part of the planned platform work.

- Email confirmation: a one-time link (72 hours) is sent at registration. `GET /api/auth/me` reports `emailVerified`. Accounts can request a new link, which revokes the previous one.
- Password reset: `forgot-password` answers identically for every address, and `reset-password` consumes a one-time link (1 hour). A reset signs out other sessions, confirms the email, and notifies the account holder.
- `REQUIRE_VERIFIED_EMAIL=true` blocks listing creation and CompraDeAutos publishing until the email is confirmed.
- Account links are stored as SHA-256 hashes. Email jobs hold their token sealed with AES-256-GCM, so the queue never contains a usable link.
- Sessions carry a `session_version`. Changing the password invalidates earlier sessions.
- `RATE_LIMIT_STORE=database` shares rate limits across API instances. The default stays in memory.
- `APP_URL` is required in production. Links in emails are built from it.
- Development: one secret is shared through `data/.dev-auth-secret`, so the API and worker can exchange links. Emails in development show their full text, including the links.
- Web app: confirmation banner, confirmation page, forgot-password and reset-password screens, and a "Forgot your password?" link on sign-in.
- Migrations `002_account_tokens` and `003_rate_limits` for SQLite and PostgreSQL.
- Tests: 101 unit and integration tests (was 74), plus opt-in browser tests in `test/e2e`.
- Demo seed accounts are marked as confirmed.
- Upgrade note: accounts created before 1.1.0 have no confirmed email. They see the confirmation banner and can request a link. Ask existing users to confirm before setting `REQUIRE_VERIFIED_EMAIL=true`, or it will block their listings.
- Not in this release: the items in [docs/ROADMAP.md](docs/ROADMAP.md) that depend on partners, data providers or legal review.
## 1.0.0

Rewrite of the earlier Spanish prototype as an English platform.

- Full English interface, API messages, documentation and code comments.
- Persistence on SQLite (built in, development and single node) and PostgreSQL (production), from one set of SQL statements.
- Accounts with scrypt hashing, HttpOnly session cookies, CSRF checks, roles and admin moderation.
- Listings with status state machine, photo uploads with magic-byte validation, renewal and inquiries with explicit consent.
- Seller inbox with status tracking and CSV export that neutralises formula injection.
- Persistent job queue with transactional outbox, backoff, permanent-error handling, stale-lock recovery and admin retry.
- Idempotent notifications: a retry does not resend an email that was already delivered.
- Renewal reminders on a monthly schedule.
- Signed outbound webhooks.
- AI listing drafts with a facts-only fallback, and a buyer assistant grounded in active listings.
- CompraDeAutos.cl publishing as a background job.
- Web app with search, filters, galleries, comparison, seller dashboard, inquiries and admin jobs.
- 47 unit tests and 27 integration tests; CI runs SQLite and PostgreSQL suites.
- Issues caught while building this version and fixed before release: a parameter mix-up in paginated search, dialect properties missing from transaction scopes, a router that did not escape literal dots, and a worker-level race between parallel test files (solved with per-test schemas).
- Carried over from 0.2.0: malformed UUIDs in routes return 404 instead of a database error.
